import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import net from 'node:net';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
async function freePort() {
  const socket = net.createServer();
  await new Promise((resolve, reject) => socket.listen(0, '127.0.0.1', resolve).once('error', reject));
  const port = socket.address().port;
  await new Promise((resolve, reject) => socket.close((error) => error ? reject(error) : resolve()));
  return port;
}
async function waitForBackend(base, child) {
  for (let attempt = 0; attempt < 60; attempt++) {
    if (child.exitCode !== null) throw new Error('Backend exited before becoming ready');
    try { if ((await fetch(`${base}/api/health`)).ok) return; } catch { /* startup */ }
    await pause(50);
  }
  child.kill();
  throw new Error('Backend did not become ready');
}

test('self-hosted Ollama-compatible provider works without an API key and can be diagnosed', async (t) => {
  let providerSawAuthorization = false;
  let diagnosticPrompt = '';
  const provider = createServer((request, response) => {
    let text = '';
    request.setEncoding('utf8');
    request.on('data', (chunk) => { text += chunk; });
    request.on('end', () => {
      providerSawAuthorization ||= Boolean(request.headers.authorization);
      const body = JSON.parse(text || '{}');
      if (body.messages?.length === 1) diagnosticPrompt = body.messages[0].content;
      const content = body.messages?.length === 1
        ? 'Circuit Studio model connection OK.'
        : JSON.stringify({ title: 'Mock review', summary: 'Self-hosted endpoint responded.', recommendations: ['Verify sensor voltage.'], cautions: ['Confirm the exact sensor datasheet.'], parts: ['dht22'] });
      response.writeHead(200, { 'content-type': 'application/json' });
      response.end(JSON.stringify({ choices: [{ message: { role: 'assistant', content } }] }));
    });
  });
  await new Promise((resolve, reject) => provider.listen(0, '127.0.0.1', resolve).once('error', reject));
  const providerPort = provider.address().port;
  t.after(async () => {
    provider.close();
    await Promise.race([once(provider, 'close'), pause(1500)]);
  });

  const appPort = await freePort();
  const child = spawn(process.execPath, ['server/index.js'], {
    cwd: ROOT,
    env: { ...process.env, PORT: String(appPort), HOST: '127.0.0.1', AI_API_KEY: '', AI_PROVIDER: 'ollama', AI_MODEL: 'mock-model', AI_BASE_URL: `http://127.0.0.1:${providerPort}/v1` },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  t.after(async () => {
    if (child.exitCode === null) {
      child.kill();
      await Promise.race([once(child, 'exit'), pause(1500)]);
    }
  });
  const base = `http://127.0.0.1:${appPort}`;
  await waitForBackend(base, child);

  const health = await fetch(`${base}/api/health`).then((response) => response.json());
  assert.equal(health.ai.enabled, true);
  assert.equal(health.ai.provider, 'ollama');
  assert.equal(health.ai.model, 'mock-model');

  const diagnostic = await fetch(`${base}/api/ai/test`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' }).then((response) => response.json());
  assert.equal(diagnostic.ok, true);
  assert.equal(diagnostic.provider, 'ollama');
  assert.equal(providerSawAuthorization, false);
  assert.match(diagnosticPrompt, /connection OK/);

  const review = await fetch(`${base}/api/assistant`, {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ prompt: 'Review an ESP32 with a DHT22', useExternal: true, usePublicData: false, project: { name: 'Private Project', components: [], nets: [] } }),
  }).then((response) => response.json());
  assert.equal(review.mode, 'configured-ai');
  assert.equal(review.title, 'Mock review');
  assert.ok(review.cautions.includes('Confirm the exact sensor datasheet.'));
});
