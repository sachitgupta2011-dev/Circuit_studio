import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { createServer } from 'node:http';
import net from 'node:net';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function freePort() {
  const socket = net.createServer();
  await new Promise((resolve, reject) => socket.listen(0, '127.0.0.1', resolve).once('error', reject));
  const port = socket.address().port;
  await new Promise((resolve, reject) => socket.close((error) => error ? reject(error) : resolve()));
  return port;
}

async function startTestServer(overrides = {}) {
  const port = await freePort();
  const child = spawn(process.execPath, ['server/index.js'], {
    cwd: ROOT,
    env: { ...process.env, PORT: String(port), HOST: '127.0.0.1', AI_API_KEY: '', AI_MODEL: '', ...overrides },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let logs = '';
  child.stdout.on('data', (chunk) => { logs += chunk; });
  child.stderr.on('data', (chunk) => { logs += chunk; });
  const base = `http://127.0.0.1:${port}`;
  for (let attempt = 0; attempt < 60; attempt++) {
    if (child.exitCode !== null) throw new Error(`Backend exited during startup: ${logs}`);
    try {
      const response = await fetch(`${base}/api/health`);
      if (response.ok) return { base, child };
    } catch { /* server is still starting */ }
    await pause(50);
  }
  child.kill();
  throw new Error(`Backend did not become ready: ${logs}`);
}

test('Node backend serves health, starter catalog, local assistant, BOM import, and frontend files', async (t) => {
  const { base, child } = await startTestServer();
  t.after(async () => {
    if (child.exitCode === null) {
      child.kill();
      await Promise.race([once(child, 'exit'), pause(1500)]);
    }
  });

  const healthResponse = await fetch(`${base}/api/health`);
  const health = await healthResponse.json();
  assert.equal(health.ok, true);
  assert.equal(health.ai.enabled, false);
  const aiDiagnostic = await fetch(`${base}/api/ai/test`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' }).then((response) => response.json());
  assert.equal(aiDiagnostic.configured, false);
  assert.equal(aiDiagnostic.ok, false);
  assert.equal(health.catalog.count, 70);
  assert.ok(health.integrations.some((entry) => entry.id === 'tinkercad'));

  const catalog = await fetch(`${base}/api/catalog?q=OLED`).then((response) => response.json());
  assert.ok(catalog.items.some((item) => item.id === 'oled'));

  const assistant = await fetch(`${base}/api/assistant`, {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ prompt: 'ESP32 DHT22 room monitor', usePublicData: false, project: { name: 'Test' } }),
  }).then((response) => response.json());
  assert.equal(assistant.mode, 'local-catalog');
  assert.ok(assistant.parts.some((part) => part.id === 'dht22'));

  const bom = await fetch(`${base}/api/import/tinkercad-bom`, {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ csv: 'Reference,Component,Quantity,Value\nU1,ESP32 DevKit V1,1,ESP32-WROOM\nR1,Resistor,2,4.7k\n' }),
  }).then((response) => response.json());
  assert.equal(bom.count, 2);
  assert.equal(bom.rows[0].description, 'ESP32 DevKit V1');
  assert.equal(bom.rows[0].value, 'ESP32-WROOM');
  assert.equal(bom.rows[0].match.id, 'esp32dev');
  assert.equal(bom.rows[1].quantity, 2);

  const html = await fetch(`${base}/`).then((response) => response.text());
  const frontend = await fetch(`${base}/src/main.js`).then((response) => response.text());
  assert.match(html, /Circuit Studio/);
  assert.match(frontend, /openIntegrationsModal/);
});
