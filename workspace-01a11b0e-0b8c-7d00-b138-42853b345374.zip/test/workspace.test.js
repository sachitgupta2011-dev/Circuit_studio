import test from 'node:test';
import assert from 'node:assert/strict';
import { createStarterProject, getPinAnchor } from '../src/model.js';
import { applyLocalDesignAssistant, generateFirmware, describeConnections } from '../src/assistant.js';
import { validateDesign, simulateBehavior } from '../src/simulator.js';
import { bomCSV, gerberCopper, gerberOutline, kicadPCB, drillFile, projectJSON } from '../src/exporters.js';

const project = createStarterProject();

test('starter design has real component references and resolvable wire endpoints', () => {
  assert.equal(project.components.length, 7);
  assert.ok(project.components.some((component) => component.ref === 'C1' && component.type === 'capacitor'));
  const ids = new Set(project.components.map((component) => component.id));
  for (const wire of project.wires) {
    assert.ok(ids.has(wire.from[0]), `missing source for ${wire.id}`);
    assert.ok(ids.has(wire.to[0]), `missing destination for ${wire.id}`);
  }
});

test('pin anchors align with the ESP32 module and passive footprints', () => {
  assert.deepEqual(getPinAnchor(project.components[0], '3V3'), { x: 340, y: 275, side: 'left' });
  assert.deepEqual(getPinAnchor(project.components.find((item) => item.id === 'R1'), 'B'), { x: 270, y: 363, side: 'right' });
});

test('local assistant creates scoped templates and retains safety notes', () => {
  const irrigation = applyLocalDesignAssistant(project, 'Build an ESP32 soil moisture irrigation relay controller');
  assert.equal(irrigation.project.name, 'Smart Irrigation');
  assert.ok(irrigation.project.components.some((component) => component.libraryId === 'soil'));
  assert.ok(irrigation.project.components.some((component) => component.id === 'K1'));
  assert.ok(irrigation.cautions.some((note) => /never power it from/i.test(note)));
  const blink = applyLocalDesignAssistant(project, 'Make a blinking status LED controller');
  assert.equal(blink.project.components.length, 4);
  assert.ok(blink.project.components.some((component) => component.type === 'resistor'));
  const room = applyLocalDesignAssistant(blink.project, 'Build a room temperature and humidity monitor');
  assert.ok(room.project.components.some((component) => component.libraryId === 'dht22'));
  assert.ok(room.project.components.some((component) => component.libraryId === 'oled'));
});

test('limited checks and behavior preview are explicit about their scope', () => {
  const report = validateDesign(project);
  assert.equal(report.counts.errors, 0);
  assert.ok(report.suggestions.some((suggestion) => /manufacturing/i.test(suggestion.title)));
  const simulation = simulateBehavior(project);
  assert.ok(simulation.lines.some((line) => /no SPICE solve/i.test(line.text)));
  assert.ok(simulation.waves.points.length >= 40);
  assert.equal(describeConnections(project).length, project.wires.length);
});

test('exports produce text snapshots with fabrication warnings', () => {
  assert.match(projectJSON(project), /circuit-studio-project/);
  assert.match(bomCSV(project), /Reference/);
  assert.match(gerberCopper(project), /not fabrication-verified/);
  assert.match(gerberOutline(), /Edge.Cuts/);
  assert.match(kicadPCB(project), /\(kicad_pcb/);
  assert.match(drillFile(project), /M48/);
  assert.match(generateFirmware(project), /void setup\(\)/);
});
