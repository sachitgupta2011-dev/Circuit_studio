import { designSuggestions } from './assistant.js';

export function validateDesign(project) {
  const issues = [];
  const refs = new Set();
  for (const component of project.components) {
    if (refs.has(component.ref)) issues.push({ severity: 'error', code: 'REF_DUPLICATE', text: `Duplicate reference ${component.ref}.` });
    refs.add(component.ref);
  }
  const byId = new Map(project.components.map((component) => [component.id, component]));
  for (const wire of project.wires) {
    if (!byId.has(wire.from[0]) || !byId.has(wire.to[0])) issues.push({ severity: 'error', code: 'WIRE_ENDPOINT', text: `${wire.id} references a missing component.` });
  }
  const hasSensor = project.components.some((component) => ['sensor', 'display'].includes(component.type));
  if (hasSensor && !project.wires.some((wire) => wire.net === 'GND')) issues.push({ severity: 'warning', code: 'NO_GROUND', text: 'No ground net found in the project.' });
  const hasLed = project.components.some((component) => component.type === 'led');
  const hasResistor = project.components.some((component) => component.type === 'resistor');
  if (hasLed && !hasResistor) issues.push({ severity: 'warning', code: 'LED_RESISTOR', text: 'No series resistor found for the LED. Add a current-limiting resistor.' });
  const hasDht = project.components.some((component) => component.libraryId === 'dht22');
  if (hasDht && !project.components.some((component) => component.type === 'resistor' && /4\.7\s*k/i.test(component.value))) issues.push({ severity: 'warning', code: 'DHT_PULLUP', text: 'A 4.7 kΩ DHT22 data pull-up was not detected.' });
  if (!project.components.some((component) => component.type === 'capacitor')) issues.push({ severity: 'info', code: 'BYPASS', text: 'Consider local 100 nF bypass capacitors at module power pins.' });
  if (project.wires.length === 0) issues.push({ severity: 'warning', code: 'NO_NETS', text: 'No schematic nets are defined.' });
  const suggestions = designSuggestions(project);
  const errors = issues.filter((issue) => issue.severity === 'error').length;
  const warnings = issues.filter((issue) => issue.severity === 'warning').length + suggestions.filter((item) => item.type === 'review').length;
  const info = issues.filter((issue) => issue.severity === 'info').length + suggestions.filter((item) => item.type === 'verified').length;
  return {
    issues,
    suggestions,
    summary: errors ? 'Blocking structural issues found' : warnings ? 'Structural preview passes · engineering review recommended' : 'Preview checks passed · not a full ERC/DRC',
    counts: { errors, warnings, info },
  };
}

export function simulateBehavior(project) {
  const check = validateDesign(project);
  const lines = [];
  const time = new Date().toLocaleTimeString([], { hour12: false });
  lines.push({ kind: 'meta', text: `[${time}] Circuit Studio behavioral preview · ${project.name}` });
  lines.push({ kind: 'meta', text: 'Offline model only — no SPICE solve, MCU execution, or hardware measurement.' });
  lines.push({ kind: 'meta', text: `Loaded ${project.components.length} components · ${project.wires.length} schematic connections.` });
  lines.push({ kind: check.counts.errors ? 'error' : check.counts.warnings ? 'warning' : 'success', text: `Preview checks: ${check.counts.errors} blocking · ${check.counts.warnings} engineering review items · ${check.counts.info} notes.` });
  if (project.components.some((component) => component.libraryId === 'dht22')) {
    const t = 22.1 + (Math.sin(Date.now() / 15000) + 1) * 1.2;
    const h = 46 + (Math.sin(Date.now() / 18000 + 0.8) + 1) * 4.5;
    lines.push({ kind: 'output', text: `DHT22 behavioral sample: ${t.toFixed(1)} °C · ${h.toFixed(1)} % RH` });
    lines.push({ kind: 'output', text: 'SSD1306 I²C target: 0x3C · GPIO21 SDA / GPIO22 SCL (assumed)' });
  } else if (/soil|irrigation/i.test(project.name)) {
    const adc = Math.round(2100 + (Math.sin(Date.now() / 12000) + 1) * 450);
    lines.push({ kind: 'output', text: `Soil ADC behavioral sample: ${adc} / 4095 · calibration not applied` });
    lines.push({ kind: 'output', text: 'Relay output held LOW in safe preview; pump and contact behavior are not simulated.' });
  } else if (project.components.some((component) => component.type === 'led')) {
    lines.push({ kind: 'output', text: 'GPIO2 → 220 Ω → status LED → GND · idealized digital toggle at 1 Hz.' });
  } else {
    lines.push({ kind: 'meta', text: 'No built-in behavioral model for this component set. Add a supported starter or connect a simulation backend.' });
  }
  if (check.issues.length) {
    for (const issue of check.issues) lines.push({ kind: issue.severity === 'error' ? 'error' : 'warning', text: `${issue.severity.toUpperCase()} ${issue.code}: ${issue.text}` });
  } else {
    lines.push({ kind: 'success', text: 'No blocking structural errors detected in this limited preview.' });
  }
  for (const suggestion of check.suggestions.filter((item) => item.type === 'review')) lines.push({ kind: 'warning', text: `REVIEW ${suggestion.title}: ${suggestion.text}` });
  return { lines, check, waves: createWaveforms(project) };
}

export function createWaveforms(project) {
  const points = Array.from({ length: 80 }, (_, index) => {
    const x = index / 79;
    return {
      x,
      temperature: 0.45 + 0.16 * Math.sin(x * Math.PI * 3.4 - 0.6),
      humidity: 0.55 + 0.11 * Math.sin(x * Math.PI * 2.1 + 0.7),
      digital: index % 20 < 10 ? 0.76 : 0.26,
    };
  });
  return { points, sensorName: /soil|irrigation/i.test(project.name) ? 'ADC1 · GPIO34' : 'DHT22 · GPIO4' };
}
