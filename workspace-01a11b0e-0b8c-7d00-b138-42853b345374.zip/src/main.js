import { LIBRARY, CATEGORIES, createStarterProject, createComponentFromLibrary, getComponentSize, getPinAnchor, nextReference } from './model.js';
import { applyLocalDesignAssistant, generateFirmware, describeConnections, designSuggestions } from './assistant.js';
import { validateDesign, simulateBehavior } from './simulator.js';
import { renderCanvas } from './render.js';
import { downloadText, projectJSON, bomCSV, gerberCopper, gerberOutline, kicadPCB, drillFile, schematicSVG } from './exporters.js';

const STORAGE_KEY = 'circuit-studio-workspace-v1';
const app = document.querySelector('#app');
const escapeHTML = (value = '') => String(value).replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
const clone = (value) => structuredClone(value);
const icon = (name, size = 16) => {
  const paths = {
    circuit: '<path d="M3 12h3l2-6 4 12 2-6h7"/><circle cx="3" cy="12" r="1"/><circle cx="21" cy="12" r="1"/>',
    chevron: '<path d="m7 10 5 5 5-5"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    search: '<circle cx="10.8" cy="10.8" r="6.7"/><path d="m16 16 4.5 4.5"/>',
    folder: '<path d="M3 7.5h7l2 2H21v9H3z"/><path d="M3 7V5h7l2 2"/>',
    file: '<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>',
    board: '<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M9 2v4m6-4v4M9 18v4m6-4v4M2 9h4m12 0h4M2 15h4m12 0h4"/><circle cx="12" cy="12" r="3"/>',
    code: '<path d="m8 7-5 5 5 5m8-10 5 5-5 5m-2-13-4 16"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M2 12h2m16 0h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    moon: '<path d="M20.8 14.3A8.5 8.5 0 0 1 9.7 3.2 8.6 8.6 0 1 0 20.8 14.3Z"/>',
    activity: '<path d="M3 12h4l3-8 4 16 3-8h4"/>',
    undo: '<path d="M9 14 4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-2"/>',
    redo: '<path d="m15 14 5-5-5-5"/><path d="M20 9H10a6 6 0 0 0 0 12h2"/>',
    play: '<path d="m8 5 11 7-11 7z"/>',
    stop: '<rect x="6" y="6" width="12" height="12" rx="2"/>',
    spark: '<path d="m12 3 1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="m19 16 .8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z"/>',
    share: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.7 10.7 6.6-4.4m-6.6 7 6.6 4.4"/>',
    download: '<path d="M12 3v12m-5-5 5 5 5-5M5 20h14"/>',
    fit: '<path d="M8 3H5a2 2 0 0 0-2 2v3m13-5h3a2 2 0 0 1 2 2v3M3 16v3a2 2 0 0 0 2 2h3m13-5v3a2 2 0 0 1-2 2h-3"/>',
    select: '<path d="m5 3 14 10-7 1-3 7z"/>',
    wire: '<path d="M4 5h6v6H4zM14 13h6v6h-6zM10 8h4v8"/>',
    pan: '<path d="M8 11V5a2 2 0 0 1 4 0v5-7a2 2 0 0 1 4 0v8-5a2 2 0 0 1 4 0v8a8 8 0 0 1-8 8h-1a7 7 0 0 1-5-2l-3-4a2 2 0 0 1 3-3l2 2"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    x: '<path d="m6 6 12 12M18 6 6 18"/>',
    trash: '<path d="M4 7h16m-10 4v6m4-6v6M6 7l1 14h10l1-14M9 7V4h6v3"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    terminal: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="m7 9 3 3-3 3m6 0h4"/>',
    sliders: '<path d="M4 21v-7m0-4V3m8 18v-9m0-4V3m8 18v-5m0-4V3M2 14h4m4-6h4m4 6h4"/>',
    expand: '<path d="M8 3H5a2 2 0 0 0-2 2v3m13-5h3a2 2 0 0 1 2 2v3M3 16v3a2 2 0 0 0 2 2h3m13-5v3a2 2 0 0 1-2 2h-3"/>',
    chevronRight: '<path d="m9 18 6-6-6-6"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5m0-8h.01"/>',
    flash: '<path d="m13 2-3 9h7l-6 11 1-9H5z"/>',
    layers: '<path d="m12 3 9 5-9 5-9-5zM3 12l9 5 9-5m-18 5 9 5 9-5"/>',
    more: '<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
  };
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.info}</svg>`;
};

function decodeHashProject() {
  const match = window.location.hash.match(/(?:#|&)project=([^&]+)/);
  if (!match) return null;
  try {
    const bytes = Uint8Array.from(atob(decodeURIComponent(match[1])), (character) => character.charCodeAt(0));
    const parsed = JSON.parse(new TextDecoder().decode(bytes));
    return parsed.project || parsed;
  } catch { return null; }
}
function loadProject() {
  const shared = decodeHashProject();
  if (shared?.components && shared?.wires) return shared;
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
    if (saved?.project?.components && saved?.project?.wires) return saved.project;
  } catch { /* local storage may be disabled */ }
  return createStarterProject();
}
let project = loadProject();
project.boardPositions ||= {};
project.versions ||= [];
project.notes ||= [];
if (!project.firmware) project.firmware = generateFirmware(project);

const ui = {
  view: project.activeView || 'schematic',
  tool: 'select', zoom: 1, panX: 0, panY: 0, snap: true,
  selectedIds: new Set(), selectedWire: null, pendingPin: null,
  librarySearch: '', libraryCategory: 'All parts', inspectorTab: 'properties', consoleTab: 'console',
  consoleLines: [{ kind: 'meta', text: 'Workspace ready · autosave is stored locally in this browser.' }],
  simulation: null, theme: (() => { try { return localStorage.getItem('circuit-studio-theme') || 'dark'; } catch { return 'dark'; } })(),
  drag: null, spaceDown: false, toastTimer: null, firmwareSaveTimer: null, exportMenu: false,
  backendStatus: 'checking', backendHealth: null,
  tinkercadCsvText: '', tinkercadFileName: '', tinkercadRows: [],
};
let undoStack = [];
let undoIndex = -1;
let copiedComponents = [];
let suppressInputCommit = false;

function iconButton(name, label, action, extra = '') {
  return `<button class="icon-button ${extra}" type="button" data-action="${action}" aria-label="${label}" title="${label}">${icon(name, 16)}</button>`;
}

app.innerHTML = `
  <div class="app-shell ${ui.theme === 'light' ? 'theme-light' : ''}">
    <header class="topbar">
      <div class="brand-block">
        <div class="brand-mark">${icon('circuit', 19)}</div>
        <div class="brand-type"><span>CIRCUIT</span><b>STUDIO</b></div>
        <span class="brand-divider"></span>
        <span class="workspace-label">ENGINEERING WORKSPACE</span>
      </div>
      <div class="project-identity">
        <div class="project-identity-icon">${icon('file', 15)}</div>
        <div class="project-name-wrap"><span id="top-project-name">${escapeHTML(project.name)}</span><span class="project-branch">main <i></i> local project</span></div>
        <button class="rename-trigger" data-action="rename-project" title="Rename project">${icon('chevron', 13)}</button>
      </div>
      <div class="top-actions">
        <span class="saved-status" id="saved-status"><i class="status-dot"></i><span>Saved locally</span></span>
        ${iconButton('file', 'Save version · Ctrl+S', 'save')}
        ${iconButton('undo', 'Undo · Ctrl+Z', 'undo')}
        ${iconButton('redo', 'Redo · Ctrl+Shift+Z', 'redo')}
        <span class="top-divider"></span>
        ${iconButton(ui.theme === 'dark' ? 'sun' : 'moon', 'Toggle light / dark theme', 'theme')}
        <button class="top-action-button" data-action="share">${icon('share', 15)}<span>Share</span></button>
        <button class="top-action-button" data-action="export">${icon('download', 15)}<span>Export</span>${icon('chevron', 12)}</button>
        <button class="top-action-button ai-top-button" data-action="ai-open">${icon('spark', 15)}<span>AI design</span></button>
        <button class="run-top-button" data-action="simulate">${icon('play', 14)}<span>Run simulation</span></button>
      </div>
    </header>

    <div class="workspace-grid">
      <aside class="left-panel" aria-label="Project explorer and parts library">
        <section class="explorer-section">
          <div class="section-heading"><div class="section-title">PROJECT</div><span class="project-count">${project.components.length} PARTS</span>${iconButton('plus', 'New project', 'new-project', 'tiny-icon-button')}</div>
          <div class="project-tree">
            <div class="tree-row project-root-row"><span class="tree-caret">${icon('chevron', 12)}</span><span class="tree-icon root-folder">${icon('folder', 15)}</span><span class="tree-label" id="tree-project-name">${escapeHTML(project.name)}</span><span class="tree-more">${icon('more', 14)}</span></div>
            <button class="tree-row tree-file ${ui.view === 'schematic' ? 'active' : ''}" data-view="schematic"><span class="tree-indent"></span><span class="tree-icon schematic-icon">${icon('file', 14)}</span><span class="tree-label">${escapeHTML(project.name.toLowerCase().replace(/\s+/g, '-'))}.sch</span><span class="file-badge">SHEET 1</span></button>
            <button class="tree-row tree-file ${ui.view === 'pcb' ? 'active' : ''}" data-view="pcb"><span class="tree-indent"></span><span class="tree-icon board-icon">${icon('board', 14)}</span><span class="tree-label">${escapeHTML(project.name.toLowerCase().replace(/\s+/g, '-'))}.pcb</span></button>
            <button class="tree-row tree-file ${ui.view === 'firmware' ? 'active' : ''}" data-view="firmware"><span class="tree-indent"></span><span class="tree-icon code-icon">${icon('code', 14)}</span><span class="tree-label">src / main.ino</span><span class="file-badge code-badge">INO</span></button>
          </div>
        </section>

        <section class="library-section">
          <div class="library-heading"><div><div class="section-title">COMPONENT LIBRARY</div><div class="library-subtitle">${LIBRARY.length} curated parts · open data search</div></div><div class="library-heading-actions"><button class="library-settings integration-trigger" data-action="integrations" title="Backend & integrations" aria-label="Backend and integrations">${icon('activity', 15)}<i class="backend-status-dot checking" id="backend-indicator"></i></button><button class="library-settings" data-action="library-info" title="Library information">${icon('info', 15)}</button><button class="library-collapse" data-action="collapse-library" title="Collapse component library">${icon('chevron', 13)}</button></div></div>
          <label class="library-search"><span>${icon('search', 15)}</span><input id="library-search" type="search" value="${escapeHTML(ui.librarySearch)}" placeholder="Find a component…" autocomplete="off"/><kbd>/</kbd></label>
          <div class="library-category-list" id="library-category-list"></div>
          <div class="library-results-head"><span>COMPONENTS</span><span id="library-result-count"></span></div>
          <div class="library-list" id="library-list"></div>
          <div class="library-footnote"><span class="library-footnote-icon">${icon('info', 13)}</span><span>Footprints and models are a starter catalog. Verify datasheets and packages before fabrication.</span></div>
        </section>
      </aside>

      <main class="center-column">
        <div class="canvas-toolbar-row">
          <div class="view-tabs" role="tablist" aria-label="Design workspace">
            <button class="view-tab" data-view="schematic" role="tab" title="Schematic editor">${icon('circuit', 15)}<span>Schematic</span></button>
            <button class="view-tab" data-view="pcb" role="tab" title="PCB placement and routing preview">${icon('board', 15)}<span>PCB layout</span><span class="tab-draft">DRAFT</span></button>
            <button class="view-tab" data-view="firmware" role="tab" title="Firmware scaffold">${icon('code', 15)}<span>Firmware</span></button>
          </div>
          <div id="view-tools"></div>
        </div>
        <section class="canvas-stage" id="canvas-stage" aria-label="Design canvas">
          <svg id="design-canvas" viewBox="0 0 1000 680" preserveAspectRatio="xMidYMid meet" aria-label="Interactive schematic canvas"></svg>
          <div id="firmware-stage" hidden></div>
          <div class="canvas-status-left" id="canvas-status-left"></div>
          <div class="canvas-status-right" id="canvas-status-right"></div>
        </section>
        <section class="console-dock" aria-label="Simulation and validation">
          <div class="dock-header">
            <div class="dock-tabs" role="tablist">
              <button class="dock-tab" data-console-tab="console">${icon('terminal', 14)} Console <span class="dock-live-dot"></span></button>
              <button class="dock-tab" data-console-tab="waveforms">${icon('activity', 14)} Waveforms</button>
              <button class="dock-tab" data-console-tab="instruments">${icon('sliders', 14)} Instruments</button>
              <button class="dock-tab" data-console-tab="checks">${icon('check', 14)} Design checks <span class="check-count" id="check-count">—</span></button>
            </div>
            <div class="dock-actions"><span class="engine-label"><i></i> LOCAL BEHAVIORAL MODEL</span><button data-action="clear-console" class="dock-clear">Clear</button><button class="dock-collapse" data-action="collapse-dock" aria-label="Collapse console">⌄</button></div>
          </div>
          <div class="dock-body" id="dock-body"></div>
        </section>
      </main>

      <aside class="inspector-panel" aria-label="Properties inspector">
        <div class="inspector-heading"><div><div class="inspector-title">INSPECTOR</div><div class="inspector-context" id="inspector-context">PROJECT SETTINGS</div></div><button class="inspector-menu" data-action="inspector-menu" aria-label="Inspector menu">${icon('more', 17)}</button></div>
        <div class="inspector-tabs" role="tablist"><button data-inspector-tab="properties">${icon('sliders', 13)} Properties</button><button data-inspector-tab="connections">${icon('circuit', 13)} Connections <span id="connection-count">0</span></button></div>
        <div class="inspector-content" id="inspector-content"></div>
        <div class="inspector-bottom" id="inspector-bottom"></div>
      </aside>
    </div>
    <div id="modal-root"></div>
    <div id="toast" class="toast" role="status" aria-live="polite"></div>
  </div>`;

const shell = app.querySelector('.app-shell');
const svg = app.querySelector('#design-canvas');
const modalRoot = app.querySelector('#modal-root');

function persistProject() {
  try {
    project.activeView = ui.view;
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ project, savedAt: new Date().toISOString() }));
    const status = app.querySelector('#saved-status');
    if (status) {
      status.classList.add('is-saved');
      status.querySelector('span').textContent = 'Saved locally';
    }
  } catch {
    setSaveLabel('Storage unavailable');
  }
}
function setSaveLabel(text) {
  const status = app.querySelector('#saved-status');
  if (status) { status.querySelector('span').textContent = text; status.classList.remove('is-saved'); }
}
function addVersion(label = 'Manual save') {
  const entry = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    label,
    savedAt: new Date().toISOString(),
    name: project.name,
    components: clone(project.components),
    wires: clone(project.wires),
  };
  project.versions = [...(project.versions || []), entry].slice(-12);
}
function addHistory(label = 'Edit', saveVersion = true) {
  const current = JSON.stringify(project);
  if (undoStack[undoIndex] !== current) {
    undoStack = undoStack.slice(0, undoIndex + 1);
    undoStack.push(current);
    undoIndex = undoStack.length - 1;
  }
  if (saveVersion) addVersion(label);
  persistProject();
  renderAll();
}
function setDirty() { setSaveLabel('Unsaved changes'); }
function saveVersion() {
  addVersion('Manual save');
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify({ project, savedAt: new Date().toISOString() })); } catch { /* no-op */ }
  toast('Version saved locally');
  renderHeader();
}
function initHistory() {
  undoStack = [JSON.stringify(project)]; undoIndex = 0;
}
function undo() {
  if (undoIndex <= 0) return toast('Nothing to undo');
  undoIndex--;
  project = JSON.parse(undoStack[undoIndex]);
  ui.selectedIds.clear(); ui.selectedWire = null; ui.pendingPin = null;
  persistProject(); renderAll(); toast('Undo');
}
function redo() {
  if (undoIndex >= undoStack.length - 1) return toast('Nothing to redo');
  undoIndex++;
  project = JSON.parse(undoStack[undoIndex]);
  ui.selectedIds.clear(); ui.selectedWire = null; ui.pendingPin = null;
  persistProject(); renderAll(); toast('Redo');
}
function toast(message) {
  const node = app.querySelector('#toast');
  node.textContent = message;
  node.classList.add('visible');
  clearTimeout(ui.toastTimer);
  ui.toastTimer = setTimeout(() => node.classList.remove('visible'), 2600);
}
function renderHeader() {
  const top = app.querySelector('#top-project-name');
  const tree = app.querySelector('#tree-project-name');
  if (top) top.textContent = project.name;
  if (tree) tree.textContent = project.name;
  const status = app.querySelector('#saved-status');
  if (status && !status.classList.contains('is-saved')) status.querySelector('span').textContent = 'Unsaved changes';
  const themeButton = app.querySelector('[data-action="theme"]');
  if (themeButton) { themeButton.innerHTML = icon(ui.theme === 'dark' ? 'sun' : 'moon', 16); themeButton.title = 'Toggle light / dark theme'; }
  updateBackendIndicator();
}

function updateBackendIndicator() {
  const indicator = app.querySelector('#backend-indicator');
  const button = app.querySelector('[data-action="integrations"]');
  if (indicator) {
    indicator.className = `backend-status-dot ${ui.backendStatus}`;
    indicator.title = ui.backendStatus === 'online' ? 'Backend API online' : ui.backendStatus === 'offline' ? 'Backend API unavailable' : 'Checking backend';
  }
  if (button) button.title = ui.backendStatus === 'online' ? 'Backend online · integrations' : ui.backendStatus === 'offline' ? 'Backend unavailable · integrations' : 'Checking backend · integrations';
  const external = modalRoot.querySelector('#ai-use-external');
  const externalLabel = modalRoot.querySelector('#ai-external-label');
  if (external) {
    const enabled = ui.backendHealth?.ai?.enabled === true;
    external.disabled = !enabled;
    if (!enabled) external.checked = false;
    if (externalLabel) externalLabel.textContent = enabled ? `Send this brief and project summary to the configured ${ui.backendHealth.ai.provider || 'server'} model (${ui.backendHealth.ai.model}).` : 'Unavailable: no server-side AI provider is configured.';
  }
  const badge = modalRoot.querySelector('#ai-backend-badge');
  if (badge) badge.textContent = ui.backendStatus === 'online'
    ? `Backend online · ${ui.backendHealth?.ai?.enabled ? `${ui.backendHealth.ai.provider || 'server'} model ${ui.backendHealth.ai.model} available by opt-in` : 'local catalog + public KiCad metadata'}`
    : 'Backend unavailable · local templates still work';
}

async function refreshBackendHealth() {
  try {
    const response = await fetch('/api/health', { cache: 'no-store' });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    ui.backendHealth = await response.json();
    ui.backendStatus = ui.backendHealth?.ok ? 'online' : 'offline';
  } catch {
    ui.backendHealth = null;
    ui.backendStatus = 'offline';
  }
  updateBackendIndicator();
  return ui.backendHealth;
}

function renderLibrary() {
  const categoryHolder = app.querySelector('#library-category-list');
  const list = app.querySelector('#library-list');
  if (!categoryHolder || !list) return;
  const shortcuts = [
    ['All parts', 'ALL'], ['Microcontrollers', 'MCU'], ['Sensors', 'SENS'], ['Displays', 'DISP'], ['Passives', 'PASS'], ['Power & drivers', 'PWR'],
  ];
  categoryHolder.innerHTML = shortcuts.map(([category, label]) => `<button class="category-chip ${ui.libraryCategory === category ? 'active' : ''}" data-category="${escapeHTML(category)}" title="${escapeHTML(category)}">${label}</button>`).join('');
  const query = ui.librarySearch.trim().toLowerCase();
  const filtered = LIBRARY.filter((item) => (ui.libraryCategory === 'All parts' || item.category === ui.libraryCategory) && (!query || `${item.name} ${item.sub} ${item.category} ${item.family} ${item.footprint}`.toLowerCase().includes(query)));
  app.querySelector('#library-result-count').textContent = `${filtered.length} shown`;
  list.innerHTML = filtered.map((item) => `<button class="library-item" type="button" data-lib-id="${escapeHTML(item.id)}" draggable="true" title="Click to add ${escapeHTML(item.name)} · drag to canvas">
    <span class="library-symbol symbol-${escapeHTML(item.symbol)}">${escapeHTML(item.name.slice(0, 1))}</span>
    <span class="library-item-copy"><span class="library-item-name">${escapeHTML(item.name)}</span><span class="library-item-sub">${escapeHTML(item.sub)}</span></span>
    <span class="library-add">${icon('plus', 14)}</span>
  </button>`).join('') || `<div class="library-empty">No matching parts.<br><span>Try a family, function, or footprint.</span></div>`;
}

function renderTreeAndTabs() {
  app.querySelectorAll('.tree-file[data-view]').forEach((node) => node.classList.toggle('active', node.dataset.view === ui.view));
  app.querySelectorAll('.view-tab').forEach((node) => {
    node.classList.toggle('active', node.dataset.view === ui.view);
    node.setAttribute('aria-selected', node.dataset.view === ui.view ? 'true' : 'false');
  });
  const count = app.querySelector('.project-count'); if (count) count.textContent = `${project.components.length} PARTS`;
  const stem = project.name.toLowerCase().replace(/\s+/g, '-');
  const schematicLabel = app.querySelector('.tree-file[data-view="schematic"] .tree-label');
  const pcbLabel = app.querySelector('.tree-file[data-view="pcb"] .tree-label');
  if (schematicLabel) schematicLabel.textContent = `${stem}.sch`;
  if (pcbLabel) pcbLabel.textContent = `${stem}.pcb`;
}

function renderTools() {
  const holder = app.querySelector('#view-tools');
  if (ui.view === 'firmware') {
    holder.innerHTML = `<div class="mobile-panel-tools"><button class="mobile-panel-toggle" data-action="toggle-library" title="Parts library">${icon('layers', 14)}</button><button class="mobile-panel-toggle" data-action="toggle-inspector" title="Inspector">${icon('sliders', 14)}</button></div><div class="firmware-quick-tools"><span class="firmware-runtime">${icon('code', 13)} Arduino framework · ESP32</span><button class="mini-tool" data-action="lint-firmware">${icon('check', 14)} Syntax check</button><button class="mini-tool mini-tool-accent" data-action="download-firmware">${icon('download', 14)} Download .ino</button></div>`;
    return;
  }
  if (ui.view === 'pcb') {
    holder.innerHTML = `<div class="mobile-panel-tools"><button class="mobile-panel-toggle" data-action="toggle-library" title="Parts library">${icon('layers', 14)}</button><button class="mobile-panel-toggle" data-action="toggle-inspector" title="Inspector">${icon('sliders', 14)}</button></div><div class="tool-group"><button class="tool-button active" data-tool="select" title="Select and move footprints">${icon('select', 15)}<span>Select</span></button><button class="tool-button" data-tool="pan" title="Pan · hold Space">${icon('pan', 15)}<span>Pan</span></button></div><span class="toolbar-divider"></span><button class="snap-control ${ui.snap ? 'on' : ''}" data-action="toggle-snap"><span class="snap-dot"></span> Snap <span>${ui.snap ? 'ON' : 'OFF'}</span></button><div class="zoom-control"><button data-action="zoom-out" aria-label="Zoom out">−</button><span id="zoom-readout">${Math.round(ui.zoom * 100)}%</span><button data-action="zoom-in" aria-label="Zoom in">+</button><span class="zoom-sep"></span><button class="fit-button" data-action="fit" title="Fit board">${icon('fit', 14)}</button></div><span class="toolbar-divider pcb-toolbar-divider"></span><div class="pcb-actions"><button class="mini-tool" data-action="auto-place" title="Auto-place footprints">${icon('layers', 13)} Auto-place</button><button class="mini-tool" data-action="pcb-drc" title="Run limited structural preview checks">${icon('check', 13)} Preview checks</button><button class="mini-tool mini-tool-accent" data-action="export-gerber" title="Export draft Gerber copper preview">${icon('download', 13)} Gerber</button></div>`;
    return;
  }
  holder.innerHTML = `<div class="mobile-panel-tools"><button class="mobile-panel-toggle" data-action="toggle-library" title="Parts library">${icon('layers', 14)}</button><button class="mobile-panel-toggle" data-action="toggle-inspector" title="Inspector">${icon('sliders', 14)}</button></div><div class="tool-group">
    <button class="tool-button ${ui.tool === 'select' ? 'active' : ''}" data-tool="select" title="Select · V">${icon('select', 15)}<span>Select</span></button>
    <button class="tool-button ${ui.tool === 'wire' ? 'active' : ''}" data-tool="wire" title="Wire · W">${icon('wire', 15)}<span>Wire</span></button>
    <button class="tool-button ${ui.tool === 'pan' ? 'active' : ''}" data-tool="pan" title="Pan · hold Space">${icon('pan', 15)}<span>Pan</span></button>
  </div>
  <span class="toolbar-divider"></span>
  <div class="tool-group compact-tools">
    <button class="tool-button tool-icon-only" data-action="undo" title="Undo · Ctrl+Z">${icon('undo', 15)}</button>
    <button class="tool-button tool-icon-only" data-action="redo" title="Redo · Ctrl+Shift+Z">${icon('redo', 15)}</button>
  </div>
  <span class="toolbar-divider"></span>
  <button class="snap-control ${ui.snap ? 'on' : ''}" data-action="toggle-snap"><span class="snap-dot"></span> Snap <span>${ui.snap ? 'ON' : 'OFF'}</span></button>
  <div class="zoom-control"><button data-action="zoom-out" aria-label="Zoom out">−</button><span id="zoom-readout">${Math.round(ui.zoom * 100)}%</span><button data-action="zoom-in" aria-label="Zoom in">+</button><span class="zoom-sep"></span><button class="fit-button" data-action="fit" title="Fit drawing">${icon('fit', 14)}</button></div>`;
}

function renderFirmwareStage() {
  const holder = app.querySelector('#firmware-stage');
  const code = project.firmware || generateFirmware(project);
  const lines = code.split('\n').length;
  holder.innerHTML = `<div class="firmware-editor-shell">
    <div class="firmware-editor-heading"><div class="firmware-file-icon">${icon('code', 17)}</div><div><b>main.ino</b><span>Generated scaffold · edit freely</span></div><div class="firmware-heading-right"><span class="firmware-language-pill">C++</span><span class="firmware-local-note">No compiler connected</span></div></div>
    <div class="firmware-editor"><div class="line-numbers">${Array.from({ length: lines }, (_, index) => `<span>${index + 1}</span>`).join('')}</div><textarea id="firmware-editor" spellcheck="false" aria-label="Firmware source code">${escapeHTML(code)}</textarea></div>
    <div class="firmware-hints"><span>${icon('info', 14)} Requires Arduino-ESP32 core and the libraries listed in the comments.</span><span>Static checks only · no toolchain or flashing backend</span></div>
  </div>`;
}

function renderCenter() {
  renderTreeAndTabs(); renderTools();
  const schematic = ui.view !== 'firmware';
  svg.hidden = !schematic;
  const firmwareStage = app.querySelector('#firmware-stage');
  firmwareStage.hidden = schematic;
  if (schematic) renderCanvas(svg, project, ui);
  else renderFirmwareStage();
  const stage = app.querySelector('#canvas-stage');
  stage.classList.toggle('firmware-active', !schematic);
  stage.classList.toggle('pcb-active', ui.view === 'pcb');
  const statusLeft = app.querySelector('#canvas-status-left');
  const statusRight = app.querySelector('#canvas-status-right');
  if (ui.view === 'schematic') {
    statusLeft.innerHTML = `<span class="status-crosshair">⌖</span> ${ui.pendingPin ? `Wire from ${escapeHTML(ui.pendingPin.id)} · ${escapeHTML(ui.pendingPin.pin)}` : ui.tool === 'wire' ? 'Select two pins to connect' : `${project.components.length} components · ${project.wires.length} nets`}`;
    statusRight.innerHTML = `<span>100% vector</span><span class="stage-separator"></span><span>Grid 24</span><span class="stage-separator"></span><span>Local draft</span>`;
  } else if (ui.view === 'pcb') {
    statusLeft.innerHTML = `<span class="status-crosshair">⌖</span> ${project.components.length} footprints · ${project.wires.length} net previews`;
    statusRight.innerHTML = `<span>FR-4 · 1.6 mm</span><span class="stage-separator"></span><span>2 copper layers</span><span class="stage-separator"></span><span class="pcb-stage-draft">DRAFT ONLY</span>`;
  } else {
    statusLeft.innerHTML = `<span class="status-crosshair">⌖</span> Arduino framework · ESP32 DevKit V1`;
    statusRight.innerHTML = `<span>${(project.firmware || '').split('\n').length} lines</span><span class="stage-separator"></span><span>Not compiled</span>`;
  }
}

function selectedComponents() {
  return project.components.filter((component) => ui.selectedIds.has(component.id));
}
function renderInspector() {
  const tabs = app.querySelectorAll('[data-inspector-tab]');
  tabs.forEach((tab) => tab.classList.toggle('active', tab.dataset.inspectorTab === ui.inspectorTab));
  const selected = selectedComponents();
  const selectedWire = project.wires.find((wire) => wire.id === ui.selectedWire);
  const context = app.querySelector('#inspector-context');
  const count = app.querySelector('#connection-count');
  const connectionList = describeConnections(project);
  count.textContent = String(connectionList.length);
  const content = app.querySelector('#inspector-content');
  const bottom = app.querySelector('#inspector-bottom');
  if (ui.inspectorTab === 'connections') {
    context.textContent = selected.length === 1 ? `NETS · ${selected[0].ref}` : 'NETS · PROJECT';
    const ids = new Set(selected.map((component) => component.id));
    const visible = connectionList.filter((entry) => !ids.size || project.wires.some((wire) => (wire.id === entry.id) && (ids.has(wire.from[0]) || ids.has(wire.to[0]))));
    content.innerHTML = `<div class="inspector-section-title"><span>CONNECTION MAP</span><span>${visible.length} NETS</span></div>
      <div class="connection-list">${visible.map((entry) => `<div class="connection-card"><div class="connection-card-head"><span class="net-color net-${escapeHTML(entry.color)}"></span><b>${escapeHTML(entry.net)}</b><button data-select-wire="${escapeHTML(entry.id)}" title="Select net">${icon('expand', 12)}</button></div><div class="connection-endpoints"><span>${escapeHTML(entry.from)}</span><i>→</i><span>${escapeHTML(entry.to)}</span></div><div class="connection-detail">${escapeHTML(entry.detail)}</div></div>`).join('') || `<div class="inspector-empty">No nets to show. Use the wire tool to connect two pins.</div>`}</div>`;
    bottom.innerHTML = `<div class="inspector-note">${icon('info', 14)} Connection labels and rules are inferred locally; verify every pin against its datasheet.</div>`;
    return;
  }
  if (selectedWire) {
    context.textContent = `NET · ${selectedWire.net || 'UNNAMED'}`;
    const from = project.components.find((component) => component.id === selectedWire.from[0]);
    const to = project.components.find((component) => component.id === selectedWire.to[0]);
    content.innerHTML = `<div class="selected-symbol-strip"><span class="symbol-preview wire-preview">${icon('wire', 19)}</span><div><span class="eyebrow">SCHEMATIC NET</span><h3>${escapeHTML(selectedWire.net || 'Unnamed wire')}</h3><span>${escapeHTML(selectedWire.label || 'Orthogonal connection')}</span></div></div>
      <div class="property-form"><label>Net label<input value="${escapeHTML(selectedWire.label || '')}" data-wire-field="label" placeholder="Optional net label" /></label><label>Net name<input value="${escapeHTML(selectedWire.net || '')}" data-wire-field="net" /></label><div class="wire-endpoints-edit"><span>FROM</span><b>${escapeHTML(from?.ref || '?')} · ${escapeHTML(selectedWire.from[1])}</b><span>TO</span><b>${escapeHTML(to?.ref || '?')} · ${escapeHTML(selectedWire.to[1])}</b></div></div>`;
    bottom.innerHTML = `<button class="inspector-danger-button" data-action="delete-wire">${icon('trash', 14)} Delete connection</button>`;
    return;
  }
  if (selected.length === 1) {
    const component = selected[0];
    const entry = LIBRARY.find((item) => item.id === component.libraryId);
    const pins = project.wires.filter((wire) => wire.from[0] === component.id || wire.to[0] === component.id).length;
    const position = ui.view === 'pcb' ? getBoardPositionForApp(component) : { x: component.x, y: component.y };
    const coordinateField = ui.view === 'pcb' ? 'board-field' : 'component-field';
    context.textContent = `${component.ref} · ${component.category?.toUpperCase() || 'COMPONENT'}`;
    content.innerHTML = `<div class="selected-symbol-strip"><span class="symbol-preview ${escapeHTML(component.type)}-preview">${escapeHTML(component.ref.slice(0, 1))}</span><div><span class="eyebrow">${escapeHTML(component.category || 'COMPONENT')}</span><h3>${escapeHTML(component.name)}</h3><span>${escapeHTML(component.footprint || 'No footprint assigned')}</span></div></div>
      <div class="component-health"><span class="health-icon">${icon('check', 12)}</span><span><b>${pins} visible connections</b><small>${entry ? escapeHTML(entry.family) : 'User component'} · ${escapeHTML(component.type)}</small></span><button data-action="view-connections" title="View connections">${icon('chevronRight', 14)}</button></div>
      <div class="property-form"><div class="form-section-label">IDENTIFICATION</div>
        <label>Reference<input data-component-field="ref" value="${escapeHTML(component.ref)}" /></label>
        <label>Name<input data-component-field="name" value="${escapeHTML(component.name)}" /></label>
        <label>Value / rating<input data-component-field="value" value="${escapeHTML(component.value)}" /></label>
        <div class="form-section-label form-section-spaced">${ui.view === 'pcb' ? 'PCB PLACEMENT' : 'PCB FOOTPRINT'}</div>
        <label>Footprint<input data-component-field="footprint" value="${escapeHTML(component.footprint || '')}" /></label>
        <div class="xy-row"><label>${ui.view === 'pcb' ? 'Board X' : 'Schematic X'} <input data-${coordinateField}="x" type="number" step="12" value="${Math.round(position[0] ?? position.x)}" /></label><label>${ui.view === 'pcb' ? 'Board Y' : 'Schematic Y'} <input data-${coordinateField}="y" type="number" step="12" value="${Math.round(position[1] ?? position.y)}" /></label></div>
      </div>`;
    bottom.innerHTML = `<div class="inspector-actions"><button data-action="duplicate">${icon('copy', 14)} Duplicate</button><button data-action="delete-selection" class="danger-subtle">${icon('trash', 14)} Remove</button></div><div class="inspector-footnote">${icon('info', 13)} Confirm package dimensions and pin numbering against the manufacturer datasheet.</div>`;
    return;
  }
  if (selected.length > 1) {
    context.textContent = `${selected.length} ITEMS SELECTED`;
    content.innerHTML = `<div class="multi-select-card"><span class="multi-select-icon">${icon('layers', 20)}</span><b>${selected.length} components selected</b><p>Drag to move as a group, duplicate, or align their centers.</p></div><div class="property-form"><div class="form-section-label">ARRANGE</div><button class="wide-action-button" data-action="align-horizontal">${icon('sliders', 14)} Align horizontal centers</button><button class="wide-action-button" data-action="align-vertical">${icon('sliders', 14)} Align vertical centers</button></div>`;
    bottom.innerHTML = `<div class="inspector-actions"><button data-action="duplicate">${icon('copy', 14)} Duplicate</button><button data-action="delete-selection" class="danger-subtle">${icon('trash', 14)} Remove</button></div>`;
    return;
  }
  context.textContent = 'PROJECT SETTINGS';
  const check = validateDesign(project);
  content.innerHTML = `<div class="project-inspector-hero"><div class="project-hero-icon">${icon('circuit', 21)}</div><div><span class="eyebrow">ENGINEERING PROJECT</span><h3>${escapeHTML(project.name)}</h3><p>${escapeHTML(project.description || 'Local design workspace')}</p></div></div>
    <div class="summary-metrics"><div><b>${project.components.length}</b><span>PARTS</span></div><div><b>${project.wires.length}</b><span>NETS</span></div><div><b>${check.counts.errors}</b><span>ERRORS</span></div></div>
    <div class="inspector-section-title"><span>DESIGN REVIEW</span><span>${check.counts.warnings} NOTES</span></div>
    <div class="review-list">${designSuggestions(project).slice(0, 5).map((item) => `<div class="review-row"><span class="review-dot ${item.type}"></span><div><b>${escapeHTML(item.title)}</b><p>${escapeHTML(item.text)}</p></div></div>`).join('')}</div>`;
  bottom.innerHTML = `<button class="inspector-primary-button" data-action="ai-open">${icon('spark', 14)} Ask design assistant</button><div class="inspector-footnote">${icon('info', 13)} Browser-local prototype · not a substitute for ERC / DRC sign-off.</div>`;
}

function renderConsole() {
  const body = app.querySelector('#dock-body');
  app.querySelectorAll('.dock-tab').forEach((tab) => tab.classList.toggle('active', tab.dataset.consoleTab === ui.consoleTab));
  const check = validateDesign(project);
  app.querySelector('#check-count').textContent = check.counts.errors ? String(check.counts.errors) : check.counts.warnings ? String(check.counts.warnings) : 'OK';
  app.querySelector('#check-count').classList.toggle('has-warnings', check.counts.warnings > 0 || check.counts.errors > 0);
  if (ui.consoleTab === 'console') {
    const lines = ui.consoleLines;
    body.innerHTML = `<div class="console-output" role="log" aria-live="polite">${lines.map((line) => `<div class="console-line ${escapeHTML(line.kind || 'meta')}"><span class="console-chevron">${line.kind === 'error' ? '×' : line.kind === 'success' ? '✓' : line.kind === 'warning' ? '!' : '›'}</span><span>${escapeHTML(line.text)}</span></div>`).join('')}</div><div class="console-hint">${icon('info', 13)} Behavioral sample values are illustrative, not a SPICE result or hardware measurement.</div>`;
  } else if (ui.consoleTab === 'waveforms') {
    if (!ui.simulation) {
      body.innerHTML = `<div class="dock-empty"><div class="empty-wave-icon">${icon('activity', 21)}</div><b>Waveform viewer is idle</b><span>Run the behavioral preview to see example signal traces.</span><button data-action="simulate" class="small-accent-button">${icon('play', 13)} Run preview</button></div>`;
    } else {
      const { points, sensorName } = ui.simulation.waves;
      const pathFor = (key) => points.map((point, index) => `${index ? 'L' : 'M'}${22 + point.x * 670},${14 + (1 - point[key]) * 87}`).join(' ');
      body.innerHTML = `<div class="waveform-view"><div class="waveform-legend"><span><i class="wave-teal"></i>${escapeHTML(sensorName)}</span><span><i class="wave-orange"></i>RH / status</span><span><i class="wave-purple"></i>GPIO output</span><em>Behavioral preview · arbitrary units</em></div><svg viewBox="0 0 710 118" class="wave-chart" role="img" aria-label="Example waveform traces"><path class="wave-grid-line" d="M22 20H690M22 48H690M22 77H690M22 105H690M22 20V105M156 20V105M290 20V105M424 20V105M558 20V105M690 20V105"/><path class="wave-line wave-line-teal" d="${pathFor('temperature')}"/><path class="wave-line wave-line-orange" d="${pathFor('humidity')}"/><path class="wave-line wave-line-purple" d="${pathFor('digital')}"/></svg><div class="wave-axis"><span>0 s</span><span>2 s</span><span>4 s</span><span>6 s</span><span>8 s</span><span>10 s</span></div></div>`;
    }
  } else if (ui.consoleTab === 'instruments') {
    const serialLines = ui.consoleLines.filter((line) => line.kind === 'output').slice(-3);
    const simulated = Boolean(ui.simulation);
    body.innerHTML = `<div class="instrument-view"><div class="instrument-card meter-card"><div class="instrument-card-head">${icon('flash', 14)} <b>DC MULTIMETER</b><span>V⎓</span></div><div class="meter-reading">${simulated ? '3.30' : '—.——'}<small>V</small></div><div class="meter-channel"><span class="meter-led"></span>3V3 rail <span>${simulated ? 'assumed' : 'idle'}</span></div><div class="meter-channel"><span class="meter-ground-led"></span>GND reference <span>COMMON</span></div></div><div class="instrument-card logic-card"><div class="instrument-card-head">${icon('activity', 14)} <b>LOGIC ANALYZER</b><span>3.3 V TTL</span></div><div class="logic-row"><i class="logic-ch teal"></i><b>CH 0</b><span>${escapeHTML(/soil|irrigation/i.test(project.name) ? 'GPIO34 · ADC1' : 'GPIO21 · SDA')}</span><em>${simulated ? 'SAMPLE' : 'ARMED'}</em></div><div class="logic-row"><i class="logic-ch orange"></i><b>CH 1</b><span>${escapeHTML(/soil|irrigation/i.test(project.name) ? 'GPIO26 · PUMP_EN' : 'GPIO22 · SCL')}</span><em>${simulated ? 'SAMPLE' : 'ARMED'}</em></div><div class="logic-row"><i class="logic-ch purple"></i><b>CH 2</b><span>GPIO2 · STATUS</span><em>${simulated ? 'SAMPLE' : 'ARMED'}</em></div><div class="logic-note">Pin activity is illustrative; no digital simulator is connected.</div></div><div class="instrument-card serial-card"><div class="instrument-card-head">${icon('terminal', 14)} <b>SERIAL MONITOR</b><span>115200 baud</span></div><div class="serial-lines">${serialLines.length ? serialLines.map((line) => `<span>${escapeHTML(line.text)}</span>`).join('') : `<span class="serial-placeholder">Waiting for preview output…</span>`}</div><div class="serial-status"><i></i>${simulated ? 'Local sample stream' : 'Disconnected'} <span>UTF-8</span></div></div><div class="instrument-disclaimer">${icon('info', 13)} Instrument readings are mock/assumed values from the local behavioral preview—not electrical measurements. Signal generator and SPICE instruments require a simulation backend.</div></div>`;
  } else {
    body.innerHTML = `<div class="checks-view"><div class="checks-summary"><span class="checks-summary-icon ${check.counts.errors ? 'error' : 'pass'}">${icon(check.counts.errors ? 'x' : 'check', 15)}</span><div><b>${check.summary}</b><span>${check.counts.errors} blocking · ${check.counts.warnings} review notes · ${check.counts.info} suggestions</span></div><button data-action="run-checks">Re-run</button></div><div class="checks-grid">${[...check.issues.map((issue) => ({ ...issue, title: issue.code, text: issue.text, type: issue.severity })), ...check.suggestions.map((suggestion) => ({ title: suggestion.title, text: suggestion.text, type: suggestion.type }))].map((item) => `<div class="check-card ${escapeHTML(item.type)}"><span class="check-card-mark">${item.type === 'error' ? '×' : item.type === 'verified' ? '✓' : '!'}</span><div><b>${escapeHTML(item.title)}</b><p>${escapeHTML(item.text)}</p></div></div>`).join('')}</div><div class="checks-disclaimer">${icon('info', 13)} Local structural checks only. Not an electrical rule checker, SPICE solver, or manufacturing sign-off.</div></div>`;
  }
}

function renderAll() {
  renderHeader(); renderLibrary(); renderCenter(); renderInspector(); renderConsole();
}

function setView(view) {
  ui.view = view;
  ui.pendingPin = null;
  project.activeView = view;
  renderAll();
  persistProject();
}

function findOpenPosition(component) {
  const size = getComponentSize(component);
  const xs = component.type === 'mcu' ? [520, 40, 210, 700, 300, 80] : [40, 530, 870, 220, 600, 330, 760];
  const ys = component.type === 'mcu' ? [70, 80, 240, 150, 490, 90] : [70, 80, 250, 475, 140, 360, 520];
  for (const y of ys) for (const x of xs) {
    if (x < 8 || y < 8 || x + size.w > 986 || y + size.h > 630) continue;
    const overlaps = project.components.some((other) => {
      const otherSize = getComponentSize(other);
      return x < other.x + otherSize.w + 12 && x + size.w + 12 > other.x && y < other.y + otherSize.h + 12 && y + size.h + 12 > other.y;
    });
    if (!overlaps) return { x, y };
  }
  return { x: 48, y: 70 };
}
function addPart(item, x = null, y = null) {
  if (!item) return;
  const count = project.components.length;
  const component = createComponentFromLibrary(item, count, x, y);
  if (x === null || y === null) Object.assign(component, findOpenPosition(component));
  const prefix = component.ref;
  component.ref = nextReference(project.components, prefix);
  if (ui.snap) { component.x = Math.round(component.x / 12) * 12; component.y = Math.round(component.y / 12) * 12; }
  project.components.push(component);
  ui.selectedIds = new Set([component.id]); ui.selectedWire = null;
  if (!project.firmware) project.firmware = generateFirmware(project);
  addHistory(`Add ${component.ref}`);
  toast(`${component.name} added`);
}

function partDropPosition(event) {
  const point = canvasPoint(event.clientX, event.clientY);
  return scenePoint(point);
}
function addPartAtDrop(item, event) {
  const world = partDropPosition(event);
  const size = item.symbol === 'mcu' ? [174, 380] : item.symbol === 'display' ? [146, 134] : item.symbol === 'sensor' ? [146, 118] : [130, 90];
  addPart(item, Math.max(12, world.x - size[0] / 2), Math.max(12, world.y - size[1] / 2));
}

function setInspectorTab(tab) { ui.inspectorTab = tab; renderInspector(); }
function setConsoleTab(tab) { ui.consoleTab = tab; renderConsole(); }

function autoRoute(a, b) {
  const midX = Math.round((a.x + b.x) / 2 / 12) * 12;
  return [{ x: midX, y: a.y }, { x: midX, y: b.y }];
}
function guessNet(fromPin, toPin) {
  const joined = `${fromPin} ${toPin}`.toUpperCase();
  if (/GND/.test(joined)) return { net: 'GND', color: 'ground' };
  if (/3V3|VCC|5V|VIN/.test(joined)) return { net: /5V|VIN/.test(joined) ? '5V' : '3V3', color: 'power' };
  return { net: `NET_${project.wires.length + 1}`, color: 'signal' };
}
function connectPins(first, second) {
  if (first.componentId === second.componentId && first.pin === second.pin) return;
  const componentA = project.components.find((component) => component.id === first.componentId);
  const componentB = project.components.find((component) => component.id === second.componentId);
  if (!componentA || !componentB) return;
  if (project.wires.some((wire) => wire.from[0] === first.componentId && wire.from[1] === first.pin && wire.to[0] === second.componentId && wire.to[1] === second.pin)) {
    ui.pendingPin = null; renderCenter(); return toast('These pins are already connected');
  }
  const a = getPinAnchor(componentA, first.pin); const b = getPinAnchor(componentB, second.pin);
  const guess = guessNet(first.pin, second.pin);
  project.wires.push({ id: `W${Date.now().toString(36)}`, from: [first.componentId, first.pin], to: [second.componentId, second.pin], net: guess.net, color: guess.color, waypoints: autoRoute(a, b) });
  ui.pendingPin = null;
  addHistory(`Connect ${first.pin} to ${second.pin}`);
  toast(`Connection added · ${guess.net}`);
}

function canvasPoint(clientX, clientY) {
  const point = svg.createSVGPoint(); point.x = clientX; point.y = clientY;
  const matrix = svg.getScreenCTM();
  if (!matrix) return { x: 500, y: 340 };
  const mapped = point.matrixTransform(matrix.inverse());
  return { x: mapped.x, y: mapped.y };
}
function scenePoint(canvas) { return { x: (canvas.x - ui.panX) / ui.zoom, y: (canvas.y - ui.panY) / ui.zoom }; }
function zoomAround(factor, canvasX = 500, canvasY = 340) {
  const point = { x: (canvasX - ui.panX) / ui.zoom, y: (canvasY - ui.panY) / ui.zoom };
  ui.zoom = Math.min(2.3, Math.max(0.45, ui.zoom * factor));
  ui.panX = canvasX - point.x * ui.zoom;
  ui.panY = canvasY - point.y * ui.zoom;
  renderCenter();
}
function startWireFromPin(target) {
  const current = { componentId: target.dataset.componentId, pin: target.dataset.pinId };
  if (!ui.pendingPin) {
    ui.pendingPin = current;
    ui.selectedIds = new Set([current.componentId]); ui.selectedWire = null;
    renderCenter(); renderInspector();
    toast(`Start point: ${current.pin} · select a destination pin`);
  } else {
    connectPins(ui.pendingPin, current);
  }
}

svg.addEventListener('pointerdown', (event) => {
  const pinTarget = event.target.closest?.('.pin');
  if (pinTarget) { event.stopPropagation(); return; }
  if (event.button === 1 || ui.tool === 'pan' || ui.spaceDown) {
    event.preventDefault();
    ui.drag = { kind: 'pan', pointerId: event.pointerId, start: canvasPoint(event.clientX, event.clientY), panX: ui.panX, panY: ui.panY };
    svg.setPointerCapture?.(event.pointerId);
    return;
  }
  if (ui.view === 'schematic' && ui.tool !== 'select') return;
  const componentNode = event.target.closest?.('[data-component-id]');
  if (componentNode && ui.view !== 'firmware') {
    const id = componentNode.dataset.componentId;
    if (event.shiftKey) {
      if (ui.selectedIds.has(id)) ui.selectedIds.delete(id); else ui.selectedIds.add(id);
    } else if (!ui.selectedIds.has(id)) ui.selectedIds = new Set([id]);
    ui.selectedWire = null;
    if (ui.view === 'schematic') {
      const selected = project.components.filter((component) => ui.selectedIds.has(component.id));
      const startPositions = new Map(selected.map((component) => [component.id, { x: component.x, y: component.y }]));
      ui.drag = { kind: 'components', pointerId: event.pointerId, start: canvasPoint(event.clientX, event.clientY), startPositions };
    } else {
      const selected = project.components.filter((component) => ui.selectedIds.has(component.id));
      for (const component of selected) if (!project.boardPositions[component.id]) project.boardPositions[component.id] = clone(getBoardPositionForApp(component));
      const startPositions = new Map(selected.map((component) => [component.id, clone(project.boardPositions[component.id])]));
      ui.drag = { kind: 'board-components', pointerId: event.pointerId, start: canvasPoint(event.clientX, event.clientY), startPositions };
    }
    svg.setPointerCapture?.(event.pointerId);
    renderInspector(); renderCanvas(svg, project, ui);
    return;
  }
  const wireNode = event.target.closest?.('[data-wire-id]');
  if (wireNode) return;
  ui.drag = null;
  if (!event.shiftKey) { ui.selectedIds.clear(); ui.selectedWire = null; ui.pendingPin = null; renderInspector(); renderCanvas(svg, project, ui); }
});

svg.addEventListener('pointermove', (event) => {
  if (!ui.drag || ui.drag.pointerId !== event.pointerId) return;
  const current = canvasPoint(event.clientX, event.clientY);
  if (ui.drag.kind === 'pan') {
    ui.panX = ui.drag.panX + current.x - ui.drag.start.x;
    ui.panY = ui.drag.panY + current.y - ui.drag.start.y;
    renderCanvas(svg, project, ui); return;
  }
  const factor = 1 / ui.zoom;
  let dx = (current.x - ui.drag.start.x) * factor;
  let dy = (current.y - ui.drag.start.y) * factor;
  if (ui.snap) { dx = Math.round(dx / 12) * 12; dy = Math.round(dy / 12) * 12; }
  for (const [id, start] of ui.drag.startPositions) {
    if (ui.drag.kind === 'components') {
      const component = project.components.find((entry) => entry.id === id);
      if (component) { component.x = Math.max(0, Math.min(900, start.x + dx)); component.y = Math.max(0, Math.min(580, start.y + dy)); }
    } else {
      project.boardPositions[id] = [Math.max(190, Math.min(830, start[0] + dx)), Math.max(150, Math.min(540, start[1] + dy))];
    }
  }
  renderCanvas(svg, project, ui);
});
svg.addEventListener('pointerup', (event) => {
  if (!ui.drag || ui.drag.pointerId !== event.pointerId) return;
  const kind = ui.drag.kind;
  ui.drag = null;
  if (kind === 'components' || kind === 'board-components') addHistory(kind === 'components' ? 'Move components' : 'Move PCB footprints');
  else renderCenter();
});
svg.addEventListener('pointercancel', () => { ui.drag = null; renderCanvas(svg, project, ui); });
svg.addEventListener('click', (event) => {
  const pin = event.target.closest?.('.pin');
  if (pin && ui.view === 'schematic' && ui.tool === 'wire') { startWireFromPin(pin); return; }
  const wire = event.target.closest?.('[data-wire-id]');
  if (wire && ui.view === 'schematic') {
    ui.selectedWire = wire.dataset.wireId; ui.selectedIds.clear(); ui.inspectorTab = 'properties';
    renderCanvas(svg, project, ui); renderInspector(); return;
  }
});
svg.addEventListener('wheel', (event) => {
  event.preventDefault();
  const point = canvasPoint(event.clientX, event.clientY);
  zoomAround(event.deltaY < 0 ? 1.08 : 0.92, point.x, point.y);
}, { passive: false });
svg.addEventListener('dragover', (event) => event.preventDefault());
svg.addEventListener('drop', (event) => {
  event.preventDefault();
  if (ui.view !== 'schematic') return;
  const item = LIBRARY.find((entry) => entry.id === event.dataTransfer?.getData('text/component-id'));
  if (item) addPartAtDrop(item, event);
});

app.querySelector('#library-search').addEventListener('input', (event) => { ui.librarySearch = event.target.value; renderLibrary(); });
app.addEventListener('dragstart', (event) => {
  const item = event.target.closest?.('[data-lib-id]');
  if (item) { event.dataTransfer.setData('text/component-id', item.dataset.libId); event.dataTransfer.effectAllowed = 'copy'; }
});
app.addEventListener('click', (event) => {
  const category = event.target.closest?.('[data-category]');
  if (category) { ui.libraryCategory = category.dataset.category; renderLibrary(); return; }
  const libraryItem = event.target.closest?.('[data-lib-id]');
  if (libraryItem && !event.defaultPrevented) { addPart(LIBRARY.find((item) => item.id === libraryItem.dataset.libId)); return; }
  const viewButton = event.target.closest?.('[data-view]');
  if (viewButton) { setView(viewButton.dataset.view); return; }
  const toolButton = event.target.closest?.('[data-tool]');
  if (toolButton) { ui.tool = toolButton.dataset.tool; ui.pendingPin = null; renderTools(); renderCenter(); return; }
  const inspectorTab = event.target.closest?.('[data-inspector-tab]');
  if (inspectorTab) { setInspectorTab(inspectorTab.dataset.inspectorTab); return; }
  const consoleTab = event.target.closest?.('[data-console-tab]');
  if (consoleTab) { setConsoleTab(consoleTab.dataset.consoleTab); return; }
  const selectWire = event.target.closest?.('[data-select-wire]');
  if (selectWire) { ui.selectedWire = selectWire.dataset.selectWire; ui.selectedIds.clear(); ui.inspectorTab = 'properties'; renderInspector(); renderCanvas(svg, project, ui); return; }
  const action = event.target.closest?.('[data-action]')?.dataset.action;
  if (action) handleAction(action, event);
  const exportItem = event.target.closest?.('[data-export]');
  if (exportItem) { runExport(exportItem.dataset.export); return; }
  const quickPrompt = event.target.closest?.('[data-prompt]');
  if (quickPrompt) { const prompt = modalRoot.querySelector('#ai-prompt'); if (prompt) { prompt.value = quickPrompt.dataset.prompt; prompt.focus(); } return; }
  if (event.target === modalRoot) closeModal();
});

app.addEventListener('focusin', (event) => {
  const field = event.target.closest?.('[data-component-field]');
  const component = selectedComponents()[0];
  if (field && component) field.dataset.originalValue = String(component[field.dataset.componentField] ?? '');
});
app.addEventListener('change', (event) => {
  const boardField = event.target.closest?.('[data-board-field]');
  if (boardField) {
    const component = selectedComponents()[0];
    if (!component) return;
    const pos = project.boardPositions[component.id] || clone(getBoardPositionForApp(component));
    const axis = boardField.dataset.boardField === 'x' ? 0 : 1;
    let value = Number(boardField.value);
    if (ui.snap) value = Math.round(value / 12) * 12;
    pos[axis] = Math.max(185, Math.min(axis === 0 ? 835 : 545, value));
    project.boardPositions[component.id] = pos;
    addHistory(`Edit ${component.ref} PCB placement`);
    return;
  }
  const field = event.target.closest?.('[data-component-field]');
  if (field) {
    const component = selectedComponents()[0];
    if (!component) return;
    const key = field.dataset.componentField;
    let value = field.value;
    if (key === 'x' || key === 'y') value = Number(value);
    if (key === 'ref' && project.components.some((item) => item.id !== component.id && item.ref === value)) { const previous = field.dataset.originalValue ?? component.ref; component.ref = previous; field.value = previous; toast('Reference already in use'); renderCanvas(svg, project, ui); return; }
    component[key] = value;
    if (key === 'x' || key === 'y') { if (ui.snap) component[key] = Math.round(component[key] / 12) * 12; }
    addHistory(`Edit ${component.ref}`);
    return;
  }
  const wireField = event.target.closest?.('[data-wire-field]');
  if (wireField && ui.selectedWire) {
    const wire = project.wires.find((entry) => entry.id === ui.selectedWire);
    if (wire) { wire[wireField.dataset.wireField] = wireField.value; addHistory('Edit connection'); }
  }
});
app.addEventListener('input', (event) => {
  const field = event.target.closest?.('[data-component-field]');
  if (!field) return;
  const component = selectedComponents()[0];
  if (!component) return;
  const key = field.dataset.componentField;
  if (key === 'x' || key === 'y') return;
  component[key] = field.value;
  setDirty();
  renderCanvas(svg, project, ui);
});

app.addEventListener('keydown', (event) => {
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's') {
    event.preventDefault();
    const editor = app.querySelector('#firmware-editor'); if (editor) project.firmware = editor.value;
    saveVersion(); return;
  }
  if (event.target.matches('input, textarea, [contenteditable="true"]')) return;
  if (event.key === 'Escape') { closeModal(); ui.pendingPin = null; ui.drag = null; renderCenter(); return; }
  if (event.code === 'Space') { ui.spaceDown = true; event.preventDefault(); return; }
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'z') { event.preventDefault(); event.shiftKey ? redo() : undo(); return; }
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'y') { event.preventDefault(); redo(); return; }
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'a' && ui.view !== 'firmware') { event.preventDefault(); ui.selectedIds = new Set(project.components.map((component) => component.id)); ui.selectedWire = null; renderInspector(); renderCanvas(svg, project, ui); return; }
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'c') { copiedComponents = selectedComponents().map((item) => clone(item)); if (copiedComponents.length) toast(`${copiedComponents.length} component(s) copied`); return; }
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'v') { duplicateSelected(true); return; }
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'd') { event.preventDefault(); duplicateSelected(); return; }
  if (event.key === 'Delete' || event.key === 'Backspace') { deleteSelection(); return; }
  if (event.key.toLowerCase() === 'w' && ui.view === 'schematic') { ui.tool = 'wire'; ui.pendingPin = null; renderCenter(); return; }
  if (event.key.toLowerCase() === 'v' && ui.view !== 'firmware') { ui.tool = 'select'; renderCenter(); return; }
  if (event.key === '/' && ui.view !== 'firmware') { app.querySelector('#library-search').focus(); event.preventDefault(); }
});
document.addEventListener('keyup', (event) => { if (event.code === 'Space') ui.spaceDown = false; });

function getBoardPositionForApp(component) {
  const presets = { U1: [390, 338], OLED1: [672, 240], U2: [672, 410], R1: [535, 332], R2: [538, 495], D1: [724, 496], C1: [470, 370], K1: [710, 490] };
  return project.boardPositions?.[component.id] || presets[component.id] || [250 + (project.components.indexOf(component) % 4) * 130, 260 + Math.floor(project.components.indexOf(component) / 4) * 105];
}

function deleteSelection() {
  if (ui.selectedWire) {
    project.wires = project.wires.filter((wire) => wire.id !== ui.selectedWire);
    ui.selectedWire = null; addHistory('Delete connection'); toast('Connection removed'); return;
  }
  if (!ui.selectedIds.size) return;
  const removed = ui.selectedIds.size;
  const ids = new Set(ui.selectedIds);
  project.components = project.components.filter((component) => !ids.has(component.id));
  project.wires = project.wires.filter((wire) => !ids.has(wire.from[0]) && !ids.has(wire.to[0]));
  ui.selectedIds.clear(); addHistory(`Remove ${removed} component(s)`); toast(`${removed} component(s) removed`);
}
function duplicateSelected(pasteClipboard = false) {
  const source = pasteClipboard ? copiedComponents : selectedComponents();
  if (!source.length) return;
  const inserted = source.map((entry, index) => {
    const item = clone(entry); item.id = `C${Date.now().toString(36)}${index}${Math.random().toString(36).slice(2, 5)}`;
    const prefix = item.ref.replace(/\d+$/, '') || 'U'; item.ref = nextReference(project.components, prefix);
    item.x = Math.min(880, Number(item.x) + 36); item.y = Math.min(590, Number(item.y) + 36);
    project.components.push(item); return item;
  });
  ui.selectedIds = new Set(inserted.map((item) => item.id)); ui.selectedWire = null;
  addHistory(`Duplicate ${inserted.length} component(s)`); toast(`${inserted.length} component(s) duplicated`);
}
function alignSelection(axis) {
  const selected = selectedComponents(); if (selected.length < 2) return;
  if (ui.view === 'pcb') {
    const items = selected.map((component) => ({ component, pos: clone(getBoardPositionForApp(component)) }));
    const target = items.reduce((sum, item) => sum + (axis === 'horizontal' ? item.pos[1] : item.pos[0]), 0) / items.length;
    for (const item of items) {
      const pos = item.pos;
      if (axis === 'horizontal') pos[1] = target; else pos[0] = target;
      if (ui.snap) { pos[0] = Math.round(pos[0] / 12) * 12; pos[1] = Math.round(pos[1] / 12) * 12; }
      project.boardPositions[item.component.id] = pos;
    }
  } else {
    const centers = selected.map((component) => {
      const size = getComponentSize(component);
      return { component, centerX: component.x + size.w / 2, centerY: component.y + size.h / 2 };
    });
    const x = centers.reduce((sum, item) => sum + item.centerX, 0) / centers.length;
    const y = centers.reduce((sum, item) => sum + item.centerY, 0) / centers.length;
    for (const item of centers) {
      const size = getComponentSize(item.component);
      if (axis === 'horizontal') item.component.y = y - size.h / 2;
      else item.component.x = x - size.w / 2;
      if (ui.snap) { item.component.x = Math.round(item.component.x / 12) * 12; item.component.y = Math.round(item.component.y / 12) * 12; }
    }
  }
  addHistory(`Align ${axis}`);
}

function runSimulation() {
  const result = simulateBehavior(project);
  ui.simulation = result;
  ui.consoleLines = result.lines;
  ui.consoleTab = 'console';
  renderConsole();
  app.querySelector('.console-dock').classList.add('just-ran');
  setTimeout(() => app.querySelector('.console-dock')?.classList.remove('just-ran'), 950);
  toast('Behavioral preview complete · illustrative values only');
}
function runChecks() {
  const result = validateDesign(project);
  ui.consoleTab = 'checks'; renderConsole();
  toast(`${result.summary} · ${result.counts.warnings} review notes`);
}
function autoPlaceBoard() {
  const presets = { U1: [390, 338], OLED1: [672, 240], U2: [672, 410], R1: [535, 332], R2: [538, 495], D1: [724, 496], C1: [470, 370], K1: [710, 490] };
  project.boardPositions ||= {};
  project.components.forEach((component, index) => {
    const position = presets[component.id] || [260 + (index % 4) * 135, 250 + Math.floor(index / 4) * 100];
    project.boardPositions[component.id] = [...position];
  });
  addHistory('Auto-place PCB footprints');
  toast('Footprints arranged · inspect clearances and routes');
}
function runPcbChecks() {
  ui.consoleTab = 'checks'; renderConsole();
  const result = validateDesign(project);
  toast(`Preview only · ${result.counts.errors} structural errors, ${result.counts.warnings} review notes`);
}

function showModal(content, size = 'normal') {
  modalRoot.innerHTML = `<div class="modal-backdrop"><div class="modal-card ${size === 'wide' ? 'modal-wide' : ''}" role="dialog" aria-modal="true">${content}</div></div>`;
  modalRoot.querySelector('.modal-backdrop').addEventListener('click', (event) => { if (event.target === event.currentTarget) closeModal(); });
}
function closeModal() { modalRoot.innerHTML = ''; }
function openIntegrationsModal() {
  ui.tinkercadCsvText = '';
  ui.tinkercadFileName = '';
  ui.tinkercadRows = [];
  showModal(`<div class="modal-header"><div class="modal-icon export-modal-icon">${icon('activity', 17)}</div><div><span class="modal-eyebrow">BACKEND · PUBLIC COMPONENT DATA</span><h2>Backend & integrations</h2></div><button class="modal-close" data-action="close-modal">${icon('x', 17)}</button></div>
    <div class="integration-modal-body"><div class="backend-summary" id="integration-backend-status"><span class="backend-pulse"></span> Checking local backend…</div>
      <div class="ai-diagnostics" id="integration-ai-test" hidden></div>
      <div class="integration-grid" id="integration-cards"><div class="integration-loading">Loading documented integration routes…</div></div>
      <section class="tinkercad-import-card"><div class="integration-section-heading"><span class="integration-section-icon">${icon('download', 15)}</span><div><b>Tinkercad Circuits · component-list CSV</b><small>User-authorized export bridge · no account connection</small></div></div>
        <p>In Tinkercad, export the component list CSV, then select it here. Circuit Studio normalizes the BOM and suggests likely catalog matches; it cannot recover wiring or a full project.</p>
        <input id="tinkercad-bom-file" type="file" accept=".csv,text/csv" hidden />
        <div class="tinkercad-file-row"><button class="secondary-button" data-action="choose-tinkercad-file">Choose CSV</button><span class="tinkercad-file-name" id="tinkercad-file-name">No file selected</span><button class="primary-button" data-action="import-tinkercad-bom" id="tinkercad-import-button" disabled>Normalize BOM</button></div>
        <div class="tinkercad-import-result" id="tinkercad-import-result"><span class="integration-empty-state">Select a Tinkercad component-list CSV to see row-level matches.</span></div>
      </section>
    </div><div class="modal-footer"><span>Public source metadata is attributed · verify exact datasheets</span><div><button class="secondary-button" data-action="close-modal">Close</button></div></div>`, 'wide');
  refreshIntegrationsModal();
}

async function refreshIntegrationsModal() {
  const statusNode = modalRoot.querySelector('#integration-backend-status');
  const cardsNode = modalRoot.querySelector('#integration-cards');
  if (!statusNode || !cardsNode) return;
  try {
    const [healthResponse, integrationsResponse] = await Promise.all([fetch('/api/health', { cache: 'no-store' }), fetch('/api/integrations', { cache: 'no-store' })]);
    if (!healthResponse.ok || !integrationsResponse.ok) throw new Error('Backend API did not respond successfully');
    const [health, integrations] = await Promise.all([healthResponse.json(), integrationsResponse.json()]);
    ui.backendHealth = health;
    ui.backendStatus = health?.ok ? 'online' : 'offline';
    updateBackendIndicator();
    const modelText = health?.ai?.enabled ? `Configured ${escapeHTML(health.ai.provider || 'server')} model: ${escapeHTML(health.ai.model)} · user opt-in only` : 'Server-side AI is not configured';
    statusNode.innerHTML = `<span class="backend-state-mark online">${icon('check', 12)}</span><div><b>Circuit Studio API online</b><small>${health.catalog?.count || LIBRARY.length} local catalog records · ${modelText}</small></div><button class="integration-test-ai" data-action="test-ai-provider" ${health?.ai?.enabled ? '' : 'disabled'}>${health?.ai?.enabled ? 'Test AI' : 'AI not set'}</button><button class="integration-refresh" data-action="refresh-integrations">Refresh</button>`;
    const labels = {
      catalog: 'Local starter catalog', kicad: 'Open component metadata',
      tinkercad: 'Authorized CSV import only', cirkit: 'Documented extension API only',
    };
    cardsNode.innerHTML = (integrations.items || []).map((item) => `<article class="integration-card"><div class="integration-card-head"><b>${escapeHTML(item.title)}</b><span class="integration-state ${item.id}">${escapeHTML(labels[item.id] || item.status)}</span></div><p>${escapeHTML(item.description || '')}</p><div class="integration-card-links">${item.url ? `<a href="${escapeHTML(item.url)}" target="_blank" rel="noopener noreferrer">Product / source ↗</a>` : ''}${item.docsUrl ? `<a href="${escapeHTML(item.docsUrl)}" target="_blank" rel="noopener noreferrer">Docs ↗</a>` : ''}${item.licenseUrl ? `<a href="${escapeHTML(item.licenseUrl)}" target="_blank" rel="noopener noreferrer">${escapeHTML(item.license || 'License')} ↗</a>` : ''}</div></article>`).join('');
  } catch (error) {
    ui.backendHealth = null;
    ui.backendStatus = 'offline';
    updateBackendIndicator();
    statusNode.innerHTML = `<span class="backend-state-mark offline">${icon('x', 12)}</span><div><b>Backend unavailable</b><small>${escapeHTML(error.message || 'Start Circuit Studio with npm run dev to enable API routes.')}</small></div><button class="integration-refresh" data-action="refresh-integrations">Retry</button>`;
    cardsNode.innerHTML = `<div class="integration-offline-note">The app can still use its browser-local templates and saved projects. Start the Node backend to enable public KiCad search, server-side BOM normalization, and integration status.</div>`;
  }
}

async function testAIProvider() {
  const holder = modalRoot.querySelector('#integration-ai-test');
  const button = modalRoot.querySelector('[data-action="test-ai-provider"]');
  if (!holder) return;
  holder.hidden = false;
  holder.innerHTML = `<span class="backend-pulse"></span><span>Testing the configured model endpoint with a short, project-free prompt…</span>`;
  if (button) { button.disabled = true; button.textContent = 'Testing…'; }
  try {
    const response = await fetch('/api/ai/test', { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || `Test failed (HTTP ${response.status})`);
    holder.classList.toggle('success', result.ok === true);
    holder.classList.toggle('failure', result.ok !== true);
    holder.innerHTML = `<b>${result.ok ? 'Model connection succeeded' : 'Model connection failed'}</b><span>${escapeHTML(result.error || `${result.provider} · ${result.model} · ${result.latencyMs} ms`)}</span>`;
  } catch (error) {
    holder.classList.remove('success'); holder.classList.add('failure');
    holder.innerHTML = `<b>Could not run model diagnostics</b><span>${escapeHTML(error.message || 'Backend is unavailable.')}</span>`;
  } finally {
    if (button) { button.disabled = false; button.textContent = 'Test AI'; }
  }
}

async function importTinkercadBom() {
  if (!ui.tinkercadCsvText) return toast('Choose a component-list CSV first');
  const button = modalRoot.querySelector('#tinkercad-import-button');
  const resultNode = modalRoot.querySelector('#tinkercad-import-result');
  if (button) { button.disabled = true; button.textContent = 'Working…'; }
  if (resultNode) resultNode.innerHTML = `<span class="integration-empty-state">Sending the selected CSV to the local backend…</span>`;
  try {
    const response = await fetch('/api/import/tinkercad-bom', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ csv: ui.tinkercadCsvText }) });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || `Import failed (HTTP ${response.status})`);
    ui.tinkercadRows = Array.isArray(result.rows) ? result.rows : [];
    renderTinkercadImportResult(result);
  } catch (error) {
    ui.tinkercadRows = [];
    if (resultNode) resultNode.innerHTML = `<div class="integration-import-error">${escapeHTML(error.message || 'Could not import this CSV.')}</div>`;
  } finally {
    if (button) { button.disabled = !ui.tinkercadCsvText; button.textContent = 'Normalize BOM'; }
  }
}

function renderTinkercadImportResult(result) {
  const holder = modalRoot.querySelector('#tinkercad-import-result');
  if (!holder) return;
  const matches = ui.tinkercadRows.filter((row) => row.match);
  const rawAddable = matches.reduce((sum, row) => sum + Math.min(20, row.quantity || 1), 0);
  const addable = Math.min(48, rawAddable);
  holder.innerHTML = `<div class="bom-import-summary"><b>${result.count} BOM row${result.count === 1 ? '' : 's'} normalized</b><span>${matches.length} likely catalog match${matches.length === 1 ? '' : 'es'}</span></div>${ui.tinkercadRows.length ? `<div class="bom-table-wrap"><table class="bom-preview-table"><thead><tr><th>Ref</th><th>Exported item</th><th>Qty</th><th>Suggested match</th></tr></thead><tbody>${ui.tinkercadRows.map((row) => `<tr><td>${escapeHTML(row.reference || '—')}</td><td>${escapeHTML(row.description || row.value || '—')}${row.value && row.value !== row.description ? `<small>${escapeHTML(row.value)}</small>` : ''}</td><td>${row.quantity}</td><td>${row.match ? `<span class="bom-match">${escapeHTML(row.match.name)}</span>` : `<span class="bom-unmatched">No close match</span>`}</td></tr>`).join('')}</tbody></table></div>` : `<div class="integration-empty-state">No data rows were recognized. Check that this is the Tinkercad component-list CSV.</div>`}<p class="bom-import-note">${escapeHTML(result.note || 'Matches are heuristic. No pins, nets, or wiring are imported.')}</p>${addable ? `<button class="secondary-button bom-add-button" data-action="add-imported-matches">Add ${addable}${rawAddable > 48 ? '+' : ''} matched part${addable === 1 ? '' : 's'} as unwired components</button>` : ''}`;
}

function findBomPosition(component, occupied) {
  const size = getComponentSize(component);
  for (let y = 24; y + size.h < 650; y += 132) for (let x = 24; x + size.w < 980; x += 154) {
    const overlaps = occupied.some((other) => {
      const otherSize = getComponentSize(other);
      return x < other.x + otherSize.w + 12 && x + size.w + 12 > other.x && y < other.y + otherSize.h + 12 && y + size.h + 12 > other.y;
    });
    if (!overlaps) return { x: ui.snap ? Math.round(x / 12) * 12 : x, y: ui.snap ? Math.round(y / 12) * 12 : y };
  }
  return { x: 32, y: 32 };
}

function addImportedBomMatches() {
  const occupied = [...project.components];
  const additions = [];
  for (const row of ui.tinkercadRows) {
    const item = row.match && LIBRARY.find((part) => part.id === row.match.id);
    if (!item) continue;
    const quantity = Math.min(20, Math.max(1, Number(row.quantity) || 1));
    for (let i = 0; i < quantity && additions.length < 48; i++) {
      const component = createComponentFromLibrary(item, occupied.length + additions.length);
      component.ref = nextReference([...occupied, ...additions], component.ref);
      component.value = row.value || item.sub;
      Object.assign(component, findBomPosition(component, [...occupied, ...additions]));
      additions.push(component);
    }
    if (additions.length >= 48) break;
  }
  if (!additions.length) return toast('No matched parts to add');
  project.components.push(...additions);
  project.notes = [...(project.notes || []), 'Tinkercad BOM matches were added as unconnected schematic components. Verify exact identity, pin map, values, and wiring before use.'];
  ui.view = 'schematic';
  ui.selectedIds = new Set(additions.map((component) => component.id));
  ui.selectedWire = null;
  addHistory('Import Tinkercad BOM matches');
  closeModal();
  toast(`${additions.length} matched part${additions.length === 1 ? '' : 's'} added · no wiring imported`);
}

function openAIModal() {
  showModal(`<div class="modal-header"><div class="modal-icon ai-modal-icon">${icon('spark', 18)}</div><div><span class="modal-eyebrow">CIRCUIT STUDIO · DESIGN COPILOT</span><h2>Describe what you want to build</h2></div><button class="modal-close" data-action="close-modal">${icon('x', 17)}</button></div>
    <div class="ai-modal-body"><div class="local-model-badge"><span class="local-indicator"></span><span id="ai-backend-badge">${ui.backendStatus === 'online' ? 'Backend online · local catalog + public KiCad metadata' : 'Backend status checking · local templates are ready'}</span></div><label class="prompt-label" for="ai-prompt">PROJECT BRIEF</label><textarea id="ai-prompt" placeholder="Example: Build an ESP32 soil-moisture monitor with a protected pump relay and a small status display…"></textarea><div class="prompt-examples"><span>TRY A TEMPLATE</span><button data-prompt="Build a room temperature and humidity monitor with an ESP32, DHT22, and OLED">Room monitor</button><button data-prompt="Build a capacitive soil moisture monitor with a safely controlled irrigation relay">Smart irrigation</button><button data-prompt="Make a simple ESP32 status LED that blinks safely">LED controller</button></div>
      <div class="assistant-backend-options"><label class="backend-option"><input id="ai-use-public" type="checkbox" checked /><span><b>Search public KiCad metadata</b><small>Fetch attributed symbol, footprint-hint, and datasheet metadata through the backend when online.</small></span></label><label class="backend-option"><input id="ai-use-external" type="checkbox" disabled /><span><b>Use configured server-side AI</b><small id="ai-external-label">Unavailable until a provider is configured by the backend operator.</small></span></label></div>
      <div class="assistant-scope"><div class="scope-icon">${icon('info', 15)}</div><p><b>Engineering note</b><br>Only the built-in room-monitor, LED, and irrigation templates change the schematic automatically; a connected model currently reviews and recommends but does not emit arbitrary auto-wired netlists. Neither templates nor public symbol data verify a circuit. No Tinkercad/Cirkit project API is connected. External models require server configuration and your opt-in. Verify exact datasheets, voltages, currents, pinouts, and load ratings.</p></div>
      <div class="ai-result" id="ai-result" hidden></div></div>
    <div class="modal-footer"><span>Project autosaves locally · server AI is opt-in</span><div><button class="secondary-button" data-action="close-modal">Cancel</button><button class="primary-button" data-action="generate-design">${icon('spark', 15)} Generate design</button></div></div>`, 'wide');
  refreshBackendHealth();
}

async function runDesignAssistant() {
  const prompt = modalRoot.querySelector('#ai-prompt')?.value?.trim() || '';
  if (!prompt) { toast('Describe the circuit you want to build'); modalRoot.querySelector('#ai-prompt')?.focus(); return; }
  const holder = modalRoot.querySelector('#ai-result');
  const button = modalRoot.querySelector('[data-action="generate-design"]');
  const publicToggle = modalRoot.querySelector('#ai-use-public');
  const externalToggle = modalRoot.querySelector('#ai-use-external');
  const usePublicData = publicToggle?.checked === true;
  const useExternal = externalToggle?.checked === true && ui.backendHealth?.ai?.enabled === true;
  if (button) { button.disabled = true; button.textContent = 'Reviewing…'; }
  if (holder) { holder.hidden = false; holder.innerHTML = `<div class="backend-pending"><span class="backend-pulse"></span>Applying a local template and querying enabled backend sources…</div>`; }
  const localResult = applyLocalDesignAssistant(project, prompt);
  const plannedProject = localResult.project;
  let backendReview = null;
  let backendError = '';
  try {
    const response = await fetch('/api/assistant', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        prompt,
        project: { name: plannedProject.name, components: plannedProject.components.map((component) => ({ ref: component.ref, name: component.name, value: component.value, footprint: component.footprint })), nets: plannedProject.wires.map((wire) => wire.net || 'unlabelled net') },
        usePublicData, useExternal,
      }),
    });
    const responseBody = await response.json();
    if (!response.ok) throw new Error(responseBody.error || `Backend returned HTTP ${response.status}`);
    backendReview = responseBody;
  } catch (error) { backendError = error.message || 'Backend is unavailable'; }
  project = plannedProject;
  project.firmware = generateFirmware(project);
  if (localResult.changed) { ui.view = 'schematic'; ui.selectedIds.clear(); ui.selectedWire = null; addHistory('AI design update'); }
  else { persistProject(); renderAll(); }
  const backendCautions = Array.isArray(backendReview?.cautions) ? backendReview.cautions : [];
  showAIResult({
    ...localResult,
    cautions: [...new Set([...(localResult.cautions || []), ...backendCautions])],
    backendReview, backendError,
  });
  if (button) { button.disabled = false; button.innerHTML = `${icon('spark', 15)} Generate design`; }
}

function showAIResult(result) {
  const holder = modalRoot.querySelector('#ai-result');
  if (!holder) return;
  holder.hidden = false;
  const review = result.backendReview;
  const recommendations = (review?.recommendations || []).slice(0, 5);
  const suggestedParts = (review?.parts || []).slice(0, 6).map((part) => `${part.name}${part.valueHint ? ` · ${part.valueHint}` : ''}`);
  const publicData = review?.publicData;
  const publicItems = (publicData?.items || []).slice(0, 5);
  const renderPublicItem = (item) => {
    const datasheetLink = /^https?:\/\//i.test(item.datasheet || '') ? `<a href="${escapeHTML(item.datasheet)}" target="_blank" rel="noopener noreferrer">Datasheet ↗</a>` : '';
    return `<li><b>${escapeHTML(item.symbol)}</b><span>${escapeHTML(item.library)}${item.footprint ? ` · ${escapeHTML(item.footprint)}` : ''}</span>${item.description ? `<small>${escapeHTML(item.description)}</small>` : ''}<div class="public-item-links"><a href="${escapeHTML(item.sourceUrl)}" target="_blank" rel="noopener noreferrer">KiCad source ↗</a>${datasheetLink}</div></li>`;
  };
  const publicHtml = publicData ? `<div class="public-data-results"><div class="public-data-heading"><b>Open KiCad metadata</b><span>${publicData.status === 'available' ? `${publicItems.length} records` : escapeHTML(publicData.status || 'not available')} · CC-BY-SA 4.0</span></div>${publicItems.length ? `<ul>${publicItems.map(renderPublicItem).join('')}</ul>` : `<p>${escapeHTML(publicData.error || publicData.note || 'No relevant public symbol entries were returned.')}</p>`}<small class="public-attribution">${publicData.sourceUrl ? `<a href="${escapeHTML(publicData.sourceUrl)}" target="_blank" rel="noopener noreferrer">${escapeHTML(publicData.source || 'KiCad official library')}</a> · <a href="${escapeHTML(publicData.licenseUrl || 'https://www.kicad.org/libraries/license/')}" target="_blank" rel="noopener noreferrer">CC-BY-SA 4.0 license</a>` : escapeHTML(publicData.source || '')}. Verify all datasheets and package assignments.</small></div>` : '';
  holder.innerHTML = `<div class="result-header"><span class="result-success-icon">${icon('check', 15)}</span><div><b>${escapeHTML(result.title)}</b><p>${escapeHTML(result.summary)}</p></div></div><div class="result-parts"><span>LOCAL DESIGN CONTENTS</span><div>${(result.parts || []).slice(0, 10).map((part) => `<i>${escapeHTML(part)}</i>`).join('')}</div></div>${review ? `<section class="backend-review"><div class="backend-review-heading"><b>${review.mode === 'configured-ai' ? 'Configured AI review' : 'Backend catalog review'}</b><span>${escapeHTML(review.source || 'Circuit Studio backend')}</span></div><p>${escapeHTML(review.summary || '')}</p>${recommendations.length ? `<ul>${recommendations.map((item) => `<li>${escapeHTML(item)}</li>`).join('')}</ul>` : ''}${suggestedParts.length ? `<div class="backend-part-chips">${suggestedParts.map((part) => `<i>${escapeHTML(part)}</i>`).join('')}</div>` : ''}${review.fallbackReason ? `<small class="backend-fallback">Provider fallback: ${escapeHTML(review.fallbackReason)}</small>` : ''}</section>` : ''}${result.backendError ? `<div class="backend-fallback">Backend unavailable: ${escapeHTML(result.backendError)}. The local design template was still applied.</div>` : ''}${publicData?.status === 'unavailable' ? `<div class="backend-fallback">The public KiCad index could not be reached this time; local catalog suggestions remain available.</div>` : ''}${publicHtml}${result.cautions?.length ? `<div class="result-caution"><b>Review before power-on</b>${result.cautions.map((note) => `<span>• ${escapeHTML(note)}</span>`).join('')}</div>` : ''}<div class="result-actions"><button class="secondary-button" data-action="view-connections">Review connections</button><button class="secondary-button" data-action="close-modal">Continue editing</button></div>`;
}
function openExportMenu() {
  const entries = [
    ['project', 'Project JSON', 'Editable browser project · .json', 'file'],
    ['svg', 'Schematic SVG', 'Vector sheet snapshot · .svg', 'file'],
    ['bom', 'Bill of materials', 'Grouped component list · .csv', 'file'],
    ['kicad', 'KiCad PCB draft', 'Placement skeleton · .kicad_pcb', 'board'],
    ['gerber', 'Gerber copper preview', 'Draft top copper · .gtl', 'layers'],
    ['outline', 'Gerber board outline', '68 × 43 mm · .gko', 'board'],
    ['drill', 'Excellon drill preview', 'Draft through-hole drill · .drl', 'layers'],
    ['firmware', 'Firmware sketch', 'Arduino scaffold · .ino', 'code'],
  ];
  showModal(`<div class="modal-header"><div class="modal-icon export-modal-icon">${icon('download', 17)}</div><div><span class="modal-eyebrow">DOWNLOAD DESIGN ASSETS</span><h2>Export project</h2></div><button class="modal-close" data-action="close-modal">${icon('x', 17)}</button></div><div class="export-list">${entries.map(([id, title, sub, symbol]) => `<button data-export="${id}" class="export-row"><span class="export-row-icon">${icon(symbol, 16)}</span><span><b>${title}</b><small>${sub}</small></span><span class="export-chevron">${icon('chevronRight', 14)}</span></button>`).join('')}</div><div class="export-warning">${icon('info', 14)} PCB / Gerber exports are geometry previews, not ERC/DRC-verified manufacturing files. Verify them in KiCad.</div><div class="modal-footer"><span>All generation runs locally</span><div><button class="secondary-button" data-action="close-modal">Close</button></div></div>`, 'normal');
}
function openShareModal() {
  const encoded = btoa(String.fromCharCode(...new TextEncoder().encode(projectJSON(project))));
  const url = `${location.origin}${location.pathname}#project=${encodeURIComponent(encoded)}`;
  showModal(`<div class="modal-header"><div class="modal-icon share-modal-icon">${icon('share', 17)}</div><div><span class="modal-eyebrow">PORTABLE PROJECT SNAPSHOT</span><h2>Share this design</h2></div><button class="modal-close" data-action="close-modal">${icon('x', 17)}</button></div><div class="share-content"><div class="share-info-card"><span class="share-info-icon">${icon('info', 16)}</span><p>This creates a self-contained URL snapshot of the current project. No cloud account or collaboration service is connected; anyone with the URL can read the design contents.</p></div><label class="share-url-label">SNAPSHOT LINK<input id="share-url" readonly value="${escapeHTML(url)}" /></label><div class="share-snapshot-meta"><span>${project.components.length} parts · ${project.wires.length} nets</span><span>Snapshot encoded in URL</span></div></div><div class="modal-footer"><span>Live co-editing is not enabled in this offline build</span><div><button class="secondary-button" data-action="close-modal">Close</button><button class="primary-button" data-action="copy-share">${icon('copy', 14)} Copy link</button></div></div>`);
}
function openHistoryModal() {
  const versions = [...(project.versions || [])].reverse();
  showModal(`<div class="modal-header"><div class="modal-icon history-modal-icon">${icon('clock', 17)}</div><div><span class="modal-eyebrow">LOCAL VERSION HISTORY</span><h2>Saved project versions</h2></div><button class="modal-close" data-action="close-modal">${icon('x', 17)}</button></div><div class="history-list">${versions.length ? versions.map((version) => `<div class="history-row"><span class="history-icon">${icon('clock', 14)}</span><div><b>${escapeHTML(version.label)}</b><small>${new Date(version.savedAt).toLocaleString()} · ${escapeHTML(version.name)}</small></div><span class="history-parts">${version.components.length} parts</span><button data-restore-version="${escapeHTML(version.id)}">Restore</button></div>`).join('') : `<div class="history-empty">No snapshots yet. Use Save or make a design change to create a local version.</div>`}</div><div class="modal-footer"><span>Stored in this browser only</span><div><button class="secondary-button" data-action="close-modal">Done</button></div></div>`);
}
function openLibraryInfo() {
  showModal(`<div class="modal-header"><div class="modal-icon export-modal-icon">${icon('layers', 17)}</div><div><span class="modal-eyebrow">OFFLINE PART CATALOG</span><h2>Starter library coverage</h2></div><button class="modal-close" data-action="close-modal">${icon('x', 17)}</button></div><div class="library-info-content"><p>${LIBRARY.length} curated part entries cover common microcontroller families, sensor and display modules, power stages, protection, passives, semiconductors, and connectors.</p><div class="coverage-grid">${CATEGORIES.slice(1).map((category) => `<span>${escapeHTML(category)}<b>${LIBRARY.filter((item) => item.category === category).length}</b></span>`).join('')}</div><div class="share-info-card"><span class="share-info-icon">${icon('info', 16)}</span><p>These are catalog records and approximate footprints, not vendor-verified 3D models, SPICE models, or electrical symbols for every listed part. Check exact revisions and datasheets.</p></div></div><div class="modal-footer"><span>Community/open standard-inspired metadata</span><div><button class="secondary-button" data-action="close-modal">Close</button></div></div>`);
}

function runExport(kind) {
  closeModal();
  const base = (project.name || 'circuit-studio').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'circuit-studio';
  if (kind === 'project') downloadText(`${base}.circuit.json`, projectJSON(project), 'application/json;charset=utf-8');
  if (kind === 'bom') downloadText(`${base}-bom.csv`, bomCSV(project), 'text/csv;charset=utf-8');
  if (kind === 'svg') downloadText(`${base}-schematic.svg`, schematicSVG(svg, project.name), 'image/svg+xml;charset=utf-8');
  if (kind === 'kicad') downloadText(`${base}.kicad_pcb`, kicadPCB(project), 'text/plain;charset=utf-8');
  if (kind === 'gerber') downloadText(`${base}-F_Cu.gtl`, gerberCopper(project), 'text/plain;charset=utf-8');
  if (kind === 'outline') downloadText(`${base}-Edge_Cuts.gko`, gerberOutline(), 'text/plain;charset=utf-8');
  if (kind === 'drill') downloadText(`${base}.drl`, drillFile(project), 'text/plain;charset=utf-8');
  if (kind === 'firmware') downloadText(`${base}.ino`, project.firmware || generateFirmware(project), 'text/plain;charset=utf-8');
  toast(`${kind.toUpperCase()} export downloaded`);
}

async function copyText(text) {
  try { await navigator.clipboard.writeText(text); return true; }
  catch {
    const temp = document.createElement('textarea'); temp.value = text; temp.style.position = 'fixed'; temp.style.opacity = '0'; document.body.appendChild(temp); temp.select();
    const ok = document.execCommand('copy'); temp.remove(); return ok;
  }
}

function lintFirmware() {
  const editor = app.querySelector('#firmware-editor');
  if (editor) project.firmware = editor.value;
  const code = project.firmware || '';
  const braces = (code.match(/{/g) || []).length - (code.match(/}/g) || []).length;
  const hasSetup = /void\s+setup\s*\(/.test(code);
  const hasLoop = /void\s+loop\s*\(/.test(code);
  const issues = [];
  if (braces !== 0) issues.push('Unbalanced braces');
  if (!hasSetup) issues.push('Missing setup()');
  if (!hasLoop) issues.push('Missing loop()');
  if (issues.length) toast(`Static review: ${issues.join(' · ')}`);
  else toast('Static shape checks passed · not a compiler');
}

function handleAction(action, event) {
  switch (action) {
    case 'undo': undo(); break;
    case 'redo': redo(); break;
    case 'save': saveVersion(); break;
    case 'theme':
      ui.theme = ui.theme === 'dark' ? 'light' : 'dark'; shell.classList.toggle('theme-light', ui.theme === 'light');
      try { localStorage.setItem('circuit-studio-theme', ui.theme); } catch { /* ignore */ }
      renderHeader(); break;
    case 'simulate': runSimulation(); break;
    case 'auto-place': autoPlaceBoard(); break;
    case 'pcb-drc': runPcbChecks(); break;
    case 'export-gerber': runExport('gerber'); break;
    case 'toggle-snap': ui.snap = !ui.snap; renderCenter(); break;
    case 'zoom-in': zoomAround(1.15); break;
    case 'zoom-out': zoomAround(0.87); break;
    case 'fit': ui.zoom = 1; ui.panX = 0; ui.panY = 0; renderCenter(); break;
    case 'ai-open': openAIModal(); break;
    case 'integrations': openIntegrationsModal(); break;
    case 'refresh-integrations': refreshIntegrationsModal(); break;
    case 'test-ai-provider': testAIProvider(); break;
    case 'choose-tinkercad-file': modalRoot.querySelector('#tinkercad-bom-file')?.click(); break;
    case 'import-tinkercad-bom': importTinkercadBom(); break;
    case 'add-imported-matches': addImportedBomMatches(); break;
    case 'share': openShareModal(); break;
    case 'export': openExportMenu(); break;
    case 'library-info': openLibraryInfo(); break;
    case 'collapse-library': app.querySelector('.left-panel').classList.toggle('library-collapsed'); break;
    case 'history': openHistoryModal(); break;
    case 'clear-console': ui.consoleLines = []; if (ui.simulation) ui.simulation = null; renderConsole(); break;
    case 'run-checks': runChecks(); break;
    case 'view-connections': ui.inspectorTab = 'connections'; closeModal(); renderInspector(); break;
    case 'delete-selection': deleteSelection(); break;
    case 'delete-wire': deleteSelection(); break;
    case 'duplicate': duplicateSelected(); break;
    case 'align-horizontal': alignSelection('horizontal'); break;
    case 'align-vertical': alignSelection('vertical'); break;
    case 'close-modal': closeModal(); break;
    case 'generate-design': runDesignAssistant(); break;
    case 'copy-share': {
      const value = modalRoot.querySelector('#share-url')?.value || '';
      copyText(value).then((ok) => toast(ok ? 'Snapshot link copied' : 'Copy failed — select the link manually'));
      break;
    }
    case 'download-firmware': {
      const editor = app.querySelector('#firmware-editor'); if (editor) project.firmware = editor.value;
      const base = project.name.toLowerCase().replace(/[^a-z0-9]+/g, '-') || 'circuit-studio';
      downloadText(`${base}.ino`, project.firmware || generateFirmware(project), 'text/plain;charset=utf-8'); toast('Firmware sketch downloaded'); break;
    }
    case 'lint-firmware': lintFirmware(); break;
    case 'rename-project': renameProject(); break;
    case 'new-project': createNewProject(); break;
    case 'collapse-dock': { const collapsed = app.querySelector('.console-dock').classList.toggle('collapsed'); app.querySelector('.center-column').classList.toggle('dock-collapsed', collapsed); break; }
    case 'inspector-menu': openHistoryModal(); break;
    case 'toggle-library': shell.classList.toggle('library-open'); shell.classList.remove('inspector-open'); break;
    case 'toggle-inspector': shell.classList.toggle('inspector-open'); shell.classList.remove('library-open'); break;
    default: break;
  }
}
function renameProject() {
  const name = window.prompt('Project name', project.name);
  if (!name?.trim()) return;
  project.name = name.trim().slice(0, 64);
  project.description = project.description || 'Local electronics design';
  addHistory('Rename project');
}
function createNewProject() {
  if (!window.confirm('Start a new Room Monitor starter project? The current project is saved locally.')) return;
  project = createStarterProject(); project.firmware = generateFirmware(project);
  ui.view = 'schematic'; ui.selectedIds.clear(); ui.selectedWire = null; ui.zoom = 1; ui.panX = 0; ui.panY = 0;
  initHistory(); addHistory('New project'); toast('New project created');
}

modalRoot.addEventListener('click', (event) => {
  event.stopPropagation();
  const exportItem = event.target.closest?.('[data-export]'); if (exportItem) { runExport(exportItem.dataset.export); return; }
  const quickPrompt = event.target.closest?.('[data-prompt]'); if (quickPrompt) { const prompt = modalRoot.querySelector('#ai-prompt'); if (prompt) { prompt.value = quickPrompt.dataset.prompt; prompt.focus(); } return; }
  const action = event.target.closest?.('[data-action]')?.dataset.action; if (action) { handleAction(action, event); return; }
  const restore = event.target.closest?.('[data-restore-version]');
  if (restore) {
    const version = project.versions.find((entry) => entry.id === restore.dataset.restoreVersion);
    if (version && window.confirm(`Restore “${version.label}” from ${new Date(version.savedAt).toLocaleString()}?`)) {
      project.name = version.name; project.components = clone(version.components); project.wires = clone(version.wires); ui.selectedIds.clear(); ui.selectedWire = null;
      closeModal(); addHistory('Restore version'); toast('Version restored');
    }
  }
});
modalRoot.addEventListener('change', async (event) => {
  if (event.target.id !== 'tinkercad-bom-file') return;
  const file = event.target.files?.[0];
  const nameNode = modalRoot.querySelector('#tinkercad-file-name');
  const button = modalRoot.querySelector('#tinkercad-import-button');
  const resultNode = modalRoot.querySelector('#tinkercad-import-result');
  ui.tinkercadRows = [];
  ui.tinkercadCsvText = '';
  ui.tinkercadFileName = file?.name || '';
  if (nameNode) nameNode.textContent = file?.name || 'No file selected';
  if (!file) { if (button) button.disabled = true; return; }
  if (file.size > 900 * 1024) {
    if (button) button.disabled = true;
    if (resultNode) resultNode.innerHTML = `<div class="integration-import-error">CSV must be under 900 KB for this local prototype.</div>`;
    return;
  }
  try {
    ui.tinkercadCsvText = await file.text();
    if (button) button.disabled = !ui.tinkercadCsvText;
    if (resultNode) resultNode.innerHTML = `<span class="integration-empty-state">${escapeHTML(file.name)} ready · choose “Normalize BOM” to preview component rows.</span>`;
  } catch {
    if (button) button.disabled = true;
    if (resultNode) resultNode.innerHTML = `<div class="integration-import-error">Could not read the selected file.</div>`;
  }
});
modalRoot.addEventListener('input', (event) => {
  if (event.target.id === 'firmware-editor') project.firmware = event.target.value;
});
app.querySelector('#firmware-stage').addEventListener('input', (event) => {
  if (event.target.id === 'firmware-editor') {
    project.firmware = event.target.value; setDirty();
    const lineNumber = event.target.value.split('\n').length; const lines = app.querySelector('.line-numbers');
    if (lines) lines.innerHTML = Array.from({ length: lineNumber }, (_, index) => `<span>${index + 1}</span>`).join('');
    clearTimeout(ui.firmwareSaveTimer); ui.firmwareSaveTimer = setTimeout(() => persistProject(), 650);
  }
});
app.querySelector('#firmware-stage').addEventListener('scroll', (event) => {
  if (event.target.id === 'firmware-editor') { const lines = app.querySelector('.line-numbers'); if (lines) lines.scrollTop = event.target.scrollTop; }
}, true);

function initialSetup() {
  initHistory();
  app.querySelector('.app-shell').classList.toggle('theme-light', ui.theme === 'light');
  renderAll();
  persistProject();
  refreshBackendHealth();
  if (decodeHashProject()) toast('Opened portable project snapshot');
}
initialSetup();
