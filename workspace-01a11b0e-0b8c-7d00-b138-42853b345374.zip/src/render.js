import { getComponentSize, getPinAnchor } from './model.js';

const esc = (value = '') => String(value).replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
const fmt = (value) => Number(value).toFixed(1).replace(/\.0$/, '');

function wirePath(wire, project) {
  const from = project.components.find((component) => component.id === wire.from[0]);
  const to = project.components.find((component) => component.id === wire.to[0]);
  if (!from || !to) return null;
  const start = getPinAnchor(from, wire.from[1]);
  const end = getPinAnchor(to, wire.to[1]);
  const nodes = [start, ...(wire.waypoints || []), end];
  const points = [nodes[0]];
  for (let i = 1; i < nodes.length; i++) {
    const a = points.at(-1);
    const b = nodes[i];
    if (Math.abs(a.x - b.x) > 0.5 && Math.abs(a.y - b.y) > 0.5) {
      const prior = points.at(-2) || { x: a.x - 1, y: a.y };
      const priorWasHorizontal = Math.abs(a.y - prior.y) < 0.5;
      points.push(priorWasHorizontal ? { x: a.x, y: b.y } : { x: b.x, y: a.y });
    }
    points.push(b);
  }
  const d = points.map((point, index) => `${index ? 'L' : 'M'}${fmt(point.x)},${fmt(point.y)}`).join(' ');
  let longest = null;
  for (let i = 1; i < points.length; i++) {
    const a = points[i - 1]; const b = points[i];
    if (Math.abs(a.y - b.y) < 0.5) {
      const length = Math.abs(a.x - b.x);
      if (!longest || length > longest.length) longest = { x: (a.x + b.x) / 2, y: a.y, length };
    }
  }
  return { d, start, end, label: longest };
}

function pinMarkup(component, pin, label, side) {
  const point = getPinAnchor(component, pin);
  const x = point.x; const y = point.y;
  const left = side === 'left';
  return `<g class="pin" data-component-id="${esc(component.id)}" data-pin-id="${esc(pin)}" tabindex="0" role="button" aria-label="${esc(component.ref)} ${esc(pin)}">
    <line x1="${x}" y1="${y}" x2="${x + (left ? 9 : -9)}" y2="${y}" class="pin-stub" />
    <circle cx="${x}" cy="${y}" r="3.3" class="pin-dot" />
    <text x="${x + (left ? 14 : -14)}" y="${y + 3}" text-anchor="${left ? 'start' : 'end'}" class="pin-label">${esc(label)}</text>
    <circle cx="${x}" cy="${y}" r="10" class="pin-hit" />
  </g>`;
}

function renderUnmappedBoard(component) {
  const x = +component.x; const y = +component.y; const { w, h } = getComponentSize(component);
  return `<g class="component generic-mcu-component" data-component-id="${esc(component.id)}" tabindex="0" role="button" aria-label="Select ${esc(component.ref)} ${esc(component.name)}" transform="translate(${x} ${y})">
    <rect class="component-outline" width="${w}" height="${h}" rx="9" />
    <path class="mcu-top-line" d="M10 43H164" />
    <rect class="mcu-chip" x="40" y="126" width="94" height="80" rx="5" />
    <text class="ref-label" x="12" y="19">${esc(component.ref)} · BOARD</text>
    <text class="component-title" x="12" y="35">${esc(component.name.slice(0, 22))}</text>
    <text class="mcu-chip-title" x="87" y="160" text-anchor="middle">${esc(component.libraryId.toUpperCase())}</text>
    <text class="mcu-chip-sub" x="87" y="180" text-anchor="middle">${esc((component.value || 'Board').slice(0, 20))}</text>
    <rect class="component-tag" x="36" y="237" width="102" height="25" rx="12" />
    <text class="component-tag-text" x="87" y="253" text-anchor="middle">PIN MAP NEEDED</text>
    <text class="component-subtitle" x="87" y="291" text-anchor="middle">Footprint preview only</text>
    <text class="component-footnote" x="87" y="318" text-anchor="middle">No pin-accurate symbol in</text>
    <text class="component-footnote" x="87" y="333" text-anchor="middle">this starter library build.</text>
    <text class="component-footnote" x="87" y="358" text-anchor="middle">Do not route by board name alone.</text>
  </g>`;
}

function renderMcu(component) {
  if (component.libraryId && component.libraryId !== 'esp32dev') return renderUnmappedBoard(component);
  const x = +component.x; const y = +component.y; const { w, h } = getComponentSize(component);
  const boardName = component.name || 'Microcontroller board';
  const chipLabel = /pico|rp2040/i.test(boardName) ? 'RP2040' : /arduino/i.test(boardName) ? 'ATmega328P' : /stm32/i.test(boardName) ? 'STM32' : /teensy/i.test(boardName) ? 'CORTEX-M7' : /esp/i.test(boardName) ? 'ESP32' : 'MCU';
  const chipDetail = /pico|rp2040/i.test(boardName) ? 'DUAL-CORE · ARM' : /arduino/i.test(boardName) ? '8-BIT AVR · 5 V' : /stm32/i.test(boardName) ? 'ARM CORTEX-M' : /teensy/i.test(boardName) ? '600 MHz · 32-BIT' : /esp/i.test(boardName) ? 'WROOM-32 · Wi-Fi' : 'BOARD · MODULE';
  const boardTag = /devkit/i.test(boardName) ? 'DEVKIT V1' : /arduino/i.test(boardName) ? 'ARDUINO BOARD' : /pico/i.test(boardName) ? 'RASPBERRY PI' : 'DEVELOPMENT BOARD';
  const shortBoard = boardName.length > 22 ? `${boardName.slice(0, 20)}…` : boardName;
  const leftPins = [['5V', '5V'], ['GND_L', 'GND'], ['3V3', '3V3'], ['GPIO34', 'GPIO34'], ['GPIO35', 'GPIO35'], ['GPIO32', 'GPIO32'], ['GPIO33', 'GPIO33'], ['GPIO25', 'GPIO25']];
  const rightPins = [['GPIO23', 'GPIO23'], ['GPIO22', 'GPIO22'], ['GPIO21', 'GPIO21'], ['GPIO19', 'GPIO19'], ['GPIO18', 'GPIO18'], ['GPIO5', 'GPIO5'], ['GPIO4', 'GPIO4'], ['GPIO2', 'GPIO2'], ['GPIO26', 'GPIO26'], ['GND_R', 'GND']];
  return `<g class="component mcu-component" data-component-id="${esc(component.id)}" tabindex="0" role="button" aria-label="Select ${esc(component.ref)} ${esc(component.name)}" transform="translate(${x} ${y})">
    <rect class="component-outline" x="0" y="0" width="${w}" height="${h}" rx="9" />
    <path class="mcu-top-line" d="M10 43H164" />
    <rect class="mcu-chip" x="46" y="118" width="82" height="101" rx="4" />
    <rect class="mcu-chip-inset" x="54" y="126" width="66" height="85" rx="3" />
    <path class="chip-pin-lines" d="M54 137h-8m8 10h-8m8 10h-8m8 10h-8m8 10h-8m8 10h-8m66-53h8m-8 10h8m-8 10h8m-8 10h8m-8 10h8m-8 10h8" />
    <text class="ref-label" x="12" y="19">${esc(component.ref)} · ${esc(chipLabel)}</text>
    <text class="component-title" x="12" y="35">${esc(shortBoard)}</text>
    <text class="mcu-chip-title" x="87" y="164" text-anchor="middle">${esc(chipLabel)}</text>
    <text class="mcu-chip-sub" x="87" y="180" text-anchor="middle">${esc((component.value || chipLabel).slice(0, 17))}</text>
    <text class="mcu-chip-sub" x="87" y="198" text-anchor="middle">${esc(chipDetail)}</text>
    <rect class="component-tag" x="36" y="237" width="102" height="25" rx="12" />
    <text class="component-tag-text" x="87" y="253" text-anchor="middle">${esc(boardTag)}</text>
    <text class="component-subtitle" x="87" y="286" text-anchor="middle">USB powered · 3.3 V logic</text>
    <text class="component-subtitle" x="87" y="303" text-anchor="middle">GPIO · UART · I²C · SPI</text>
    <text class="component-footnote" x="87" y="343" text-anchor="middle">Wire tool: click source, then destination</text>
    <text class="component-footnote" x="87" y="358" text-anchor="middle">Pin names are indicative</text>
    ${leftPins.map(([id, label]) => pinMarkup(component, id, label, 'left')).join('')}
    ${rightPins.map(([id, label]) => pinMarkup(component, id, label, 'right')).join('')}
  </g>`;
}

function renderDisplay(component) {
  const x = +component.x; const y = +component.y; const { w, h } = getComponentSize(component);
  const interfaceLabel = /spi/i.test(component.value) ? 'SPI' : /i²c|i2c/i.test(component.value) ? 'I²C' : 'DISPLAY';
  const pins = [['GND', 'GND'], ['VCC', 'VCC'], ['SCL', 'SCL'], ['SDA', 'SDA']];
  return `<g class="component display-component" data-component-id="${esc(component.id)}" tabindex="0" role="button" aria-label="Select ${esc(component.ref)} ${esc(component.name)}" transform="translate(${x} ${y})">
    <rect class="component-outline" width="${w}" height="${h}" rx="8" />
    <rect class="display-screen" x="44" y="31" width="89" height="70" rx="4" />
    <rect class="display-pixel" x="51" y="39" width="75" height="54" rx="1" />
    <path class="screen-line" d="M59 49h52M59 59h39M59 69h47M59 79h30" />
    <text class="ref-label" x="10" y="17">${esc(component.ref)} · ${esc(interfaceLabel)}</text>
    <text class="component-subtitle" x="10" y="124">${esc(component.name.slice(0, 21))}</text>
    <text class="component-footnote" x="88" y="112" text-anchor="middle">${esc(component.value.slice(0, 18))}</text>
    ${pins.map(([id, label]) => pinMarkup(component, id, label, 'left')).join('')}
  </g>`;
}

function renderSensor(component) {
  const x = +component.x; const y = +component.y; const { w, h } = getComponentSize(component);
  const pins = [['VCC', 'VCC'], ['DATA', 'DATA'], ['GND', 'GND']];
  return `<g class="component sensor-component" data-component-id="${esc(component.id)}" tabindex="0" role="button" aria-label="Select ${esc(component.ref)} ${esc(component.name)}" transform="translate(${x} ${y})">
    <rect class="component-outline" width="${w}" height="${h}" rx="8" />
    <rect class="sensor-face" x="55" y="31" width="77" height="52" rx="8" />
    <path class="sensor-grill" d="M69 42v30m10-30v30m10-30v30m10-30v30m10-30v30" />
    <circle class="sensor-led" cx="119" cy="42" r="3" />
    <text class="ref-label" x="10" y="17">${esc(component.ref)} · SENSOR</text>
    <text class="component-title" x="10" y="104">${esc(component.name)}</text>
    <text class="component-footnote" x="10" y="115">${esc(component.value)}</text>
    ${pins.map(([id, label]) => pinMarkup(component, id, label, 'left')).join('')}
  </g>`;
}

function renderResistor(component) {
  const x = +component.x; const y = +component.y; const { w, h } = getComponentSize(component);
  return `<g class="component passive-component" data-component-id="${esc(component.id)}" tabindex="0" role="button" aria-label="Select ${esc(component.ref)} ${esc(component.name)}" transform="translate(${x} ${y})">
    <rect class="component-outline" width="${w}" height="${h}" rx="7" />
    <text class="ref-label" x="10" y="16">${esc(component.ref)} · R</text>
    <path class="resistor-zigzag" d="M7 31h12l6-9 9 18 9-18 9 18 9-18 9 18 9-18 6 9h15" />
    <text class="resistor-value" x="50" y="56" text-anchor="middle">${esc(component.value)}</text>
    ${pinMarkup(component, 'A', '', 'left')}
    ${pinMarkup(component, 'B', '', 'right')}
  </g>`;
}

function renderCapacitor(component) {
  const x = +component.x; const y = +component.y; const { w, h } = getComponentSize(component);
  return `<g class="component passive-component" data-component-id="${esc(component.id)}" tabindex="0" role="button" aria-label="Select ${esc(component.ref)} ${esc(component.name)}" transform="translate(${x} ${y})">
    <rect class="component-outline" width="${w}" height="${h}" rx="7" />
    <text class="ref-label" x="10" y="16">${esc(component.ref)} · C</text>
    <path class="capacitor-symbol" d="M34 22v18m10-18v18M7 31h27m10 0h42" />
    <text class="resistor-value" x="50" y="56" text-anchor="middle">${esc(component.value)}</text>
    ${pinMarkup(component, 'A', '', 'left')}
    ${pinMarkup(component, 'B', '', 'right')}
  </g>`;
}

function renderLed(component) {
  const x = +component.x; const y = +component.y; const { w, h } = getComponentSize(component);
  return `<g class="component led-component" data-component-id="${esc(component.id)}" tabindex="0" role="button" aria-label="Select ${esc(component.ref)} ${esc(component.name)}" transform="translate(${x} ${y})">
    <rect class="component-outline" width="${w}" height="${h}" rx="8" />
    <text class="ref-label" x="10" y="16">${esc(component.ref)} · LED</text>
    <circle class="led-symbol" cx="60" cy="39" r="14" />
    <path class="led-diode" d="M55 31v16l12-8zM69 29v20" />
    <path class="led-rays" d="m72 24 7-7m-1 14 9-2" />
    <text class="component-footnote" x="60" y="63" text-anchor="middle">${esc(component.value)}</text>
    ${pinMarkup(component, 'A', 'A', 'left')}
    ${pinMarkup(component, 'K', 'K', 'right')}
  </g>`;
}

function renderGeneric(component) {
  const x = +component.x; const y = +component.y; const { w, h } = getComponentSize(component);
  return `<g class="component generic-component" data-component-id="${esc(component.id)}" tabindex="0" role="button" aria-label="Select ${esc(component.ref)} ${esc(component.name)}" transform="translate(${x} ${y})">
    <rect class="component-outline" width="${w}" height="${h}" rx="8" />
    <rect class="generic-icon" x="14" y="29" width="34" height="34" rx="7" />
    <text class="generic-icon-letter" x="31" y="51" text-anchor="middle">${esc((component.name || 'P').slice(0, 1))}</text>
    <text class="ref-label" x="58" y="17">${esc(component.ref)} · ${esc(component.category || 'PART')}</text>
    <text class="component-title" x="58" y="37">${esc(component.name.slice(0, 18))}</text>
    <text class="component-subtitle" x="58" y="55">${esc(component.value.slice(0, 19))}</text>
    <text class="component-footnote" x="14" y="85">${esc(component.footprint || 'Unassigned footprint')}</text>
    ${pinMarkup(component, 'IN', '', 'left')}
    ${pinMarkup(component, 'OUT', '', 'right')}
  </g>`;
}

function renderSchematic(project, state) {
  const endpointCounts = new Map();
  const paths = project.wires.map((wire) => {
    const rendered = wirePath(wire, project);
    if (!rendered) return '';
    for (const point of [rendered.start, rendered.end]) {
      const key = `${Math.round(point.x)}:${Math.round(point.y)}`;
      endpointCounts.set(key, (endpointCounts.get(key) || 0) + 1);
    }
    return `<g class="wire-group ${state.selectedWire === wire.id ? 'is-selected' : ''}" data-wire-id="${esc(wire.id)}" tabindex="0" role="button" aria-label="${esc(wire.net || 'Wire')}">
      <path d="${rendered.d}" class="wire-halo" />
      <path d="${rendered.d}" class="wire-path wire-${esc(wire.color || 'signal')}" />
      ${wire.label && rendered.label ? `<g class="wire-label" transform="translate(${fmt(rendered.label.x)} ${fmt(rendered.label.y - 8)})"><rect x="-34" y="-9" width="68" height="17" rx="8"/><text y="3" text-anchor="middle">${esc(wire.label)}</text></g>` : ''}
    </g>`;
  }).join('');
  const junctions = [...endpointCounts.entries()].filter(([, count]) => count > 1).map(([key]) => {
    const [x, y] = key.split(':').map(Number);
    return `<circle class="junction-dot" cx="${x}" cy="${y}" r="3.2"/>`;
  }).join('');
  const components = project.components.map((component) => {
    const renderer = { mcu: renderMcu, display: renderDisplay, sensor: renderSensor, resistor: renderResistor, capacitor: renderCapacitor, led: renderLed }[component.type] || renderGeneric;
    return `<g class="component-wrap ${state.selectedIds?.has(component.id) ? 'is-selected' : ''}">${renderer(component)}</g>`;
  }).join('');
  return `<g class="scene" transform="translate(${state.panX} ${state.panY}) scale(${state.zoom})">
    <g class="sheet-heading"><text x="42" y="46">${esc(project.name.toUpperCase())}</text><text x="42" y="64">SCHEMATIC · SHEET 01 · ${project.components.length} PARTS</text></g>
    ${paths}
    ${junctions}
    ${components}
    <g class="canvas-legend" transform="translate(40 625)"><circle cx="5" cy="0" r="3" class="legend-power"/><text x="14" y="4">POWER</text><circle cx="75" cy="0" r="3" class="legend-ground"/><text x="84" y="4">GROUND</text><circle cx="164" cy="0" r="3" class="legend-signal"/><text x="173" y="4">SIGNAL / DATA</text></g>
    <text class="sheet-scale" x="930" y="635" text-anchor="end">GRID 24 · SNAP ${state.snap ? 'ON' : 'OFF'}</text>
  </g>`;
}

const boardPresets = {
  U1: [390, 338], OLED1: [672, 240], U2: [672, 410], R1: [535, 332], R2: [538, 495], D1: [724, 496], C1: [470, 370], K1: [710, 490],
};
function boardPos(project, component) {
  return project.boardPositions?.[component.id] || boardPresets[component.id] || [250 + (project.components.indexOf(component) % 4) * 130, 260 + Math.floor(project.components.indexOf(component) / 4) * 105];
}
function footprintSize(component) {
  if (component.type === 'mcu') return [142, 86];
  if (component.type === 'display') return [106, 46];
  if (component.type === 'sensor') return [72, 46];
  if (component.type === 'resistor') return [38, 20];
  if (component.type === 'capacitor') return [28, 20];
  if (component.type === 'led') return [28, 28];
  return [68, 44];
}
function boardTracePath(a, b, index) {
  const offset = ((index % 5) - 2) * 7;
  const mx = Math.round((a[0] + b[0]) / 2 + offset);
  return `M${a[0]},${a[1]} H${mx} V${b[1]} H${b[0]}`;
}
function renderFootprint(project, component, state) {
  const [cx, cy] = boardPos(project, component);
  const [w, h] = footprintSize(component);
  const selected = state.selectedIds?.has(component.id) ? 'is-selected' : '';
  const pad = (x, y, cls = '') => `<circle class="pcb-pad ${cls}" cx="${x}" cy="${y}" r="4.2"/>`;
  let pads = '';
  if (component.type === 'mcu') {
    for (let i = 0; i < 8; i++) { pads += pad(-w / 2 + 8, -h / 2 + 10 + i * 9); pads += pad(w / 2 - 8, -h / 2 + 10 + i * 9); }
  } else if (component.type === 'display' || component.type === 'sensor') {
    for (let i = 0; i < 4; i++) pads += pad(-w / 2 + 10 + i * 12, h / 2 - 3);
  } else if (component.type === 'resistor') {
    pads = `${pad(-w / 2 + 4, 0)}${pad(w / 2 - 4, 0)}`;
  } else {
    pads = `${pad(-w / 2 + 4, 0)}${pad(w / 2 - 4, 0)}`;
  }
  const label = component.ref;
  const body = component.type === 'resistor'
    ? `<rect class="pcb-body resistor-body" x="-${w / 2 - 9}" y="-6" width="${w - 18}" height="12" rx="4"/>`
    : component.type === 'led'
      ? `<circle class="pcb-body" r="7"/>`
      : `<rect class="pcb-body" x="-${w / 2}" y="-${h / 2}" width="${w}" height="${h}" rx="${component.type === 'mcu' ? 5 : 2}"/>`;
  return `<g class="pcb-component ${selected}" data-component-id="${esc(component.id)}" tabindex="0" role="button" aria-label="Move ${esc(component.ref)}" transform="translate(${cx} ${cy})">
    <rect class="footprint-hit" x="-${w / 2 - 1}" y="-${h / 2 - 1}" width="${w - 2}" height="${h - 2}" rx="5" />
    ${body}${pads}
    <text class="pcb-ref" x="0" y="${h / 2 + 13}" text-anchor="middle">${esc(label)}</text>
    <text class="pcb-value" x="0" y="${h / 2 + 25}" text-anchor="middle">${esc(component.value.slice(0, 15))}</text>
  </g>`;
}
function renderBoard(project, state) {
  const traces = project.wires.map((wire, index) => {
    const aComp = project.components.find((component) => component.id === wire.from[0]);
    const bComp = project.components.find((component) => component.id === wire.to[0]);
    if (!aComp || !bComp) return '';
    const a = boardPos(project, aComp); const b = boardPos(project, bComp);
    const start = [a[0] + (a[0] < b[0] ? 49 : -49), a[1] + ((index % 3) - 1) * 7];
    const end = [b[0] + (b[0] < a[0] ? 34 : -34), b[1] + ((index % 3) - 1) * 6];
    return `<path class="pcb-trace trace-${esc(wire.color || 'signal')}" d="${boardTracePath(start, end, index)}"/>`;
  }).join('');
  return `<g class="scene" transform="translate(${state.panX} ${state.panY}) scale(${state.zoom})">
    <g class="sheet-heading"><text x="42" y="46">${esc(project.name.toUpperCase())}</text><text x="42" y="64">PCB EDITOR · 2-LAYER · 1.6 mm FR-4</text></g>
    <rect class="pcb-outline" x="170" y="130" width="680" height="430" rx="14"/>
    <path class="pcb-copper-zone" d="M190 150h640v390H190z"/>
    <circle class="mount-hole" cx="198" cy="158" r="7"/><circle class="mount-hole" cx="822" cy="158" r="7"/><circle class="mount-hole" cx="198" cy="532" r="7"/><circle class="mount-hole" cx="822" cy="532" r="7"/>
    ${traces}
    ${project.components.map((component) => renderFootprint(project, component, state)).join('')}
    <g class="pcb-silk"><text x="205" y="515">${esc(project.name.toUpperCase())} · REV A</text><text x="205" y="533">DESIGNED IN CIRCUIT STUDIO · VERIFY BEFORE FAB</text></g>
    <g class="board-legend" transform="translate(42 625)"><circle cx="5" cy="0" r="4" class="pcb-pad"/><text x="17" y="4">THROUGH-HOLE PAD</text><path d="M145 0h28" class="pcb-trace trace-signal"/><text x="182" y="4">ROUTED NET PREVIEW</text></g>
    <text class="sheet-scale" x="930" y="635" text-anchor="end">BOARD 68 × 43 mm · 2 LAYERS</text>
  </g>`;
}

export function renderCanvas(svg, project, state) {
  const artwork = state.view === 'pcb' ? renderBoard(project, state) : renderSchematic(project, state);
  svg.innerHTML = `<defs>
    <pattern id="canvas-grid" width="24" height="24" patternUnits="userSpaceOnUse"><circle cx="1" cy="1" r="1" class="grid-dot"/></pattern>
    <pattern id="canvas-grid-major" width="120" height="120" patternUnits="userSpaceOnUse"><path d="M120 0H0V120" fill="none" class="grid-major"/></pattern>
    <filter id="shadow-soft" x="-40%" y="-40%" width="180%" height="180%"><feDropShadow dx="0" dy="4" stdDeviation="5" flood-color="#000" flood-opacity=".22"/></filter>
  </defs>
  <rect x="0" y="0" width="1000" height="680" class="canvas-bg"/>
  <rect x="0" y="0" width="1000" height="680" fill="url(#canvas-grid)"/>
  <rect x="0" y="0" width="1000" height="680" fill="url(#canvas-grid-major)"/>
  ${artwork}`;
}
