export const LIBRARY = [
  { id: 'esp32dev', name: 'ESP32 DevKit V1', sub: 'Wi-Fi · Bluetooth · 3.3 V', category: 'Microcontrollers', family: 'MCU', symbol: 'mcu', footprint: 'ESP32-DEVKIT-V1' },
  { id: 'esp32s3', name: 'ESP32-S3 DevKitC', sub: 'Dual-core · USB OTG', category: 'Microcontrollers', family: 'MCU', symbol: 'mcu', footprint: 'ESP32-S3-DEVKITC' },
  { id: 'esp32c3', name: 'ESP32-C3 SuperMini', sub: 'RISC-V · Wi-Fi · BLE', category: 'Microcontrollers', family: 'MCU', symbol: 'mcu', footprint: 'ESP32-C3-SUPERMINI' },
  { id: 'esp8266', name: 'NodeMCU ESP8266', sub: 'Wi-Fi · 3.3 V', category: 'Microcontrollers', family: 'MCU', symbol: 'mcu', footprint: 'NODEMCU-ESP8266' },
  { id: 'arduinoUno', name: 'Arduino Uno R3', sub: 'ATmega328P · 5 V', category: 'Microcontrollers', family: 'MCU', symbol: 'mcu', footprint: 'ARDUINO-UNO-R3' },
  { id: 'arduinoNano', name: 'Arduino Nano', sub: 'ATmega328P · compact', category: 'Microcontrollers', family: 'MCU', symbol: 'mcu', footprint: 'ARDUINO-NANO' },
  { id: 'arduinoMega', name: 'Arduino Mega 2560', sub: 'ATmega2560 · 54 GPIO', category: 'Microcontrollers', family: 'MCU', symbol: 'mcu', footprint: 'ARDUINO-MEGA-2560' },
  { id: 'arduinoMicro', name: 'Arduino Micro', sub: 'ATmega32U4 · USB', category: 'Microcontrollers', family: 'MCU', symbol: 'mcu', footprint: 'ARDUINO-MICRO' },
  { id: 'pico', name: 'Raspberry Pi Pico', sub: 'RP2040 · dual-core', category: 'Microcontrollers', family: 'MCU', symbol: 'mcu', footprint: 'RASPBERRY-PI-PICO' },
  { id: 'picoW', name: 'Raspberry Pi Pico W', sub: 'RP2040 · Wi-Fi', category: 'Microcontrollers', family: 'MCU', symbol: 'mcu', footprint: 'RASPBERRY-PI-PICO-W' },
  { id: 'stm32Bluepill', name: 'STM32 Blue Pill', sub: 'STM32F103C8 · 3.3 V', category: 'Microcontrollers', family: 'MCU', symbol: 'mcu', footprint: 'STM32-BLUE-PILL' },
  { id: 'stm32Nucleo', name: 'STM32 Nucleo-64', sub: 'Cortex-M · Arduino headers', category: 'Microcontrollers', family: 'MCU', symbol: 'mcu', footprint: 'STM32-NUCLEO-64' },
  { id: 'teensy41', name: 'Teensy 4.1', sub: '600 MHz · Cortex-M7', category: 'Microcontrollers', family: 'MCU', symbol: 'mcu', footprint: 'TEENSY-4.1' },
  { id: 'microbit', name: 'BBC micro:bit v2', sub: 'nRF52833 · BLE', category: 'Microcontrollers', family: 'MCU', symbol: 'mcu', footprint: 'BBC-MICROBIT-V2' },
  { id: 'piZero', name: 'Raspberry Pi Zero 2 W', sub: 'Linux SBC · Wi-Fi', category: 'Embedded boards', family: 'SBC', symbol: 'board', footprint: 'PI-ZERO-2-W' },
  { id: 'pi4', name: 'Raspberry Pi 4 Model B', sub: 'Linux SBC · 40-pin GPIO', category: 'Embedded boards', family: 'SBC', symbol: 'board', footprint: 'PI-4-MODEL-B' },
  { id: 'jetsonNano', name: 'NVIDIA Jetson Nano', sub: 'AI edge computer', category: 'Embedded boards', family: 'SBC', symbol: 'board', footprint: 'JETSON-NANO' },
  { id: 'beagleBone', name: 'BeagleBone Black', sub: 'AM335x · Linux SBC', category: 'Embedded boards', family: 'SBC', symbol: 'board', footprint: 'BEAGLEBONE-BLACK' },
  { id: 'attiny85', name: 'ATtiny85', sub: '8-bit AVR · DIP-8', category: 'Microcontrollers', family: 'MCU', symbol: 'ic', footprint: 'DIP-8' },
  { id: 'pic16', name: 'PIC16F877A', sub: '8-bit PIC · DIP-40', category: 'Microcontrollers', family: 'MCU', symbol: 'ic', footprint: 'DIP-40' },
  { id: 'dht22', name: 'DHT22 / AM2302', sub: 'Temperature · humidity', category: 'Sensors', family: 'Sensor', symbol: 'sensor', footprint: 'DHT22-4PIN' },
  { id: 'bme280', name: 'BME280', sub: 'Pressure · temperature · RH', category: 'Sensors', family: 'Sensor', symbol: 'sensor', footprint: 'LGA-8' },
  { id: 'bmp280', name: 'BMP280', sub: 'Barometric pressure · I²C', category: 'Sensors', family: 'Sensor', symbol: 'sensor', footprint: 'LGA-8' },
  { id: 'ds18b20', name: 'DS18B20', sub: 'Waterproof temperature · 1-Wire', category: 'Sensors', family: 'Sensor', symbol: 'sensor', footprint: 'TO-92' },
  { id: 'soil', name: 'Capacitive soil sensor', sub: 'Analog moisture · 3.3–5 V', category: 'Sensors', family: 'Sensor', symbol: 'sensor', footprint: 'SOIL-SENSOR-MODULE' },
  { id: 'pir', name: 'PIR motion sensor', sub: 'HC-SR501 · digital output', category: 'Sensors', family: 'Sensor', symbol: 'sensor', footprint: 'HC-SR501' },
  { id: 'hc-sr04', name: 'HC-SR04 ultrasonic', sub: 'Distance · 5 V logic', category: 'Sensors', family: 'Sensor', symbol: 'sensor', footprint: 'HC-SR04' },
  { id: 'mpu6050', name: 'MPU-6050 IMU', sub: '6-axis · I²C', category: 'Sensors', family: 'Sensor', symbol: 'sensor', footprint: 'MPU-6050-MODULE' },
  { id: 'ina219', name: 'INA219 current sensor', sub: 'High-side · I²C', category: 'Sensors', family: 'Sensor', symbol: 'sensor', footprint: 'INA219-MODULE' },
  { id: 'ldr', name: 'Photoresistor (LDR)', sub: 'Light sensing · analog', category: 'Sensors', family: 'Sensor', symbol: 'sensor', footprint: 'LDR-5MM' },
  { id: 'mic', name: 'MAX9814 microphone', sub: 'AGC electret preamp', category: 'Sensors', family: 'Sensor', symbol: 'sensor', footprint: 'MAX9814-MODULE' },
  { id: 'gps', name: 'NEO-6M GPS', sub: 'UART · GNSS receiver', category: 'Communication', family: 'Module', symbol: 'module', footprint: 'NEO-6M-MODULE' },
  { id: 'rfid', name: 'MFRC522 RFID', sub: '13.56 MHz · SPI', category: 'Communication', family: 'Module', symbol: 'module', footprint: 'MFRC522-MODULE' },
  { id: 'nrf24', name: 'nRF24L01+', sub: '2.4 GHz · SPI radio', category: 'Communication', family: 'Module', symbol: 'module', footprint: 'NRF24L01-MODULE' },
  { id: 'can', name: 'MCP2515 CAN module', sub: 'SPI · CAN 2.0B', category: 'Communication', family: 'Module', symbol: 'module', footprint: 'MCP2515-MODULE' },
  { id: 'rs485', name: 'MAX485 RS-485', sub: 'Half-duplex transceiver', category: 'Communication', family: 'Module', symbol: 'module', footprint: 'MAX485-MODULE' },
  { id: 'oled', name: 'OLED 0.96 in SSD1306', sub: '128 × 64 · I²C · 3.3 V', category: 'Displays', family: 'Display', symbol: 'display', footprint: 'SSD1306-096-I2C' },
  { id: 'lcd1602', name: 'LCD 16 × 2', sub: 'HD44780 · character display', category: 'Displays', family: 'Display', symbol: 'display', footprint: 'LCD1602' },
  { id: 'tft24', name: 'TFT 2.4 in ILI9341', sub: '320 × 240 · SPI · touch', category: 'Displays', family: 'Display', symbol: 'display', footprint: 'ILI9341-240' },
  { id: 'epaper', name: 'e-Paper 2.13 in', sub: '296 × 128 · SPI', category: 'Displays', family: 'Display', symbol: 'display', footprint: 'EPAPER-213' },
  { id: 'matrix', name: 'MAX7219 LED matrix', sub: '8 × 8 · SPI', category: 'Displays', family: 'Display', symbol: 'display', footprint: 'MAX7219-MATRIX' },
  { id: 'touch', name: 'TTP223 touch sensor', sub: 'Capacitive · digital output', category: 'Sensors', family: 'Sensor', symbol: 'sensor', footprint: 'TTP223-MODULE' },
  { id: 'relay', name: '5 V relay module', sub: 'Optoisolated · 1 channel', category: 'Power & drivers', family: 'Driver', symbol: 'module', footprint: 'RELAY-1CH' },
  { id: 'tb6612', name: 'TB6612FNG motor driver', sub: 'Dual H-bridge · 1.2 A', category: 'Power & drivers', family: 'Driver', symbol: 'module', footprint: 'TB6612-MODULE' },
  { id: 'drv8833', name: 'DRV8833 motor driver', sub: 'Dual H-bridge · 1.5 A', category: 'Power & drivers', family: 'Driver', symbol: 'module', footprint: 'DRV8833' },
  { id: 'mosfet', name: 'Logic-level MOSFET', sub: 'N-channel · low-side switch', category: 'Power & drivers', family: 'Transistor', symbol: 'transistor', footprint: 'TO-220' },
  { id: 'lm2596', name: 'LM2596 buck module', sub: 'Step-down regulator', category: 'Power & drivers', family: 'Power', symbol: 'module', footprint: 'LM2596-MODULE' },
  { id: 'ams1117', name: 'AMS1117-3.3 regulator', sub: 'LDO · SOT-223', category: 'Power & drivers', family: 'Power', symbol: 'ic', footprint: 'SOT-223' },
  { id: 'usbC', name: 'USB-C power input', sub: '5 V · protection footprint', category: 'Power & drivers', family: 'Power', symbol: 'module', footprint: 'USB-C-16P' },
  { id: 'battery', name: 'Li-ion cell 18650', sub: '3.0–4.2 V · battery holder', category: 'Power & drivers', family: 'Power', symbol: 'power', footprint: '18650-HOLDER' },
  { id: 'resistor', name: 'Resistor', sub: 'Through-hole · editable value', category: 'Passives', family: 'Passive', symbol: 'resistor', footprint: 'R_Axial_DIN0207' },
  { id: 'capacitor', name: 'Ceramic capacitor', sub: 'Decoupling · X7R', category: 'Passives', family: 'Passive', symbol: 'capacitor', footprint: 'C_Disc_D5.0mm' },
  { id: 'electrolytic', name: 'Electrolytic capacitor', sub: 'Radial · polarized', category: 'Passives', family: 'Passive', symbol: 'capacitor', footprint: 'CP_Radial_D5.0mm' },
  { id: 'inductor', name: 'Inductor', sub: 'Power / filter · editable', category: 'Passives', family: 'Passive', symbol: 'inductor', footprint: 'L_Radial_D5.0mm' },
  { id: 'diode', name: '1N5819 Schottky diode', sub: 'Flyback / reverse protection', category: 'Semiconductors', family: 'Diode', symbol: 'diode', footprint: 'DO-41' },
  { id: 'transistor', name: '2N2222 NPN transistor', sub: 'General purpose · TO-92', category: 'Semiconductors', family: 'Transistor', symbol: 'transistor', footprint: 'TO-92' },
  { id: 'opamp', name: 'LM358 dual op-amp', sub: 'Analog · DIP-8', category: 'Semiconductors', family: 'IC', symbol: 'ic', footprint: 'DIP-8' },
  { id: 'logic', name: '74HC595 shift register', sub: '8-bit · serial in / parallel out', category: 'Semiconductors', family: 'IC', symbol: 'ic', footprint: 'DIP-16' },
  { id: 'led', name: 'LED · 5 mm', sub: 'Indicator · current-limiting R required', category: 'Semiconductors', family: 'LED', symbol: 'led', footprint: 'LED_D5.0mm' },
  { id: 'rgb', name: 'RGB LED · common cathode', sub: '4-pin · 3 current-limiting resistors', category: 'Semiconductors', family: 'LED', symbol: 'led', footprint: 'LED_RGB_5mm' },
  { id: 'button', name: 'Tactile pushbutton', sub: 'Momentary · 6 mm', category: 'Passives', family: 'Switch', symbol: 'switch', footprint: 'SW_PUSH_6mm' },
  { id: 'pot', name: 'Potentiometer 10 kΩ', sub: 'Through-hole · adjustable', category: 'Passives', family: 'Passive', symbol: 'resistor', footprint: 'Potentiometer_Bourns_3296W' },
  { id: 'fuse', name: 'Resettable fuse · 500 mA', sub: 'PTC overcurrent protection', category: 'Protection', family: 'Protection', symbol: 'fuse', footprint: 'Fuse_1206' },
  { id: 'connector2', name: '2-pin screw terminal', sub: '5.08 mm pitch', category: 'Connectors', family: 'Connector', symbol: 'connector', footprint: 'TerminalBlock_2P' },
  { id: 'connector4', name: '4-pin JST-PH', sub: '2.0 mm pitch', category: 'Connectors', family: 'Connector', symbol: 'connector', footprint: 'JST_PH_4' },
  { id: 'camera', name: 'OV2640 camera module', sub: '2 MP · DVP / JPEG', category: 'Sensors', family: 'Camera', symbol: 'module', footprint: 'OV2640-MODULE' },
  { id: 'lidar', name: 'VL53L0X LiDAR', sub: 'Time-of-flight · I²C', category: 'Sensors', family: 'Sensor', symbol: 'sensor', footprint: 'VL53L0X-MODULE' },
  { id: 'hall', name: 'Hall-effect sensor', sub: 'A3144 · digital · open collector', category: 'Sensors', family: 'Sensor', symbol: 'sensor', footprint: 'A3144' },
  { id: 'encoder', name: 'Rotary encoder', sub: 'Quadrature · push switch', category: 'Input & control', family: 'Input', symbol: 'module', footprint: 'EC11-ENCODER' },
  { id: 'speaker', name: 'Piezo buzzer', sub: 'Active · 5 V', category: 'Output', family: 'Output', symbol: 'module', footprint: 'BUZZER-12MM' },
];

export const CATEGORIES = ['All parts', 'Microcontrollers', 'Sensors', 'Displays', 'Communication', 'Power & drivers', 'Passives', 'Semiconductors', 'Connectors'];

const defaultWires = [
  { id: 'w-vcc-oled', from: ['U1', '3V3'], to: ['OLED1', 'VCC'], color: 'power', net: '3V3', label: '3V3', waypoints: [{ x: 260, y: 275 }, { x: 260, y: 110 }, { x: 680, y: 110 }, { x: 680, y: 173 }, { x: 710, y: 173 }] },
  { id: 'w-vcc-dht', from: ['U1', '3V3'], to: ['U2', 'VCC'], color: 'power', net: '3V3', waypoints: [{ x: 260, y: 275 }, { x: 260, y: 110 }, { x: 680, y: 110 }, { x: 680, y: 365 }, { x: 710, y: 365 }] },
  { id: 'w-vcc-r1', from: ['U1', '3V3'], to: ['R1', 'A'], color: 'power', net: '3V3', waypoints: [{ x: 300, y: 275 }, { x: 300, y: 363 }, { x: 170, y: 363 }] },
  { id: 'w-gnd-oled', from: ['U1', 'GND_L'], to: ['OLED1', 'GND'], color: 'ground', net: 'GND', waypoints: [{ x: 250, y: 235 }, { x: 250, y: 145 }, { x: 710, y: 145 }] },
  { id: 'w-gnd-dht', from: ['U1', 'GND_R'], to: ['U2', 'GND'], color: 'ground', net: 'GND', waypoints: [{ x: 680, y: 515 }, { x: 680, y: 435 }, { x: 710, y: 435 }] },
  { id: 'w-i2c-scl', from: ['U1', 'GPIO22'], to: ['OLED1', 'SCL'], color: 'signal', net: 'I2C_SCL', label: 'SCL', waypoints: [{ x: 590, y: 235 }, { x: 590, y: 202 }, { x: 710, y: 202 }] },
  { id: 'w-i2c-sda', from: ['U1', 'GPIO21'], to: ['OLED1', 'SDA'], color: 'signal', net: 'I2C_SDA', label: 'SDA', waypoints: [{ x: 620, y: 275 }, { x: 620, y: 231 }, { x: 710, y: 231 }] },
  { id: 'w-dht-data', from: ['U1', 'GPIO4'], to: ['U2', 'DATA'], color: 'signal', net: 'DHT_DATA', label: 'DATA · GPIO4', waypoints: [{ x: 600, y: 435 }, { x: 600, y: 399 }, { x: 710, y: 399 }] },
  { id: 'w-pullup', from: ['R1', 'B'], to: ['U2', 'DATA'], color: 'signal', net: 'DHT_DATA', waypoints: [{ x: 300, y: 363 }, { x: 300, y: 610 }, { x: 700, y: 610 }, { x: 700, y: 399 }, { x: 710, y: 399 }] },
  { id: 'w-led-drive', from: ['U1', 'GPIO2'], to: ['R2', 'A'], color: 'signal', net: 'LED_OUT', label: 'GPIO2', waypoints: [{ x: 540, y: 475 }, { x: 540, y: 563 }, { x: 560, y: 563 }] },
  { id: 'w-led', from: ['R2', 'B'], to: ['D1', 'A'], color: 'signal', net: 'LED_OUT', waypoints: [{ x: 660, y: 563 }, { x: 710, y: 563 }] },
  { id: 'w-led-gnd', from: ['D1', 'K'], to: ['U1', 'GND_R'], color: 'ground', net: 'GND', waypoints: [{ x: 890, y: 563 }, { x: 890, y: 625 }, { x: 530, y: 625 }, { x: 530, y: 515 }] },
  { id: 'w-cap-vcc', from: ['U1', '3V3'], to: ['C1', 'A'], color: 'power', net: '3V3', waypoints: [{ x: 300, y: 275 }, { x: 300, y: 461 }, { x: 170, y: 461 }] },
  { id: 'w-cap-gnd', from: ['C1', 'B'], to: ['U1', 'GND_L'], color: 'ground', net: 'GND', waypoints: [{ x: 285, y: 461 }, { x: 285, y: 235 }, { x: 340, y: 235 }] },
];

export function createStarterProject() {
  return {
    name: 'Room Monitor',
    description: 'ESP32 room monitor · temperature, humidity & status display',
    activeView: 'schematic',
    components: [
      { id: 'U1', libraryId: 'esp32dev', ref: 'U1', name: 'ESP32 DevKit V1', value: 'ESP32-WROOM-32', type: 'mcu', category: 'Microcontrollers', footprint: 'ESP32-DEVKIT-V1', x: 340, y: 155 },
      { id: 'OLED1', libraryId: 'oled', ref: 'OLED1', name: 'OLED 0.96 in SSD1306', value: '128 × 64 · I²C', type: 'display', category: 'Displays', footprint: 'SSD1306-096-I2C', x: 710, y: 116 },
      { id: 'U2', libraryId: 'dht22', ref: 'U2', name: 'DHT22 / AM2302', value: 'Digital · 3.3 V', type: 'sensor', category: 'Sensors', footprint: 'DHT22-4PIN', x: 710, y: 340 },
      { id: 'R1', libraryId: 'resistor', ref: 'R1', name: 'Pull-up resistor', value: '4.7 kΩ', type: 'resistor', category: 'Passives', footprint: 'R_Axial_DIN0207', x: 170, y: 332 },
      { id: 'R2', libraryId: 'resistor', ref: 'R2', name: 'LED current limit', value: '220 Ω', type: 'resistor', category: 'Passives', footprint: 'R_Axial_DIN0207', x: 560, y: 535 },
      { id: 'D1', libraryId: 'led', ref: 'D1', name: 'Status LED · green', value: '5 mm · 2.1 V', type: 'led', category: 'Semiconductors', footprint: 'LED_D5.0mm', x: 740, y: 528 },
      { id: 'C1', libraryId: 'capacitor', ref: 'C1', name: 'Local decoupling', value: '100 nF · X7R', type: 'capacitor', category: 'Passives', footprint: 'C_0603_1608Metric', x: 170, y: 430 },
    ],
    wires: structuredClone(defaultWires),
    boardPositions: {},
    firmware: '',
    notes: [],
    versions: [],
  };
}

export function getComponentSize(component) {
  switch (component.type) {
    case 'mcu': return { w: 174, h: 380 };
    case 'display': return { w: 146, h: 134 };
    case 'sensor': return { w: 146, h: 118 };
    case 'resistor': return { w: 100, h: 62 };
    case 'capacitor': return { w: 100, h: 62 };
    case 'led': return { w: 120, h: 70 };
    default: return { w: 138, h: 104 };
  }
}

export function getPinAnchor(component, pin) {
  const x = Number(component.x) || 0;
  const y = Number(component.y) || 0;
  const { w, h } = getComponentSize(component);
  const pinMap = {
    mcu: {
      '5V': [0, 40, 'left'], GND_L: [0, 80, 'left'], '3V3': [0, 120, 'left'], GPIO34: [0, 160, 'left'], GPIO35: [0, 200, 'left'], GPIO32: [0, 240, 'left'], GPIO33: [0, 280, 'left'], GPIO25: [0, 320, 'left'],
      GPIO23: [w, 40, 'right'], GPIO22: [w, 80, 'right'], GPIO21: [w, 120, 'right'], GPIO19: [w, 160, 'right'], GPIO18: [w, 200, 'right'], GPIO5: [w, 240, 'right'], GPIO4: [w, 280, 'right'], GPIO2: [w, 320, 'right'], GPIO26: [w, 340, 'right'], GND_R: [w, 360, 'right'],
    },
    display: { GND: [0, 29, 'left'], VCC: [0, 57, 'left'], SCL: [0, 86, 'left'], SDA: [0, 115, 'left'] },
    sensor: { VCC: [0, 25, 'left'], DATA: [0, 59, 'left'], GND: [0, 95, 'left'] },
    resistor: { A: [0, 31, 'left'], B: [w, 31, 'right'] },
    capacitor: { A: [0, 31, 'left'], B: [w, 31, 'right'] },
    led: { A: [0, 35, 'left'], K: [w, 35, 'right'] },
  };
  const entry = pinMap[component.type]?.[pin];
  if (entry) return { x: x + entry[0], y: y + entry[1], side: entry[2] };
  if (pin === 'A') return { x, y: y + h / 2, side: 'left' };
  return { x: x + w, y: y + h / 2, side: 'right' };
}

export function createComponentFromLibrary(item, count, x = null, y = null) {
  const prefix = item.symbol === 'capacitor' ? 'C' : item.symbol === 'resistor' ? 'R' : item.family === 'LED' || item.family === 'Diode' ? 'D' : item.family === 'Transistor' ? 'Q' : item.family === 'MCU' || item.family === 'SBC' || item.family === 'Sensor' || item.family === 'Driver' || item.family === 'Power' || item.family === 'IC' ? 'U' : item.family === 'Display' ? 'OLED' : item.family === 'Passive' ? 'R' : item.family === 'Connector' ? 'J' : item.family === 'Switch' ? 'SW' : 'J';
  const type = item.symbol === 'mcu' ? 'mcu' : item.symbol === 'display' ? 'display' : item.symbol === 'sensor' ? 'sensor' : item.symbol === 'resistor' ? 'resistor' : item.symbol === 'capacitor' ? 'capacitor' : item.symbol === 'led' ? 'led' : 'generic';
  const defaults = { mcu: item.sub || 'Board · verify pin map', display: item.sub || 'Module · verify interface', sensor: item.sub || 'Module · see datasheet', resistor: '10 kΩ', capacitor: '100 nF · X7R', led: item.sub || 'Indicator · check current', generic: item.sub || item.family };
  return {
    id: `C${Date.now().toString(36)}${count}`,
    libraryId: item.id,
    ref: prefix,
    name: item.name,
    value: defaults[type],
    type,
    category: item.category,
    footprint: item.footprint,
    x: x ?? 150 + (count % 3) * 205,
    y: y ?? 150 + Math.floor(count / 3) * 150,
  };
}

export function nextReference(components, prefix) {
  let n = 1;
  while (components.some((component) => component.ref === `${prefix}${n}`)) n++;
  return `${prefix}${n}`;
}
