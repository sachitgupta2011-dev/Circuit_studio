import { getComponentSize } from './model.js';

export function downloadText(filename, text, type = 'text/plain;charset=utf-8') {
  const blob = new Blob([text], { type });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1500);
}

export function projectJSON(project) {
  return JSON.stringify({ format: 'circuit-studio-project', schemaVersion: 1, exportedAt: new Date().toISOString(), project }, null, 2);
}

export function bomCSV(project) {
  const rows = [['Reference', 'Quantity', 'Value', 'Description', 'Footprint', 'Category']];
  const grouped = new Map();
  for (const component of project.components) {
    const key = [component.value, component.name, component.footprint, component.category].join('|');
    if (!grouped.has(key)) grouped.set(key, { value: component.value, name: component.name, footprint: component.footprint, category: component.category, refs: [] });
    grouped.get(key).refs.push(component.ref);
  }
  for (const group of grouped.values()) rows.push([group.refs.join(', '), group.refs.length, group.value, group.name, group.footprint, group.category]);
  return rows.map((row) => row.map((cell) => `"${String(cell ?? '').replaceAll('"', '""')}"`).join(',')).join('\r\n');
}

function mm(value) { return ((value - 170) * 0.1).toFixed(3); }
function boardY(value) { return ((value - 130) * 0.1).toFixed(3); }
function gerberCoord(x, y) {
  const xi = String(Math.round((x - 170) * 100000)).padStart(10, '0');
  const yi = String(Math.round((560 - y) * 100000)).padStart(10, '0');
  return `X${xi}Y${yi}`;
}

const fixedBoardPositions = { U1: [390, 338], OLED1: [672, 240], U2: [672, 410], R1: [535, 332], R2: [538, 495], D1: [724, 496], C1: [470, 370], K1: [710, 490] };
function getBoardPosition(project, component) {
  return project.boardPositions?.[component.id] || fixedBoardPositions[component.id] || [250 + (project.components.indexOf(component) % 4) * 130, 260 + Math.floor(project.components.indexOf(component) / 4) * 105];
}
function padOffsets(component) {
  const size = getComponentSize(component);
  if (component.type === 'mcu') return Array.from({ length: 16 }, (_, i) => [-size.w * 0.36 + (i % 2) * size.w * 0.72, -28 + Math.floor(i / 2) * 7]);
  if (component.type === 'display' || component.type === 'sensor') return Array.from({ length: 4 }, (_, i) => [-18 + i * 12, size.h * 0.28]);
  return [[-8, 0], [8, 0]];
}

export function gerberCopper(project) {
  const layers = new Set(project.wires.map((wire) => wire.color));
  let out = `G04 Circuit Studio draft F.Cu — visual routing preview; not fabrication-verified*\n%FSLAX46Y46*%\n%MOMM*%\n%LPD*%\n%ADD10C,0.250*%\n%ADD11C,1.500*%\nD10*\n`;
  let index = 0;
  for (const wire of project.wires) {
    const from = project.components.find((component) => component.id === wire.from[0]);
    const to = project.components.find((component) => component.id === wire.to[0]);
    if (!from || !to) continue;
    const a = getBoardPosition(project, from); const b = getBoardPosition(project, to);
    const start = [a[0] + (a[0] < b[0] ? 32 : -32), a[1] + ((index % 3) - 1) * 4];
    const end = [b[0] + (b[0] < a[0] ? 24 : -24), b[1] + ((index % 3) - 1) * 4];
    const middleX = (start[0] + end[0]) / 2 + ((index % 5) - 2) * 4;
    out += `${gerberCoord(...start)}D02*\n${gerberCoord(middleX, start[1])}D01*\n${gerberCoord(middleX, end[1])}D01*\n${gerberCoord(...end)}D01*\n`;
    index++;
  }
  out += 'D11*\n';
  for (const component of project.components) {
    const center = getBoardPosition(project, component);
    for (const [dx, dy] of padOffsets(component)) out += `${gerberCoord(center[0] + dx, center[1] + dy)}D03*\n`;
  }
  out += 'M02*\n';
  return out;
}

export function gerberOutline() {
  const points = [[170, 130], [850, 130], [850, 560], [170, 560], [170, 130]];
  let out = 'G04 Circuit Studio draft Edge.Cuts — 68 x 43 mm*\n%FSLAX46Y46*%\n%MOMM*%\n%ADD10C,0.100*%\nD10*\n';
  out += `${gerberCoord(...points[0])}D02*\n`;
  for (const point of points.slice(1)) out += `${gerberCoord(...point)}D01*\n`;
  out += 'M02*\n';
  return out;
}

function kicadQuote(value) { return String(value ?? '').replaceAll('\\', '\\\\').replaceAll('"', '\\"'); }

export function kicadPCB(project) {
  const nets = [...new Set(project.wires.map((wire) => wire.net).filter(Boolean))];
  const netLines = nets.map((net, index) => `  (net ${index + 1} "${kicadQuote(net)}")`).join('\n');
  const footprints = project.components.map((component) => {
    const [cx, cy] = getBoardPosition(project, component);
    const x = mm(cx); const y = boardY(cy);
    const [width, height] = component.type === 'mcu' ? [18, 10] : component.type === 'display' ? [12, 7] : [8, 6];
    const reference = kicadQuote(component.ref);
    const value = kicadQuote(component.value);
    const footprintId = kicadQuote(`CircuitStudio:${component.footprint || 'Generic_Module'}`);
    const offsets = padOffsets(component);
    const pads = offsets.map(([dx, dy], index) => {
      const px = (dx * 0.1).toFixed(3); const py = (-dy * 0.1).toFixed(3);
      const padNumber = String(index + 1);
      return `    (pad "${padNumber}" thru_hole circle (at ${px} ${py}) (size 1.7 1.7) (drill 0.9) (layers "*.Cu" "*.Mask"))`;
    }).join('\n');
    return `  (footprint "${footprintId}" (layer "F.Cu") (at ${x} ${y})\n    (property "Reference" "${reference}" (at 0 ${(-height / 2 - 2).toFixed(2)} 0) (layer "F.SilkS") (effects (font (size 1 1) (thickness 0.15))))\n    (property "Value" "${value}" (at 0 ${(height / 2 + 2).toFixed(2)} 0) (layer "F.Fab") (effects (font (size 0.8 0.8) (thickness 0.12))))\n    (fp_rect (start ${(-width / 2).toFixed(2)} ${(-height / 2).toFixed(2)}) (end ${(width / 2).toFixed(2)} ${(height / 2).toFixed(2)}) (stroke (width 0.12) (type default)) (fill none) (layer "F.SilkS"))\n${pads}\n  )`;
  }).join('\n');
  const segments = [];
  return `(kicad_pcb (version 20241229) (generator "circuit-studio") (general (thickness 1.6)) (paper "A4")\n  (layers (0 "F.Cu" signal) (31 "B.Cu" signal) (32 "B.Adhes" user) (33 "F.Adhes" user) (34 "B.Paste" user) (35 "F.Paste" user) (36 "B.SilkS" user) (37 "F.SilkS" user) (38 "B.Mask" user) (39 "F.Mask" user) (44 "Edge.Cuts" user) (45 "Margin" user) (46 "B.CrtYd" user) (47 "F.CrtYd" user) (48 "B.Fab" user) (49 "F.Fab" user))\n  (setup (pad_to_mask_clearance 0))\n  (net 0 "")\n${netLines}\n  (gr_rect (start 0 0) (end 68 43) (stroke (width 0.1) (type default)) (fill none) (layer "Edge.Cuts"))\n${footprints}\n${segments.join('\n')}\n)\n`;
}

export function drillFile(project) {
  let out = 'M48\n; Circuit Studio draft drill file — inspect before fabrication\nMETRIC,TZ\nT1C0.900\n%\nT1\n';
  const holes = [[2.8, 2.8], [65.2, 2.8], [2.8, 40.2], [65.2, 40.2]];
  for (const component of project.components) {
    const [cx, cy] = getBoardPosition(project, component);
    if (component.type === 'mcu') {
      for (const [dx, dy] of padOffsets(component)) holes.push([((cx + dx - 170) * 0.1), ((cy + dy - 130) * 0.1)]);
    } else if (component.type === 'display' || component.type === 'sensor') {
      for (const [dx, dy] of padOffsets(component)) holes.push([((cx + dx - 170) * 0.1), ((cy + dy - 130) * 0.1)]);
    }
  }
  out += holes.map(([x, y]) => `${x.toFixed(3)}${y.toFixed(3)}`).join('\n');
  return `${out}\nM30\n`;
}

export function schematicSVG(svg, projectName) {
  const clone = svg.cloneNode(true);
  clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
  clone.setAttribute('width', '1600');
  clone.setAttribute('height', '1088');
  clone.setAttribute('aria-label', `${projectName} schematic preview`);
  const style = document.createElementNS('http://www.w3.org/2000/svg', 'style');
  style.textContent = `svg{--canvas-bg:#101417;background:#101417;font-family:Inter,Arial,sans-serif}.canvas-bg{fill:#101417}.grid-dot{fill:#2a3338;opacity:.7}.grid-major{stroke:#1c2428;stroke-width:.7;opacity:.58}.sheet-heading text:first-child{fill:#879397;font-size:9px;font-weight:700;letter-spacing:1.35px}.sheet-heading text:last-child{fill:#576469;font-size:7px;letter-spacing:1px}.wire-halo{fill:none;stroke:#101417;stroke-width:5;stroke-linecap:round;stroke-linejoin:round}.wire-path{fill:none;stroke-width:1.65;stroke-linecap:round;stroke-linejoin:round}.wire-power{stroke:#e79c72}.wire-ground{stroke:#82949a}.wire-signal{stroke:#64cfb1}.wire-label rect{fill:#182024;stroke:#38464b;stroke-width:.8}.wire-label text{fill:#b7c6c6;font-size:7px;font-weight:650}.junction-dot{fill:#e7a071;stroke:#111719;stroke-width:1}.component-outline{fill:#151b1f;stroke:#354147;stroke-width:1.1}.ref-label{fill:#87969a;font-size:7px;font-weight:650;letter-spacing:.45px}.component-title{fill:#d5dfe0;font-size:8px;font-weight:620}.component-subtitle{fill:#819095;font-size:7px}.component-footnote{fill:#68777c;font-size:6.3px}.pin-stub{stroke:#6f7e83;stroke-width:.9}.pin-dot{fill:#56646a;stroke:#151b1f;stroke-width:1}.pin-label{fill:#a6b3b6;font-size:6.7px}.mcu-top-line{stroke:#2c363b;stroke-width:.8}.mcu-chip{fill:#20292c;stroke:#4a5a5e;stroke-width:.8}.mcu-chip-inset{fill:#171d20;stroke:#354247;stroke-width:.7}.chip-pin-lines{stroke:#69797d;stroke-width:.8}.mcu-chip-title{fill:#d2dedf;font-size:8px;font-weight:700}.mcu-chip-sub{fill:#829297;font-size:5.7px}.component-tag{fill:rgba(83,195,153,.09);stroke:rgba(83,195,153,.31)}.component-tag-text{fill:#82d7b7;font-size:6px;letter-spacing:.8px;font-weight:700}.display-screen{fill:#283f45;stroke:#436b68;stroke-width:.8}.display-pixel{fill:#12312e}.screen-line{stroke:#7de7c2;stroke-width:1;opacity:.6}.sensor-face{fill:#222d31;stroke:#48575b;stroke-width:.9}.sensor-grill{stroke:#607174;stroke-width:1.5;stroke-linecap:round}.sensor-led{fill:#70d5a9}.resistor-zigzag{fill:none;stroke:#e3b36f;stroke-width:1.25}.capacitor-symbol{fill:none;stroke:#7dbbe5;stroke-width:1.25}.resistor-value{fill:#dfba83;font-size:7px}.led-symbol{fill:#26312a;stroke:#8cda9f;stroke-width:1.2}.led-diode,.led-rays{fill:none;stroke:#a2e29f;stroke-width:1.2}.canvas-legend text,.sheet-scale{fill:#67767b;font-size:7px;letter-spacing:.75px}.pcb-outline{fill:#18392f;stroke:#79a98d;stroke-width:1.4}.pcb-copper-zone{fill:rgba(48,129,90,.11);stroke:rgba(121,184,143,.19);stroke-width:.8}.mount-hole{fill:#101719;stroke:#8aa48f;stroke-width:1.2}.pcb-trace{fill:none;stroke-width:2.1;stroke-linecap:round;stroke-linejoin:round}.trace-power{stroke:#d89364}.trace-ground{stroke:#87a99b}.trace-signal{stroke:#e4c379}.pcb-body{fill:#141b1c;stroke:#b5c8b2;stroke-width:1}.pcb-pad{fill:#daa96c;stroke:#f1d596;stroke-width:.75}.pcb-ref{fill:#d0dccd;font-size:7px;font-weight:700}.pcb-value{fill:#91a79a;font-size:5.5px}.pcb-silk text{fill:rgba(214,235,218,.56);font-size:6px;letter-spacing:.7px}.board-legend text{fill:#82958a;font-size:7px}`;
  clone.insertBefore(style, clone.firstChild);
  return new XMLSerializer().serializeToString(clone);
}
