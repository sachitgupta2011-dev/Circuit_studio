import { createStarterProject } from './model.js';

const clone = (value) => structuredClone(value);

export function generateFirmware(project) {
  const sensor = project.components.find((item) => item.libraryId === 'dht22' || /DHT22/i.test(item.name));
  const display = project.components.some((item) => item.type === 'display');
  const led = project.components.find((item) => item.type === 'led');
  const irrigation = /irrigation|soil|plant/i.test(project.name);
  const includeDisplay = display;
  return `/*\n * ${project.name} — firmware scaffold\n * Target: ESP32 DevKit V1 · Arduino framework\n * Generated locally by Circuit Studio. Review pin map and library versions before flashing.\n */\n#include <Arduino.h>\n${sensor && !irrigation ? '#include <DHT.h>\n' : ''}${includeDisplay ? '#include <Wire.h>\n#include <Adafruit_GFX.h>\n#include <Adafruit_SSD1306.h>\n' : ''}\n${sensor && !irrigation ? 'constexpr uint8_t DHT_PIN = 4;\nconstexpr uint8_t DHT_TYPE = DHT22;\nDHT dht(DHT_PIN, DHT_TYPE);\n' : ''}${irrigation ? 'constexpr uint8_t SOIL_PIN = 34;  // ADC1 input; calibrate dry/wet endpoints\nconstexpr uint8_t RELAY_PIN = 26; // Use a 3.3 V-compatible driver module\n' : ''}${led ? 'constexpr uint8_t STATUS_LED_PIN = 2;\n' : ''}${includeDisplay ? 'constexpr int SCREEN_WIDTH = 128;\nconstexpr int SCREEN_HEIGHT = 64;\nAdafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);\n' : ''}\nvoid setup() {\n  Serial.begin(115200);\n${sensor && !irrigation ? '  dht.begin();\n' : ''}${irrigation ? '  pinMode(RELAY_PIN, OUTPUT);\n  digitalWrite(RELAY_PIN, LOW); // Safe default: pump OFF\n' : ''}${led ? '  pinMode(STATUS_LED_PIN, OUTPUT);\n' : ''}${includeDisplay ? '  Wire.begin(21, 22); // SDA, SCL\n  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {\n    Serial.println("SSD1306 not found at 0x3C");\n  }\n' : ''}}\n\nvoid loop() {\n${sensor && !irrigation ? '  const float humidity = dht.readHumidity();\n  const float temperatureC = dht.readTemperature();\n  if (isnan(humidity) || isnan(temperatureC)) {\n    Serial.println("DHT read failed; check wiring and 4.7 kOhm pull-up");\n    delay(2000);\n    return;\n  }\n  Serial.printf("T: %.1f C  RH: %.1f %%\\n", temperatureC, humidity);\n' : ''}${irrigation ? '  const int soilRaw = analogRead(SOIL_PIN);\n  Serial.printf("Soil ADC: %d\\n", soilRaw);\n  // Calibrate this threshold for your sensor and soil before enabling a pump.\n  const bool needsWater = soilRaw > 2600;\n  digitalWrite(RELAY_PIN, needsWater ? HIGH : LOW);\n' : ''}${includeDisplay && sensor && !irrigation ? '  display.clearDisplay();\n  display.setTextColor(SSD1306_WHITE);\n  display.setTextSize(1);\n  display.setCursor(0, 8);\n  display.printf("Room monitor\\n%.1f C  %.1f %% RH", temperatureC, humidity);\n  display.display();\n' : ''}${led && !irrigation ? '  digitalWrite(STATUS_LED_PIN, !digitalRead(STATUS_LED_PIN));\n' : ''}  delay(${irrigation ? '1000' : '2000'});\n}\n`;
}

function buildIrrigation(project) {
  const next = createStarterProject();
  next.versions = clone(project.versions || []);
  next.name = 'Smart Irrigation';
  next.description = 'ESP32 soil-moisture monitor · protected relay-driver output';
  next.components = next.components.filter((component) => !['R1', 'R2', 'D1'].includes(component.id));
  const sensor = next.components.find((component) => component.id === 'U2');
  Object.assign(sensor, {
    libraryId: 'soil', name: 'Capacitive soil sensor', value: 'Analog output · 3.3 V',
    footprint: 'SOIL-SENSOR-MODULE', x: 710, y: 340,
  });
  next.components.push({
    id: 'K1', libraryId: 'relay', ref: 'K1', name: 'Relay driver module', value: '5 V coil · verify 3.3 V input',
    type: 'sensor', category: 'Power & drivers', footprint: 'RELAY-1CH', x: 710, y: 470,
  });
  next.wires = next.wires.filter((wire) => !['w-pullup', 'w-vcc-r1', 'w-led-drive', 'w-led', 'w-led-gnd'].includes(wire.id));
  const analog = next.wires.find((wire) => wire.id === 'w-dht-data');
  Object.assign(analog, {
    from: ['U1', 'GPIO34'], to: ['U2', 'DATA'], net: 'SOIL_AO', label: 'SOIL_AO · GPIO34',
    waypoints: [{ x: 290, y: 315 }, { x: 290, y: 300 }, { x: 680, y: 300 }, { x: 680, y: 399 }, { x: 710, y: 399 }],
  });
  next.wires.push(
    { id: 'w-relay-vcc', from: ['U1', '5V'], to: ['K1', 'VCC'], color: 'power', net: '5V', label: '5V · MODULE ONLY', waypoints: [{ x: 270, y: 195 }, { x: 270, y: 92 }, { x: 690, y: 92 }, { x: 690, y: 495 }, { x: 710, y: 495 }] },
    { id: 'w-relay-gnd', from: ['U1', 'GND_R'], to: ['K1', 'GND'], color: 'ground', net: 'GND', waypoints: [{ x: 700, y: 515 }, { x: 700, y: 565 }, { x: 710, y: 565 }] },
    { id: 'w-relay-control', from: ['U1', 'GPIO26'], to: ['K1', 'DATA'], color: 'signal', net: 'PUMP_EN', label: 'PUMP_EN · GPIO26', waypoints: [{ x: 535, y: 495 }, { x: 535, y: 610 }, { x: 680, y: 610 }, { x: 680, y: 529 }, { x: 710, y: 529 }] },
  );
  next.notes = [
    'Keep the pump on a separately rated supply; never power it from an ESP32 GPIO or 3.3 V rail.',
    'Confirm the relay module input is compatible with 3.3 V logic. Fuse the load supply and verify contact ratings.',
    'The relay contacts/load and pump connector are not represented in this preview. Add and verify them in a full schematic.',
  ];
  return next;
}

function buildBlink(project) {
  const next = createStarterProject();
  next.versions = clone(project.versions || []);
  next.name = 'ESP32 LED Controller';
  next.description = 'GPIO2 indicator · series current limiting · USB powered';
  next.components = next.components.filter((component) => ['U1', 'R2', 'D1', 'C1'].includes(component.id));
  next.wires = next.wires.filter((wire) => ['w-led-drive', 'w-led', 'w-led-gnd', 'w-cap-vcc', 'w-cap-gnd'].includes(wire.id));
  next.notes = ['220 Ω resistor is in series with the LED. Check LED forward voltage/current for your specific part.', '100 nF local decoupling capacitor is shown from 3V3 to GND.'];
  return next;
}

export function applyLocalDesignAssistant(project, prompt) {
  const text = prompt.trim();
  const lower = text.toLowerCase();
  if (!text) return { project, changed: false, title: 'Tell me what you want to build', summary: 'Add a short description and I will map it to a local design template.', parts: [], cautions: [] };
  let next = clone(project);
  let title = 'Design review';
  let summary = `Reviewed “${text}” against the current ${project.name} schematic. The local assistant keeps the existing ESP32 design and adds a design note rather than guessing an unverified topology.`;
  if (/soil|plant|watering|irrigat|moisture/.test(lower)) {
    next = buildIrrigation(project);
    title = 'Smart irrigation starter generated';
    summary = 'Selected a capacitive soil-moisture module, ESP32 ADC1 input, 100 nF local bypassing, and a relay-driver control output. The pump power path stays separate from the MCU logic rail.';
  } else if (/blink|blinking|flash|status led|led controller/.test(lower)) {
    next = buildBlink(project);
    title = 'LED controller starter generated';
    summary = 'Kept the ESP32, placed a 220 Ω current-limiting resistor in series with the status LED, retained local decoupling, and removed unrelated room-monitor modules.';
  } else if (/temperature|humidity|room|weather|climate|dht/.test(lower)) {
    next = createStarterProject();
    next.versions = clone(project.versions || []);
    next.name = /weather|outdoor/.test(lower) ? 'Weather Node' : 'Room Monitor';
    next.description = 'ESP32 · DHT22 · SSD1306 I²C display · protected LED output';
    title = 'Room-monitor design ready';
    summary = 'Matched the request to the ESP32 + DHT22 + SSD1306 monitor. I²C uses GPIO21/22 at 3.3 V; the DHT22 data line has a 4.7 kΩ pull-up and the indicator LED has a series resistor.';
  } else if (/arduino|uno|mega|nano|pico|stm32|raspberry pi|teensy|micro:bit/.test(lower)) {
    title = 'Controller migration needs review';
    summary = 'This browser-only assistant does not silently remap a complete netlist between MCU families. The current ESP32 pin map is preserved; use the library to add a target board, then review voltage levels, pin assignments, boot-strapping pins, and firmware before migration.';
    next.notes = [...(next.notes || []), 'MCU conversion is not automatic in this offline build. Re-check every pin and logic voltage before substituting a controller.'];
  } else if (/motor|pump|solenoid|relay|valve/.test(lower)) {
    title = 'Power-stage review';
    summary = 'An inductive load must not be driven directly from a microcontroller pin. Choose a load-rated MOSFET/relay driver, separate supply sized for startup current, appropriate flyback suppression, fuse, and connector; those values depend on your motor/load datasheet.';
    next.notes = [...(next.notes || []), 'Power-stage recommendation only; load current, supply, suppression, and thermal design still need datasheet-based engineering.'];
  } else if (/debug|why|error|check|review/.test(lower)) {
    title = 'Circuit review complete';
    summary = 'Checked the present design structure, power rails, visible protection parts, and signal assignments. See the validation and connection tabs for the specific preview checks.';
  } else {
    summary = `I mapped the request to the current ${project.name} starter. This local rule-based assistant can apply room-monitor, LED-indicator, and basic irrigation templates; for other circuits it provides review prompts rather than inventing a safety-critical netlist.`;
  }
  next.firmware = generateFirmware(next);
  return {
    project: next,
    changed: JSON.stringify(next.components) !== JSON.stringify(project.components) || next.name !== project.name || JSON.stringify(next.wires) !== JSON.stringify(project.wires),
    title,
    summary,
    parts: next.components.map((component) => `${component.ref} · ${component.name}`),
    cautions: next.notes || [],
  };
}

export function describeConnections(project) {
  return project.wires.map((wire) => {
    const fromComponent = project.components.find((component) => component.id === wire.from[0]);
    const toComponent = project.components.find((component) => component.id === wire.to[0]);
    if (!fromComponent || !toComponent) return null;
    const fromPin = wire.from[1].replace('_L', '').replace('_R', '');
    const toPin = wire.to[1].replace('_L', '').replace('_R', '');
    let detail = wire.net === '3V3' ? '3.3 V logic supply' : wire.net === 'GND' ? 'common ground return' : wire.net?.startsWith('I2C') ? 'I²C bus · 3.3 V logic' : wire.net === 'DHT_DATA' ? 'digital sensor data · pull-up to 3.3 V' : wire.net === 'SOIL_AO' ? 'analog sensor output · ADC1' : wire.net === 'PUMP_EN' ? 'driver control · logic-level only' : wire.net === '5V' ? '5 V module supply' : 'signal connection';
    return { id: wire.id, net: wire.net || 'NET', from: `${fromComponent.ref} ${fromPin}`, to: `${toComponent.ref} ${toPin}`, detail, color: wire.color };
  }).filter(Boolean);
}

export function designSuggestions(project) {
  const irrigation = /irrigation|soil/i.test(project.name);
  const suggestions = [
    { type: 'verified', title: 'LED current limiting', text: project.components.some((item) => item.id === 'R2') ? 'R2 is in series with D1. Confirm its value against the LED forward voltage and desired current.' : 'Add a series resistor sized from supply voltage, LED Vf, and target current.' },
    { type: 'verified', title: 'Local bypassing', text: project.components.some((item) => item.type === 'capacitor') ? 'C1 100 nF is shown across the 3V3 and GND rails. Place it close to the module supply pins.' : 'Add local 100 nF ceramic bypass capacitors at each IC/module supply.' },
    { type: 'review', title: 'Power and logic levels', text: 'The ESP32 GPIOs are 3.3 V only and are not 5 V tolerant. Check every module output and pull-up rail.' },
    ...(project.components.some((item) => item.libraryId === 'esp32dev') && project.components.some((item) => item.type === 'led') ? [{ type: 'review', title: 'Boot-strapping pin', text: 'GPIO2 is a boot-strapping pin on common ESP32 modules. Verify the attached LED/resistor does not prevent boot; choose another GPIO if your exact board requires it.' }] : []),
    ...(irrigation ? [{ type: 'review', title: 'Pump power stage', text: 'Keep load current off the MCU rail. Validate driver/contact ratings, startup current, fuse, flyback path, and enclosure.' }] : [
      { type: 'verified', title: 'Sensor pull-up', text: project.components.some((item) => item.libraryId === 'dht22') ? 'R1 4.7 kΩ pulls the DHT22 data line to 3.3 V.' : 'Select pull-up values from the exact sensor and bus capacitance.' },
      { type: 'review', title: 'Interface verification', text: 'Confirm I²C address and module pull-up voltage; do not parallel 5 V pull-ups with the ESP32 bus.' },
    ]),
    { type: 'review', title: 'Manufacturing review', text: 'Package IDs and PCB traces in this browser preview are illustrative. Run electrical rules, DRC, ERC, and fabrication checks in KiCad before ordering.' },
  ];
  return suggestions;
}

export function templateFallback() {
  return createStarterProject();
}
