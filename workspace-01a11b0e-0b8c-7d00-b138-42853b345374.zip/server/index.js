import http from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { LIBRARY, CATEGORIES } from '../src/model.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const PORT = Number(process.env.PORT || 4173);
const HOST = process.env.HOST || '0.0.0.0';
const AI_KEY = process.env.AI_API_KEY || '';
const AI_MODEL = process.env.AI_MODEL || '';
const AI_PROVIDER = (process.env.AI_PROVIDER || 'openai-compatible').trim().toLowerCase();
const AI_BASE_URL = process.env.AI_BASE_URL || (AI_PROVIDER === 'ollama' ? 'http://127.0.0.1:11434/v1' : 'https://api.openai.com/v1');
function isLoopbackEndpoint(value) {
  try { return ['localhost', '127.0.0.1', '::1'].includes(new URL(value).hostname); } catch { return false; }
}
const AI_ENABLED = Boolean(AI_MODEL && (AI_KEY || ['ollama', 'lm-studio', 'local'].includes(AI_PROVIDER) || isLoopbackEndpoint(AI_BASE_URL)));
const MAX_BODY_BYTES = 1024 * 1024;

const integrations = {
  catalog: {
    id: 'catalog',
    title: 'Circuit Studio component index',
    mode: 'server-api',
    status: 'available',
    itemCount: LIBRARY.length,
    description: 'Searchable starter metadata served by this backend; values and footprints are indicative, not vendor-verified.',
  },
  kicad: {
    id: 'kicad',
    title: 'KiCad official symbol libraries',
    mode: 'public-metadata-search',
    status: 'live-search-when-online',
    url: 'https://gitlab.com/kicad/libraries/kicad-symbols',
    docsUrl: 'https://www.kicad.org/libraries/download/',
    licenseUrl: 'https://www.kicad.org/libraries/license/',
    license: 'CC-BY-SA-4.0',
    description: 'The backend can search public symbol metadata (description, datasheet link, and footprint hint) from the official KiCad GitLab library. Internet access is required; results are attributed and are not electrical verification.',
  },
  tinkercad: {
    id: 'tinkercad',
    title: 'Autodesk Tinkercad Circuits',
    mode: 'user-authorized-file-bridge',
    status: 'export-import-only',
    url: 'https://www.tinkercad.com/circuits',
    docsUrl: 'https://www.tinkercad.com/blog/tinkertips-export-options',
    formats: ['CSV component list', 'BRD', 'schematic PDF', 'image'],
    description: 'Use Tinkercad’s documented user export; this backend can normalize a BOM CSV. No login automation or private project API is used.',
  },
  cirkit: {
    id: 'cirkit',
    title: 'Cirkit Designer',
    mode: 'documented-extension-reference',
    status: 'custom-simulation-api-only',
    url: 'https://www.cirkitdesigner.com/',
    docsUrl: 'https://learn.cirkitdesigner.com/custom-simulation-parts/component-simulation-logic-ts/overview/',
    description: 'Public docs describe APIs for custom component simulation logic inside Cirkit. No external project-generation API is connected by this build.',
  },
};

const KICAD_API = 'https://gitlab.com/api/v4/projects/kicad%2Flibraries%2Fkicad-symbols';
const KICAD_PROJECT_URL = 'https://gitlab.com/kicad/libraries/kicad-symbols';
const KICAD_LICENSE = 'https://www.kicad.org/libraries/license/';
const publicDataCache = new Map();
const CACHE_TTL_MS = 6 * 60 * 60 * 1000;

function cachedValue(key) {
  const entry = publicDataCache.get(key);
  if (!entry || entry.expiresAt <= Date.now()) { publicDataCache.delete(key); return null; }
  return entry.value;
}
function cacheValue(key, value) {
  if (publicDataCache.size > 300) {
    const oldest = publicDataCache.keys().next().value;
    if (oldest) publicDataCache.delete(oldest);
  }
  publicDataCache.set(key, { value, expiresAt: Date.now() + CACHE_TTL_MS });
  return value;
}

async function fetchKiCadTree(folder) {
  const key = `kicad-tree:${folder}`;
  const cached = cachedValue(key);
  if (cached) return cached;
  const url = new URL(`${KICAD_API}/repository/tree`);
  url.searchParams.set('path', folder);
  url.searchParams.set('per_page', '100');
  url.searchParams.set('page', '1');
  url.searchParams.set('ref', 'master');
  const response = await fetch(url, { headers: { accept: 'application/json', 'user-agent': 'Circuit-Studio-Prototype' }, signal: AbortSignal.timeout(9000) });
  if (!response.ok) throw new Error(`KiCad library index returned HTTP ${response.status}`);
  const data = await response.json();
  if (!Array.isArray(data)) throw new Error('KiCad library index returned an unexpected response');
  return cacheValue(key, data.filter((entry) => entry.type === 'blob' && entry.name.endsWith('.kicad_sym')).map((entry) => ({ name: entry.name, path: entry.path })));
}

function readKiCadString(raw, quoteIndex) {
  if (quoteIndex < 0 || raw[quoteIndex] !== '"') return '';
  let value = '';
  for (let index = quoteIndex + 1; index < raw.length; index++) {
    const character = raw[index];
    if (character === '"') return value.trim();
    if (character === '\\' && index + 1 < raw.length) {
      const next = raw[++index];
      value += next === 'n' || next === 't' ? ' ' : next;
    } else value += character;
  }
  return value.trim();
}
function kicadProperty(raw, propertyName) {
  const marker = `(property "${propertyName}"`;
  const start = raw.indexOf(marker);
  if (start < 0) return '';
  return readKiCadString(raw, raw.indexOf('"', start + marker.length));
}

async function fetchKiCadSymbol(filePath) {
  const key = `kicad-symbol:${filePath}`;
  const cached = cachedValue(key);
  if (cached) return cached;
  const apiPath = encodeURIComponent(filePath);
  const response = await fetch(`${KICAD_API}/repository/files/${apiPath}/raw?ref=master`, {
    headers: { accept: 'text/plain', 'user-agent': 'Circuit-Studio-Prototype' },
    signal: AbortSignal.timeout(9000),
  });
  if (!response.ok) throw new Error(`KiCad symbol ${path.basename(filePath)} returned HTTP ${response.status}`);
  const raw = await response.text();
  if (raw.length > 250_000) throw new Error('KiCad symbol file exceeds the metadata limit');
  const marker = '(symbol "';
  const symbolStart = raw.indexOf(marker);
  const name = readKiCadString(raw, symbolStart < 0 ? -1 : symbolStart + marker.length - 1) || path.basename(filePath).slice(0, -'.kicad_sym'.length);
  const library = filePath.split('/')[0].endsWith('.kicad_symdir') ? filePath.split('/')[0].slice(0, -'.kicad_symdir'.length) : filePath.split('/')[0];
  const result = {
    provider: 'KiCad', library, symbol: name,
    footprint: kicadProperty(raw, 'Footprint'),
    datasheet: kicadProperty(raw, 'Datasheet'),
    description: kicadProperty(raw, 'Description'),
    keywords: kicadProperty(raw, 'ki_keywords'),
    license: 'CC-BY-SA-4.0',
    sourceUrl: `${KICAD_PROJECT_URL}/-/blob/master/${filePath.split('/').map(encodeURIComponent).join('/')}`,
    licenseUrl: KICAD_LICENSE,
  };
  return cacheValue(key, result);
}

const KICAD_STOPS = new Set(['the', 'and', 'with', 'for', 'from', 'build', 'make', 'want', 'using', 'use', 'design', 'circuit', 'project', 'module', 'component', 'board', 'part', 'monitor', 'system', 'based', 'into', 'that', 'this', 'small', 'safe', 'safely', 'connect', 'include']);
function publicSearchTokens(prompt) {
  const localMatches = candidateParts(prompt).map((item) => LIBRARY.find((part) => part.id === item.id)).filter(Boolean);
  const expanded = `${prompt} ${localMatches.map((part) => `${part.name} ${part.sub}`).join(' ')}`.toLowerCase();
  return [...new Set(expanded.split(/[^a-z0-9]+/).filter((token) => token.length > 2 && !KICAD_STOPS.has(token)))];
}
function includesAny(text, words) { return words.some((word) => text.includes(word)); }
function kicadFoldersForPrompt(prompt) {
  const lower = prompt.toLowerCase();
  const folders = [];
  if (includesAny(lower, ['esp32', 'esp8266', 'microcontroller', 'mcu'])) folders.push('MCU_Espressif.kicad_symdir', 'MCU_Module.kicad_symdir');
  if (includesAny(lower, ['arduino', 'raspberry', 'pico', 'teensy', 'micro:bit'])) folders.push('MCU_Module.kicad_symdir');
  if (includesAny(lower, ['sensor', 'temperature', 'humidity', 'moisture', 'pressure', 'dht', 'bme', 'ds18', 'soil', 'weather', 'climate', 'room'])) folders.push('Sensor.kicad_symdir');
  if (includesAny(lower, ['display', 'oled', 'ssd1306', 'screen'])) folders.push('Display_Graphic.kicad_symdir');
  if (includesAny(lower, ['lcd', 'character display'])) folders.push('Display_Character.kicad_symdir');
  if (includesAny(lower, ['relay', 'contactor'])) folders.push('Relay.kicad_symdir');
  if (includesAny(lower, ['motor', 'h-bridge', 'driver', 'pump'])) folders.push('Driver_Motor.kicad_symdir');
  if (lower.includes('led')) folders.push('LED.kicad_symdir');
  if (includesAny(lower, ['connector', 'jst', 'terminal'])) folders.push('Connector.kicad_symdir');
  if (!folders.length) folders.push('Sensor.kicad_symdir', 'MCU_Module.kicad_symdir');
  return [...new Set(folders)].slice(0, 5);
}
function directKiCadPaths(prompt) {
  const lower = prompt.toLowerCase();
  const paths = [];
  if (includesAny(lower, ['dht22', 'am2302'])) paths.push('Sensor.kicad_symdir/AM2302.kicad_sym');
  if (lower.includes('bme280')) paths.push('Sensor.kicad_symdir/BME280.kicad_sym');
  if (lower.includes('bme680')) paths.push('Sensor.kicad_symdir/BME680.kicad_sym');
  if (lower.includes('ds18b20')) paths.push('Sensor_Temperature.kicad_symdir/DS18B20.kicad_sym');
  if (includesAny(lower, ['esp32', 'esp-32'])) paths.push('MCU_Espressif.kicad_symdir/ESP32-S3.kicad_sym', 'MCU_Module.kicad_symdir/Adafruit_Feather_HUZZAH32_ESP32.kicad_sym');
  if (lower.includes('esp8266')) paths.push('MCU_Espressif.kicad_symdir/ESP8266EX.kicad_sym');
  if (lower.includes('arduino') && lower.includes('uno')) paths.push('MCU_Module.kicad_symdir/Arduino_UNO_R3.kicad_sym');
  if (includesAny(lower, ['oled', 'ssd1306'])) paths.push('Display_Graphic.kicad_symdir/ER_OLEDM0.91_1x-I2C.kicad_sym');
  if (includesAny(lower, ['resistor', 'pull-up', 'pull up'])) paths.push('Device.kicad_symdir/R.kicad_sym');
  if (lower.includes('capacitor') || lower.includes('decoupl')) paths.push('Device.kicad_symdir/C.kicad_sym');
  if (lower.includes('inductor')) paths.push('Device.kicad_symdir/L.kicad_sym');
  return [...new Set(paths)];
}

function scoreKiCadFile(file, tokens) {
  const suffix = '.kicad_sym';
  const name = (file.name.endsWith(suffix) ? file.name.slice(0, -suffix.length) : file.name).toLowerCase();
  return tokens.reduce((score, token) => score + (name.includes(token) ? (name === token ? 5 : 2) : 0), 0);
}
async function searchOpenKiCad(prompt) {
  const tokens = publicSearchTokens(prompt);
  const paths = new Set(directKiCadPaths(prompt));
  const folders = kicadFoldersForPrompt(prompt);
  const listings = await Promise.allSettled(folders.map(async (folder) => ({ folder, files: await fetchKiCadTree(folder) })));
  for (const listing of listings) {
    if (listing.status !== 'fulfilled') continue;
    const ranked = listing.value.files.map((file) => ({ ...file, score: scoreKiCadFile(file, tokens) })).filter((file) => file.score > 0).sort((a, b) => b.score - a.score);
    ranked.slice(0, 2).forEach((file) => paths.add(file.path));
  }
  const fetched = await Promise.allSettled([...paths].slice(0, 8).map((filePath) => fetchKiCadSymbol(filePath)));
  const items = fetched.filter((result) => result.status === 'fulfilled').map((result) => result.value);
  return {
    status: items.length ? 'available' : 'no-matches',
    source: 'KiCad official public symbol libraries',
    sourceUrl: KICAD_PROJECT_URL,
    license: 'CC-BY-SA-4.0', licenseUrl: KICAD_LICENSE,
    note: 'Open symbol-library metadata for discovery only. Footprint hints and datasheet links must be verified; results are not electrical or package approval.',
    items,
  };
}

const json = (response, status = 200) => ({
  status,
  headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' },
  body: JSON.stringify(response),
});

function readJson(request) {
  return new Promise((resolve, reject) => {
    let body = '';
    let bytes = 0;
    request.setEncoding('utf8');
    request.on('data', (chunk) => {
      bytes += Buffer.byteLength(chunk);
      if (bytes > MAX_BODY_BYTES) {
        reject(Object.assign(new Error('Request body too large'), { statusCode: 413 }));
        request.destroy();
        return;
      }
      body += chunk;
    });
    request.on('end', () => {
      try { resolve(JSON.parse(body || '{}')); }
      catch { reject(Object.assign(new Error('Invalid JSON body'), { statusCode: 400 })); }
    });
    request.on('error', reject);
  });
}

function csvRows(source) {
  const rows = [];
  let row = [];
  let cell = '';
  let quoted = false;
  for (let i = 0; i < source.length; i++) {
    const char = source[i];
    if (char === '"' && quoted && source[i + 1] === '"') { cell += '"'; i++; }
    else if (char === '"') quoted = !quoted;
    else if (char === ',' && !quoted) { row.push(cell.trim()); cell = ''; }
    else if ((char === '\n' || char === '\r') && !quoted) {
      if (char === '\r' && source[i + 1] === '\n') i++;
      row.push(cell.trim());
      if (row.some(Boolean)) rows.push(row);
      row = []; cell = '';
    } else cell += char;
  }
  row.push(cell.trim());
  if (row.some(Boolean)) rows.push(row);
  if (rows.length < 2) return [];
  const headers = rows.shift().map((header) => header.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim());
  const findColumn = (...names) => {
    for (const name of names) { const exact = headers.indexOf(name); if (exact >= 0) return exact; }
    for (const name of names.filter((item) => item.length > 3)) { const partial = headers.findIndex((header) => header.includes(name)); if (partial >= 0) return partial; }
    return -1;
  };
  const refIndex = findColumn('reference', 'designator', 'ref');
  const qtyIndex = findColumn('quantity', 'qty', 'count');
  const valueIndex = findColumn('value', 'rating', 'part number', 'component value');
  const nameIndex = findColumn('description', 'component name', 'name', 'component', 'part name', 'part');
  const footprintIndex = findColumn('footprint', 'package');
  return rows.map((record) => {
    const get = (index) => index < 0 ? '' : record[index] || '';
    const description = get(nameIndex) || get(valueIndex) || 'Imported component';
    const value = get(valueIndex);
    const query = `${description} ${value} ${get(footprintIndex)}`.toLowerCase();
    const match = LIBRARY.map((part) => ({
      part,
      score: `${part.name} ${part.sub} ${part.footprint} ${part.category}`.toLowerCase().split(/[^a-z0-9]+/).filter((token) => token.length > 2 && query.includes(token)).length,
    })).sort((a, b) => b.score - a.score)[0];
    return {
      reference: get(refIndex),
      quantity: Math.max(1, Number.parseInt(get(qtyIndex) || '1', 10) || 1),
      value,
      description,
      footprint: get(footprintIndex),
      match: match?.score ? { id: match.part.id, name: match.part.name, score: match.score } : null,
    };
  });
}

function candidateParts(prompt) {
  const words = prompt.toLowerCase().split(/[^a-z0-9]+/).filter((word) => word.length > 2);
  return LIBRARY.map((part) => {
    const haystack = `${part.name} ${part.sub} ${part.category} ${part.footprint}`.toLowerCase();
    const score = words.reduce((sum, word) => sum + (haystack.includes(word) ? 1 : 0), 0);
    return { part, score };
  }).filter((item) => item.score > 0).sort((a, b) => b.score - a.score).slice(0, 8).map(({ part, score }) => ({
    id: part.id, name: part.name, category: part.category, valueHint: part.sub, footprintHint: part.footprint, relevance: score,
  }));
}

function localAssistantReply(prompt, projectSummary = {}) {
  const matches = candidateParts(prompt);
  const lower = prompt.toLowerCase();
  const cautions = [];
  if (/motor|pump|relay|solenoid|heater|valve/.test(lower)) cautions.push('Do not drive an inductive or high-current load directly from a microcontroller GPIO. Size its driver, supply, fuse, and suppression from the load datasheet.');
  if (/5v|5 v|12v|12 v|motor|relay|pump/.test(lower)) cautions.push('Check logic-level compatibility; common ESP32 GPIOs are 3.3 V only and are not 5 V tolerant.');
  if (/battery|lipo|li-ion|18650/.test(lower)) cautions.push('Battery charging, over-current protection, cell chemistry, and undervoltage cutoff require a suitable protection/charger design.');
  if (!cautions.length) cautions.push('Catalog matches are suggestions only. Confirm pinout, absolute maximum ratings, supply range, and package against the exact datasheet.');
  const known = Array.isArray(projectSummary.components) ? projectSummary.components.length : 0;
  return {
    mode: 'local-catalog',
    title: 'Backend catalog review',
    summary: `The server searched ${LIBRARY.length} indexed starter parts${known ? ` against a ${known}-component project summary` : ''}. ${matches.length ? `Potential matches: ${matches.slice(0, 4).map((item) => item.name).join(', ')}.` : 'No strong catalog match was found; add manufacturer/part-number details for a better match.'}`,
    recommendations: matches.slice(0, 5).map((item) => `${item.name} · ${item.valueHint}`),
    cautions,
    parts: matches,
    source: 'Circuit Studio starter catalog; public-site logins are not used.',
  };
}

function cleanString(value, limit = 4000) { return typeof value === 'string' ? value.trim().slice(0, limit) : ''; }
function safeProjectSummary(value = {}) {
  return {
    name: cleanString(value.name, 100),
    components: Array.isArray(value.components) ? value.components.slice(0, 120).map((part) => ({
      ref: cleanString(part.ref, 20), name: cleanString(part.name, 100), value: cleanString(part.value, 80), footprint: cleanString(part.footprint, 80),
    })) : [],
    nets: Array.isArray(value.nets) ? value.nets.slice(0, 200).map((net) => cleanString(net, 100)) : [],
  };
}

function providerFailure(status) {
  if (status === 401 || status === 403) return 'Authentication rejected. Check AI_API_KEY or the local model access settings.';
  if (status === 404) return 'Model endpoint or model name was not found. Check AI_BASE_URL and AI_MODEL.';
  if (status === 429) return 'The provider is rate-limiting requests. Wait or check its quota.';
  return `The configured model provider returned HTTP ${status}.`;
}

async function diagnoseConfiguredModel() {
  if (!AI_ENABLED) return { configured: false, ok: false, provider: null, model: null, error: 'No model is configured. Set AI_MODEL and either AI_API_KEY or a supported local provider.' };
  const started = Date.now();
  let base = AI_BASE_URL;
  while (base.endsWith('/')) base = base.slice(0, -1);
  const url = base.endsWith('/chat/completions') ? base : `${base}/chat/completions`;
  try {
    const headers = { 'content-type': 'application/json' };
    if (AI_KEY) headers.authorization = `Bearer ${AI_KEY}`;
    const response = await fetch(url, {
      method: 'POST', headers,
      body: JSON.stringify({ model: AI_MODEL, temperature: 0, max_tokens: 30, messages: [{ role: 'user', content: 'Reply with exactly: Circuit Studio model connection OK.' }] }),
      signal: AbortSignal.timeout(30000),
    });
    if (!response.ok) return { configured: true, ok: false, provider: AI_PROVIDER, model: AI_MODEL, httpStatus: response.status, error: providerFailure(response.status), latencyMs: Date.now() - started };
    const payload = await response.json();
    const content = payload?.choices?.[0]?.message?.content;
    if (typeof content !== 'string' || !content.trim()) return { configured: true, ok: false, provider: AI_PROVIDER, model: AI_MODEL, error: 'Endpoint responded, but did not return chat-completions text. Check provider compatibility and model availability.', latencyMs: Date.now() - started };
    return { configured: true, ok: true, provider: AI_PROVIDER, model: AI_MODEL, latencyMs: Date.now() - started };
  } catch (error) {
    const timeout = error?.name === 'TimeoutError' || error?.name === 'AbortError';
    return { configured: true, ok: false, provider: AI_PROVIDER, model: AI_MODEL, error: timeout ? 'Model request timed out. Check that the model is loaded and reachable.' : 'Could not reach the configured model endpoint. Check AI_BASE_URL, server network access, and whether the model service is running.', latencyMs: Date.now() - started };
  }
}

async function externalAssistantReply(prompt, projectSummary, publicData = null) {
  const local = localAssistantReply(prompt, projectSummary);
  const url = AI_BASE_URL.replace(/\/+$/, '').endsWith('/chat/completions')
    ? AI_BASE_URL
    : `${AI_BASE_URL.replace(/\/+$/, '')}/chat/completions`;
  const response = await fetch(url, {
    method: 'POST',
    headers: { ...(AI_KEY ? { authorization: `Bearer ${AI_KEY}` } : {}), 'content-type': 'application/json' },
    body: JSON.stringify({
      model: AI_MODEL,
      temperature: 0.15,
      messages: [
        { role: 'system', content: 'You are an electronics design review assistant. Ground part suggestions in the supplied Circuit Studio catalog and, when useful, the supplied public KiCad symbol metadata. KiCad metadata is discovery context, not electrical verification. Never claim a design is verified. Flag uncertain pinouts, voltage domains, current, thermal, isolation, and protection. Return only JSON with keys title, summary, recommendations (array of strings), cautions (array of strings), and parts (array of catalog IDs). Do not invent datasheet facts.' },
        { role: 'user', content: JSON.stringify({ prompt, project: projectSummary, catalogMatches: local.parts, publicKiCadMetadata: publicData?.items || [] }) },
      ],
    }),
    signal: AbortSignal.timeout(25000),
  });
  if (!response.ok) throw new Error(providerFailure(response.status));
  const payload = await response.json();
  const content = payload?.choices?.[0]?.message?.content;
  if (typeof content !== 'string') throw new Error('Configured AI service returned an unsupported response');
  const normalized = content.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
  const parsed = JSON.parse(normalized);
  const knownIds = new Set(LIBRARY.map((item) => item.id));
  const parts = Array.isArray(parsed.parts) ? parsed.parts.filter((id) => knownIds.has(id)).map((id) => local.parts.find((part) => part.id === id) || (() => {
    const item = LIBRARY.find((entry) => entry.id === id);
    return { id, name: item.name, category: item.category, valueHint: item.sub, footprintHint: item.footprint };
  })()) : local.parts;
  return {
    mode: 'configured-ai',
    title: cleanString(parsed.title, 120) || 'AI design review',
    summary: cleanString(parsed.summary, 1500) || local.summary,
    recommendations: Array.isArray(parsed.recommendations) ? parsed.recommendations.slice(0, 8).map((item) => cleanString(item, 500)) : local.recommendations,
    cautions: Array.isArray(parsed.cautions) ? [...new Set([...local.cautions, ...parsed.cautions.slice(0, 8).map((item) => cleanString(item, 500))])] : local.cautions,
    parts,
    source: `Configured ${AI_PROVIDER} model · ${AI_MODEL}`,
  };
}

function addPublicKiCadRecommendations(reply, publicData) {
  if (!publicData?.items?.length) return { ...reply, publicData };
  const publicRecommendations = publicData.items.slice(0, 3).map((item) => `KiCad symbol ${item.symbol} · ${item.library}${item.footprint ? ` · footprint hint ${item.footprint}` : ''} (verify the exact variant and datasheet)`);
  return {
    ...reply,
    recommendations: [...new Set([...publicRecommendations, ...(reply.recommendations || [])])].slice(0, 8),
    source: reply.mode === 'configured-ai' ? `${reply.source} · public KiCad metadata supplied` : 'Circuit Studio catalog + KiCad public symbol metadata',
    publicData,
  };
}

async function apiRoute(request, url) {
  if (request.method === 'GET' && url.pathname === '/api/health') {
    return json({ ok: true, backend: 'Circuit Studio API', ai: { enabled: AI_ENABLED, mode: AI_ENABLED ? (AI_PROVIDER === 'ollama' ? 'self-hosted-openai-compatible' : 'configured-server-provider') : 'local-catalog-only', provider: AI_ENABLED ? AI_PROVIDER : null, model: AI_ENABLED ? AI_MODEL : null }, catalog: { count: LIBRARY.length, categories: CATEGORIES.length - 1, quality: 'curated indicative metadata' }, integrations: Object.values(integrations).map(({ id, title, mode, status }) => ({ id, title, mode, status })) });
  }
  if (request.method === 'GET' && url.pathname === '/api/integrations') return json({ items: Object.values(integrations) });
  if (request.method === 'POST' && url.pathname === '/api/ai/test') return json(await diagnoseConfiguredModel());
  if (request.method === 'GET' && url.pathname === '/api/catalog') {
    const query = cleanString(url.searchParams.get('q') || '', 120).toLowerCase();
    const category = cleanString(url.searchParams.get('category') || '', 80);
    const items = LIBRARY.filter((item) => (!category || category === 'All parts' || item.category === category) && (!query || `${item.name} ${item.sub} ${item.category} ${item.family} ${item.footprint}`.toLowerCase().includes(query)));
    return json({ source: 'Circuit Studio curated starter catalog', quality: 'indicative; verify manufacturer datasheets', items });
  }
  if (request.method === 'GET' && url.pathname === '/api/catalog/open') {
    const query = cleanString(url.searchParams.get('q') || '', 400);
    if (!query) return json({ error: 'A component name or design brief is required.' }, 400);
    try { return json(await searchOpenKiCad(query)); }
    catch (error) { return json({ status: 'unavailable', source: 'KiCad official public symbol libraries', items: [], error: cleanString(error.message, 240), sourceUrl: KICAD_PROJECT_URL, license: 'CC-BY-SA-4.0', licenseUrl: KICAD_LICENSE }); }
  }
  if (request.method === 'POST' && url.pathname === '/api/assistant') {
    const body = await readJson(request);
    const prompt = cleanString(body.prompt, 4000);
    if (!prompt) return json({ error: 'A non-empty project brief is required.' }, 400);
    const projectSummary = safeProjectSummary(body.project || {});
    let publicData = null;
    if (body.usePublicData === true) {
      try { publicData = await searchOpenKiCad(prompt); }
      catch (error) { publicData = { status: 'unavailable', source: 'KiCad official public symbol libraries', items: [], error: cleanString(error.message, 240), sourceUrl: KICAD_PROJECT_URL, license: 'CC-BY-SA-4.0', licenseUrl: KICAD_LICENSE }; }
    }
    if (body.useExternal === true && AI_ENABLED) {
      try { return json(addPublicKiCadRecommendations(await externalAssistantReply(prompt, projectSummary, publicData), publicData)); }
      catch (error) {
        return json(addPublicKiCadRecommendations({ ...localAssistantReply(prompt, projectSummary), fallbackReason: cleanString(error.message, 240) }, publicData));
      }
    }
    return json(addPublicKiCadRecommendations(localAssistantReply(prompt, projectSummary), publicData));
  }
  if (request.method === 'POST' && url.pathname === '/api/import/tinkercad-bom') {
    const body = await readJson(request);
    const csv = cleanString(body.csv, MAX_BODY_BYTES);
    if (!csv) return json({ error: 'CSV content is required.' }, 400);
    const rows = csvRows(csv);
    return json({ source: 'Tinkercad user-export CSV', count: rows.length, rows, note: 'BOM matching is heuristic; it does not import circuit wiring or a Tinkercad project.' });
  }
  return json({ error: 'API route not found.' }, 404);
}

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon',
};
async function staticRoute(urlPath) {
  let decoded;
  try { decoded = decodeURIComponent(urlPath); } catch { return { status: 400, body: 'Bad path' }; }
  let target = path.resolve(ROOT, `.${decoded === '/' ? '/index.html' : decoded}`);
  if (!target.startsWith(ROOT + path.sep) && target !== path.join(ROOT, 'index.html')) return { status: 403, body: 'Forbidden' };
  try {
    const data = await readFile(target);
    return { status: 200, headers: { 'content-type': MIME[path.extname(target)] || 'application/octet-stream', 'cache-control': 'no-cache' }, body: data };
  } catch { return { status: 404, body: 'Not found' }; }
}

const server = http.createServer(async (request, response) => {
  try {
    const url = new URL(request.url, `http://${request.headers.host || 'localhost'}`);
    const result = url.pathname.startsWith('/api/') ? await apiRoute(request, url) : await staticRoute(url.pathname);
    response.writeHead(result.status, result.headers || { 'content-type': 'text/plain; charset=utf-8' });
    response.end(result.body);
  } catch (error) {
    const status = error.statusCode || 500;
    response.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
    response.end(JSON.stringify({ error: status === 500 ? 'Backend request failed.' : error.message }));
  }
});

server.listen(PORT, HOST, () => {
  console.log(`Circuit Studio backend listening on http://${HOST}:${PORT}`);
  console.log(`Component catalog: ${LIBRARY.length} starter records · AI provider: ${AI_ENABLED ? AI_MODEL : 'local only'}`);
});
