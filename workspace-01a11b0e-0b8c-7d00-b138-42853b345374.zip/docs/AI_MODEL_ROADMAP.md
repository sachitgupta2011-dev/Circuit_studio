# Circuit Studio AI model roadmap

## What the current AI mode does

- The editor and three deterministic templates (room monitor, LED controller, irrigation) run locally.
- The backend can search the 70-record starter catalog and optionally retrieve attributed KiCad symbol metadata.
- A configured chat-completions model—hosted or self-hosted with Ollama—can review the prompt and project summary. The **Test AI** control sends a project-free diagnostic prompt.
- The model does **not** currently generate arbitrary circuit topology, emit trusted netlists, train weights, or auto-wire custom circuits. Only the known local templates change the schematic automatically.

## Recommended route to “our own model”

### 1. Start with a local, self-hosted model (available now)

Run a compatible local inference service such as Ollama on the same machine as the Node backend, install/pull a chat model, and configure:

```sh
AI_PROVIDER=ollama AI_MODEL="<installed-model-tag>" npm run dev
```

The default Ollama endpoint is `http://127.0.0.1:11434/v1`. In a hosted preview, that loopback address refers to the preview server, not the user's computer; run the backend and Ollama together locally or provide a server-reachable endpoint. This is self-hosting existing model weights, not training a new model.

### 2. Build retrieval-augmented review before fine-tuning

- Keep the starter catalog and KiCad metadata as **discovery** sources, with attribution and license records. Do not present symbols/footprints as verified electrical specifications.
- Add datasheet-derived facts only with source URLs, revision/date, extraction provenance, and human review. Preserve copyright/licensing restrictions; don't scrape gated vendor content.
- Retrieve a small set of source-backed facts per query, then pass those plus the user-approved project summary to the model.
- Require the model to cite each factual recommendation to an attached source record, or mark it unknown.

### 3. Define a safe, constrained output contract

Before allowing AI-generated schematics, accept only a strict schema such as:

```json
{
  "parts": [{ "libraryId": "dht22", "ref": "U2", "value": "DHT22" }],
  "connections": [{ "from": ["U1", "GPIO4"], "to": ["U2", "DATA"], "net": "DHT_DATA" }],
  "assumptions": [],
  "warnings": [],
  "sourceIds": []
}
```

A separate deterministic validator must reject unknown part IDs, unsupported pins, duplicate references, dangling endpoints, invalid voltage domains, unsafe load drive, and missing protection. The model's response must be a **draft proposal**, never direct proof of electrical correctness. Apply it only after validation and user review. Do not let free-form model text create SVG/HTML or executable code.

### 4. Create a trustworthy evaluation set

Collect designs that have explicit permission for reuse and human-verified netlists, with representative safe/unsafe cases and exact board/module revisions. Keep train, validation, and holdout projects separate. Score:

- JSON/schema validity and catalog-ID validity
- connection/pin validity and completeness
- voltage, current, polarity, protection, and hazardous-load checks
- source citation accuracy and calibrated uncertainty
- regression behavior for existing templates

A model that produces fluent text but fails pin/electrical checks is not ready to generate circuits.

### 5. Fine-tune only if retrieval and prompting are insufficient

Fine-tuning requires a documented dataset, rights to use it, a chosen base model, compute/storage, and a repeatable evaluation harness. Do not fine-tune on BOM-only CSV as if it contained wiring; the current Tinkercad bridge intentionally imports component-list rows only. Start with RAG plus deterministic validation, then assess whether a small LoRA/adapter adds measurable benefit on the holdout set.

## Current implementation status

Implemented: self-hosted OpenAI-compatible provider option, model connectivity diagnostic, local deterministic fallback, public KiCad metadata lookup, and source/license attribution.

Not implemented: dataset ingestion for training, fine-tuning, arbitrary netlist generation, formal ERC/DRC, or electrical simulation. Those need an approved dataset and safety-validation design before implementation.